package com.example.ec.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.ec.repository.ProductRepository;
import com.example.ec.repository.entity.ProductEntity;
import com.example.ec.service.model.ProductModel;

/**
 * 商品情報に関するサービスクラス。
 */
@Service
public class ProductService {

    /** 商品情報のデータアクセス。 */
    @Autowired
    private ProductRepository productRepository;

    /**
     * 販売中（ON_SALE）の商品一覧を取得する。
     *
     * @return 販売中商品の一覧
     */
    public List<ProductModel> getOnSaleProducts() {
        // 販売中商品をRepositoryから取得してModelに変換
        return productRepository.findOnSaleProducts().stream()
                .map(this::toModel)
                .toList();
    }

    /**
     * 指定した商品IDに一致する販売中（ON_SALE）の商品を1件取得する。
     *
     * @param productId 商品ID
     * @return 商品情報
     */
    public ProductModel getOnSaleProduct(Integer productId) {
        // 販売中の商品を商品IDで取得
        ProductEntity entity = productRepository.findOnSaleProductById(productId);
        // 商品が存在しない場合はnullを返却
        if (entity == null) {
            return null;
        }
        return toModel(entity);
    }

    private ProductModel toModel(ProductEntity entity) {
        // EntityからModelへの変換
        ProductModel model = new ProductModel();
        model.setProductId(entity.getProductId());
        model.setName(entity.getName());
        model.setDescription(entity.getDescription());
        model.setPrice(entity.getPrice());
        model.setStock(entity.getStock());
        model.setStatus(entity.getStatus());
        model.setImageUrl(entity.getImageUrl());
        return model;
    }
}
