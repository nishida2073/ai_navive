package com.example.ec.controller.form;

import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 商品一覧・商品詳細からのカート追加入力を受け取るフォームクラス。
 */
@Data
@NoArgsConstructor
public class ProductListItemForm {
	/** 商品ID。 */
	@NotNull
	private Integer productId;

	/** 数量（1〜99）。 */
	@NotNull
	@Min(1)
	@Max(99)
	private Integer quantity;
}
