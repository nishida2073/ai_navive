package com.example.ec.service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.ec.exception.BusinessException;
import com.example.ec.repository.CartRepository;
import com.example.ec.repository.ProductRepository;
import com.example.ec.repository.entity.CartItemEntity;
import com.example.ec.repository.entity.ProductEntity;
import com.example.ec.service.model.CartItemModel;
import com.example.ec.service.model.CartModel;

/**
 * カート操作に関するサービスクラス。
 */
@Service
public class CartService {

    private static final int MIN_QUANTITY = 1;
    private static final int MAX_QUANTITY = 99;

    /** カート情報のデータアクセス。 */
    @Autowired
    private CartRepository cartRepository;

    /** 商品情報のデータアクセス。 */
    @Autowired
    private ProductRepository productRepository;

    /**
     * カート表示用の情報を取得する。
     *
     * @return カート画面表示モデル
     */
    public CartModel getCart() {
        // カート内のすべての商品情報を取得
        List<CartItemEntity> cartItems = cartRepository.findAll();
        if (cartItems == null || cartItems.isEmpty()) {
            return createEmptyCart();
        }

        // 商品情報を取得してMapを構築
        List<Integer> productIds = cartItems.stream()
                .map(CartItemEntity::getProductId)
                .collect(Collectors.toList());
        List<ProductEntity> products = productRepository.findOnSaleProductsByIds(productIds);
        Map<Integer, ProductEntity> productById = products.stream()
                .collect(Collectors.toMap(ProductEntity::getProductId, p -> p, (a, b) -> a, LinkedHashMap::new));

        // カート内容をModelに変換して集計
        List<CartItemModel> itemModels = new ArrayList<>();
        int totalQuantity = 0;
        int totalAmount = 0;

        for (CartItemEntity cartItem : cartItems) {
            ProductEntity product = productById.get(cartItem.getProductId());
            // 販売停止などで取得できない商品は表示対象外とする。
            if (product == null) {
                continue;
            }

            // 数量と小計を計算
            int quantity = cartItem.getQuantity() == null ? 0 : cartItem.getQuantity();
            int price = product.getPrice() == null ? 0 : product.getPrice();
            int subtotal = price * quantity;

            // Modelの構築
            CartItemModel model = new CartItemModel();
            model.setProductId(product.getProductId());
            model.setName(product.getName());
            model.setImageUrl(product.getImageUrl());
            model.setPrice(price);
            model.setStock(product.getStock());
            model.setQuantity(quantity);
            model.setSubtotal(subtotal);
            itemModels.add(model);

            totalQuantity += quantity;
            totalAmount += subtotal;
        }

        CartModel cartModel = new CartModel();
        cartModel.setItems(itemModels);
        cartModel.setTotalQuantity(totalQuantity);
        cartModel.setTotalAmount(totalAmount);
        cartModel.setEmpty(itemModels.isEmpty());
        return cartModel;
    }

    /**
     * 商品をカートに追加する。
     *
     * @param productId 商品ID
     * @param quantity 追加数量
     */
    @Transactional
    public void addItem(Integer productId, Integer quantity) {
        // 数量の妥当性確認
        validateQuantityRange(quantity);

        // 商品の存在と販売状態を確認
        ProductEntity product = productRepository.findOnSaleProductById(productId);
        if (product == null) {
            throw new BusinessException("error.cart.product.not.on.sale");
        }

        // 在庫確認
        int stock = product.getStock() == null ? 0 : product.getStock();
        if (stock <= 0) {
            throw new BusinessException("error.cart.out.of.stock");
        }
        if (quantity > stock) {
            throw new BusinessException("error.cart.quantity.over.stock");
        }

        // 重複チェックと既存数量の更新、または新規追加
        CartItemEntity existing = cartRepository.findByProductId(productId);
        if (existing != null) {
            // 既存商品の数量更新
            int current = existing.getQuantity() == null ? 0 : existing.getQuantity();
            int newQuantity = current + quantity;
            if (newQuantity > MAX_QUANTITY) {
                throw new BusinessException("error.cart.quantity.over.max");
            }
            if (newQuantity > stock) {
                throw new BusinessException("error.cart.total.quantity.over.stock");
            }
            cartRepository.updateQuantity(productId, newQuantity);
            return;
        }

        // 新規カート項目の追加
        CartItemEntity cartItem = new CartItemEntity();
        cartItem.setProductId(productId);
        cartItem.setQuantity(quantity);
        cartRepository.insert(cartItem);
    }

    /**
     * カート商品の数量を更新する。
     *
     * @param productId 商品ID
     * @param quantity 更新数量
     */
    @Transactional
    public void updateQuantity(Integer productId, Integer quantity) {
        // 数量の妥当性確認
        validateQuantityRange(quantity);

        // 更新対象のカート商品を確認
        CartItemEntity cartItem = cartRepository.findByProductId(productId);
        if (cartItem == null) {
            throw new BusinessException("error.cart.item.not.found");
        }

        // 商品の存在と販売状態を確認
        ProductEntity product = productRepository.findOnSaleProductById(cartItem.getProductId());
        if (product == null) {
            throw new BusinessException("error.cart.product.not.on.sale");
        }

        // 在庫確認
        int stock = product.getStock() == null ? 0 : product.getStock();
        if (quantity > stock) {
            throw new BusinessException("error.cart.quantity.over.stock");
        }

        // 数量を更新
        cartRepository.updateQuantity(productId, quantity);
    }

    /**
     * カート商品を削除する。
     *
     * @param productId 商品ID
     */
    @Transactional
    public void deleteItem(Integer productId) {
        // カート内の該当商品を検索
        CartItemEntity cartItem = cartRepository.findByProductId(productId);
        // 該当商品が存在しない場合は処理終了
        if (cartItem == null) {
            return;
        }
        // カートから商品を削除
        cartRepository.deleteByProductId(productId);
    }

    private void validateQuantityRange(Integer quantity) {
        if (quantity == null || quantity < MIN_QUANTITY || quantity > MAX_QUANTITY) {
            throw new BusinessException("error.cart.quantity.range");
        }
    }

    private CartModel createEmptyCart() {
        CartModel cartModel = new CartModel();
        cartModel.setItems(Collections.emptyList());
        cartModel.setTotalQuantity(0);
        cartModel.setTotalAmount(0);
        cartModel.setEmpty(true);
        return cartModel;
    }
}
