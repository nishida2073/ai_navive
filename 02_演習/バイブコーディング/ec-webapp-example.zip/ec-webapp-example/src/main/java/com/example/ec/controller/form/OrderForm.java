package com.example.ec.controller.form;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;

import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 注文者情報の入力を受け取るフォームクラス。
 */
@Data
@NoArgsConstructor
public class OrderForm {
	/** 注文者氏名。 */
	@NotBlank
	@Size(max = 100)
	private String customerName;

	/** 郵便番号。 */
	@NotBlank
	@Size(max = 7)
	@Pattern(regexp = "\\d{7}")
	private String postalCode;

	/** 注文者住所。 */
	@NotBlank
	@Size(max = 255)
	private String address;

	/** 電話番号。 */
	@NotBlank
	@Size(max = 20)
	@Pattern(regexp = "\\d{10,11}")
	private String phoneNumber;
}
