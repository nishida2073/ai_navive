package com.example.ec.service.model;

import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 注文確認画面の商品1行分を表すモデル。
 */
@Data
@NoArgsConstructor
public class OrderItemModel {
	/** 商品ID。 */
	private Integer productId;

	/** 商品名。 */
	private String name;

	/** 商品画像URL。 */
	private String imageUrl;

	/** 単価。 */
	private Integer unitPrice;

	/** 数量。 */
	private Integer quantity;

	/** 小計。 */
	private Integer subtotal;
}
