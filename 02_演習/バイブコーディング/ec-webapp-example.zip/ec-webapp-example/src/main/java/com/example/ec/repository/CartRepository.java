package com.example.ec.repository;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.example.ec.repository.entity.CartItemEntity;

/**
 * カート情報のデータアクセスを提供するRepository。
 */
@Mapper
public interface CartRepository {

    /**
     * カート内のすべての商品を取得する。
     *
     * @return カート商品一覧
     */
    List<CartItemEntity> findAll();

    /**
     * 指定商品がカートに存在するかを確認する。
     *
     * @param productId 商品ID
     * @return カート商品情報
     */
    CartItemEntity findByProductId(@Param("productId") Integer productId);

    /**
     * カート商品を登録する。
     *
     * @param cartItem カート商品情報
     * @return 登録件数
     */
    int insert(CartItemEntity cartItem);

    /**
     * 指定商品の数量を更新する。
     *
     * @param productId 商品ID
     * @param quantity 数量
     * @return 更新件数
     */
    int updateQuantity(
	    @Param("productId") Integer productId,
	    @Param("quantity") Integer quantity);

    /**
     * 指定商品をカートから削除する。
     *
     * @param productId 商品ID
     * @return 削除件数
     */
    int deleteByProductId(@Param("productId") Integer productId);

    /**
     * カート内のすべての商品を削除する。
     *
     * @return 削除件数
     */
    int deleteAll();
}
