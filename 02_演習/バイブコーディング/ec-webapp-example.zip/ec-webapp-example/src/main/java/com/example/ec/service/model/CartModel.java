package com.example.ec.service.model;

import java.util.List;

import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * カート画面全体で使用する情報を保持するモデル。
 */
@Data
@NoArgsConstructor
public class CartModel {

	/** カート商品の一覧。 */
	private List<CartItemModel> items;

	/** 数量の合計。 */
	private Integer totalQuantity;

	/** 小計の合計金額。 */
	private Integer totalAmount;

	/** カートが空かどうか。 */
	private Boolean empty;
}
