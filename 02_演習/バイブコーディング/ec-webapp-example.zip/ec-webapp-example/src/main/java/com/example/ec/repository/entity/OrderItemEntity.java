package com.example.ec.repository.entity;

import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * order_itemsテーブルに対応する注文明細エンティティ。
 */
@Data
@NoArgsConstructor
public class OrderItemEntity {
	/** 注文明細ID。 */
	private Integer orderItemId;

	/** 注文ID。 */
	private Integer orderId;

	/** 商品ID。 */
	private Integer productId;

	/** 注文時点の商品名。 */
	private String productName;

	/** 注文時点の単価。 */
	private Integer unitPrice;

	/** 数量。 */
	private Integer quantity;

	/** 小計。 */
	private Integer subtotal;
}
