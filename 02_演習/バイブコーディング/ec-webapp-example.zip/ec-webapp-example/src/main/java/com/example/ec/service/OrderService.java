package com.example.ec.service;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.ec.exception.BusinessException;
import com.example.ec.repository.CartRepository;
import com.example.ec.repository.OrderItemRepository;
import com.example.ec.repository.OrderRepository;
import com.example.ec.repository.ProductRepository;
import com.example.ec.repository.entity.OrderEntity;
import com.example.ec.repository.entity.OrderItemEntity;
import com.example.ec.service.model.CartItemModel;
import com.example.ec.service.model.CartModel;
import com.example.ec.service.model.OrderItemModel;
import com.example.ec.service.model.OrderModel;

/**
 * 注文確認画面の表示情報を組み立てるサービスクラス。
 */
@Service
public class OrderService {

	/** カート情報を取得するサービス。 */
	@Autowired
	private CartService cartService;

	/** 注文情報のデータアクセス。 */
	@Autowired
	private OrderRepository orderRepository;

	/** 注文明細情報のデータアクセス。 */
	@Autowired
	private OrderItemRepository orderItemRepository;

	/** 商品情報のデータアクセス。 */
	@Autowired
	private ProductRepository productRepository;

	/** カート情報のデータアクセス。 */
	@Autowired
	private CartRepository cartRepository;

	/**
	 * 注文確認画面用の注文予定情報を取得する。
	 *
	 * @return 注文確認画面用モデル
	 */
	public OrderModel getOrderConfirmation() {
		// カート情報を取得
		CartModel cart = cartService.getCart();
		// カートが空の場合は空の注文モデルを返却
		if (cart == null || Boolean.TRUE.equals(cart.getEmpty())) {
			OrderModel emptyOrder = new OrderModel();
			emptyOrder.setItems(List.of());
			emptyOrder.setTotalQuantity(0);
			emptyOrder.setTotalAmount(0);
			emptyOrder.setEmpty(true);
			return emptyOrder;
		}

		// カート内容を注文モデルに変換
		List<OrderItemModel> items = new ArrayList<>();
		for (CartItemModel cartItem : cart.getItems()) {
			OrderItemModel orderItem = new OrderItemModel();
			orderItem.setProductId(cartItem.getProductId());
			orderItem.setName(cartItem.getName());
			orderItem.setImageUrl(cartItem.getImageUrl());
			orderItem.setUnitPrice(cartItem.getPrice());
			orderItem.setQuantity(cartItem.getQuantity());
			orderItem.setSubtotal(cartItem.getSubtotal());
			items.add(orderItem);
		}

		OrderModel order = new OrderModel();
		order.setItems(items);
		order.setTotalQuantity(cart.getTotalQuantity());
		order.setTotalAmount(cart.getTotalAmount());
		order.setEmpty(false);
		return order;
	}

	/**
	 * 注文を確定する。
	 *
	 * @param orderModel 注文情報
	 * @return 採番された注文ID
	 */
	@Transactional
	public Integer placeOrder(OrderModel orderModel) {
		// カート情報を取得
		CartModel cart = cartService.getCart();

		// カートが空の場合は例外をスロー
		if (Boolean.TRUE.equals(cart.getEmpty())) {
			throw new BusinessException("error.order.cart.empty");
		}

		// 注文ヘッダー情報の構築
		OrderEntity order = new OrderEntity();
		order.setCustomerName(orderModel.getCustomerName());
		order.setPostalCode(orderModel.getPostalCode());
		order.setAddress(orderModel.getAddress());
		order.setPhoneNumber(orderModel.getPhoneNumber());
		order.setTotalAmount(cart.getTotalAmount());
		order.setOrderedAt(LocalDateTime.now());

		// 注文ヘッダーをDBに登録
		orderRepository.insert(order);

		// カート内容から注文明細を作成・登録して在庫を更新
		for (CartItemModel cartItem : cart.getItems()) {
			// 在庫確認
			if (cartItem.getQuantity() > cartItem.getStock()) {
				throw new BusinessException(
						"error.order.stock.insufficient", cartItem.getName());
			}

			// 商品の在庫を減らす
			int updatedCount = productRepository.decreaseStock(
					cartItem.getProductId(),
					cartItem.getQuantity());

			if (updatedCount != 1) {
				throw new BusinessException(
						"error.order.stock.stopped", cartItem.getName());
			}

			// 注文明細の構築
			OrderItemEntity orderItem = new OrderItemEntity();
			orderItem.setOrderId(order.getOrderId());
			orderItem.setProductId(cartItem.getProductId());
			orderItem.setProductName(cartItem.getName());
			orderItem.setUnitPrice(cartItem.getPrice());
			orderItem.setQuantity(cartItem.getQuantity());
			orderItem.setSubtotal(cartItem.getSubtotal());

			// 注文明細をDBに登録
			orderItemRepository.insert(orderItem);
		}

		// 注文完了後にカートを削除
		cartRepository.deleteAll();

		return order.getOrderId();
	}

	/**
	 * 注文完了画面用の注文情報を取得する。
	 *
	 * @param orderId 注文ID
	 * @return 注文完了画面用モデル。存在しない場合は null
	 */
	public OrderModel getCompletedOrder(Integer orderId) {
		// 注文IDから注文情報を取得
		OrderEntity orderEntity = orderRepository.findByOrderId(orderId);
		// 注文情報が存在しない場合はnullを返却
		if (orderEntity == null) {
			return null;
		}

		// 注文明細を取得してModelに変換
		List<OrderItemEntity> orderItemEntities = orderItemRepository.findByOrderId(orderId);
		List<OrderItemModel> items = orderItemEntities.stream()
				.map(entity -> {
					OrderItemModel model = new OrderItemModel();
					model.setProductId(entity.getProductId());
					model.setName(entity.getProductName());
					model.setUnitPrice(entity.getUnitPrice());
					model.setQuantity(entity.getQuantity());
					model.setSubtotal(entity.getSubtotal());
					return model;
				})
				.toList();

		// 合計数量を集計
		Integer totalQuantity = items.stream()
				.mapToInt(OrderItemModel::getQuantity)
				.sum();

		// 注文完了画面用のモデルを構築
		OrderModel order = new OrderModel();
		order.setOrderId(orderEntity.getOrderId());
		order.setCustomerName(orderEntity.getCustomerName());
		order.setPostalCode(orderEntity.getPostalCode());
		order.setAddress(orderEntity.getAddress());
		order.setPhoneNumber(orderEntity.getPhoneNumber());
		order.setOrderedAt(orderEntity.getOrderedAt());
		order.setItems(items);
		order.setTotalQuantity(totalQuantity);
		order.setTotalAmount(orderEntity.getTotalAmount());
		order.setEmpty(items.isEmpty());

		return order;
	}
}
