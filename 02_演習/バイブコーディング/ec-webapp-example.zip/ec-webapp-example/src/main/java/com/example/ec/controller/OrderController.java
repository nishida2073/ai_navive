package com.example.ec.controller;

import java.util.Locale;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.example.ec.controller.form.OrderForm;
import com.example.ec.exception.BusinessException;
import com.example.ec.service.OrderService;
import com.example.ec.service.model.OrderModel;

/**
 * 注文確認画面を表示するController。
 */
@Controller
public class OrderController {

	/** 注文確認画面用のサービス。 */
	@Autowired
	private OrderService orderService;

	/** メッセージ設定。 */
	@Autowired
	private MessageSource messageSource;

	/**
	 * 注文確認画面を表示する。
	 *
	 * @param model 画面表示用モデル
	 * @param redirectAttributes リダイレクト時のフラッシュ属性
	 * @return 注文確認画面のテンプレート名、またはカート画面へのリダイレクト
	 */
	@GetMapping("/orders/confirm")
	public String showOrderConfirm(
			Model model,
			Locale locale,
			RedirectAttributes redirectAttributes) {
		// 注文確認画面用の注文情報を取得
		OrderModel order = orderService.getOrderConfirmation();

		// カートが空の場合はカート画面へリダイレクト

		if (Boolean.TRUE.equals(order.getEmpty())) {
			redirectAttributes.addFlashAttribute("errorMessage",
					messageSource.getMessage("error.order.cart.empty", null, locale));
			return "redirect:/cart";
		}

		model.addAttribute("order", order);

		if (!model.containsAttribute("orderForm")) {
			model.addAttribute("orderForm", new OrderForm());
		}

		return "order-confirm";
	}

	/**
	 * 注文を確定する。
	 *
	 * @param orderForm 注文者情報
	 * @param bindingResult バリデーション結果
	 * @param model 画面表示用モデル
	 * @param redirectAttributes リダイレクト時のフラッシュ属性
	 * @return 注文完了画面へのリダイレクト、または注文確認画面
	 */
	@PostMapping("/orders")
	public String placeOrder(
			@Validated @ModelAttribute("orderForm") OrderForm orderForm,
			BindingResult bindingResult,
			Model model,
			Locale locale,
			RedirectAttributes redirectAttributes) {
		// 注文確認画面用の注文情報を取得
		OrderModel order = orderService.getOrderConfirmation();

		// カートが空の場合はカート画面へリダイレクト
		if (Boolean.TRUE.equals(order.getEmpty())) {
			redirectAttributes.addFlashAttribute("errorMessage",
					messageSource.getMessage("error.order.cart.empty", null, locale));
			return "redirect:/cart";
		}

		// バリデーションエラーの確認
		if (bindingResult.hasErrors()) {
			model.addAttribute("orderForm", orderForm);
			model.addAttribute("order", order);
			return "order-confirm";
		}

		// 注文確定処理の実行
		try {
			OrderModel placeOrderModel = toOrderModel(orderForm);
			Integer orderId = orderService.placeOrder(placeOrderModel);
			return "redirect:/orders/complete/" + orderId;
		} catch (BusinessException e) {
			model.addAttribute("orderForm", orderForm);
			model.addAttribute("order", order);
			model.addAttribute("errorMessage",
					messageSource.getMessage(e.getMessageKey(), e.getArgs(), locale));
			return "order-confirm";
		}
	}

	/**
	 * 注文完了画面の URL に注文IDがない場合は商品一覧へ戻す。
	 *
	 * @param redirectAttributes リダイレクト時のフラッシュ属性
	 * @return 商品一覧へのリダイレクト
	 */
	@GetMapping("/orders/complete")
	public String showOrderCompleteWithoutId(Locale locale, RedirectAttributes redirectAttributes) {
		redirectAttributes.addFlashAttribute("errorMessage",
				messageSource.getMessage("error.order.not.found", null, locale));
		return "redirect:/products";
	}

	/**
	 * 注文完了画面を表示する。
	 *
	 * @param orderId 注文ID
	 * @param model 画面表示用モデル
	 * @param redirectAttributes リダイレクト時のフラッシュ属性
	 * @return 注文完了画面のテンプレート名、または商品一覧へのリダイレクト
	 */
	@GetMapping("/orders/complete/{orderId}")
	public String showOrderComplete(
			@PathVariable Integer orderId,
			Model model,
			Locale locale,
			RedirectAttributes redirectAttributes) {
		// 注文完了画面用の注文情報を取得
		OrderModel completedOrder = orderService.getCompletedOrder(orderId);
		// 注文情報が存在しない場合は商品一覧へリダイレクト
		if (completedOrder == null) {
			redirectAttributes.addFlashAttribute("errorMessage",
					messageSource.getMessage("error.order.not.found", null, locale));
			return "redirect:/products";
		}

		model.addAttribute("completedOrder", completedOrder);
		return "order-complete";
	}

	private OrderModel toOrderModel(OrderForm orderForm) {
		OrderModel model = new OrderModel();
		model.setCustomerName(orderForm.getCustomerName());
		model.setPostalCode(orderForm.getPostalCode());
		model.setAddress(orderForm.getAddress());
		model.setPhoneNumber(orderForm.getPhoneNumber());
		return model;
	}
}
