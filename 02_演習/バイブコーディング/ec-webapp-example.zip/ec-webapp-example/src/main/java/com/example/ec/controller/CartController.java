package com.example.ec.controller;

import java.util.Locale;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.example.ec.controller.form.CartItemForm;
import com.example.ec.exception.BusinessException;
import com.example.ec.service.CartService;
import com.example.ec.service.model.CartModel;

/**
 * カート画面およびカート操作を制御するコントローラクラス。
 */
@Controller
public class CartController {

	/** カート操作に関するサービス。 */
	@Autowired
	private CartService cartService;

	/** メッセージ設定。 */
	@Autowired
	private MessageSource messageSource;

	/**
	 * カート画面を表示する。
	 *
	 * @param session HTTPセッション
	 * @param model 画面に受け渡すモデル
	 * @return カート画面テンプレート名
	 */
	@GetMapping("/cart")
	public String showCart(Model model) {
		// カート情報を取得して画面に設定
		CartModel cart = cartService.getCart();
		model.addAttribute("cart", cart);
		return "cart";
	}

	/**
	 * カート商品の数量を変更する。
	 *
	 * @param productId 商品ID
	 * @param form 数量更新フォーム
	 * @param bindingResult バリデーション結果
	 * @param redirectAttributes リダイレクト属性
	 * @return カート画面へのリダイレクト
	 */
	@PostMapping("/cart/items/{productId}/update")
	public String updateQuantity(
			@PathVariable Integer productId,
			@Validated CartItemForm form,
			BindingResult bindingResult,
			Model model,
			Locale locale,
			RedirectAttributes redirectAttributes) {

		// バリデーションエラーの確認
		if (bindingResult.hasErrors()) {
			model.addAttribute("errorMessage",
					messageSource.getMessage("error.cart.quantity.input", null, locale));
			model.addAttribute("cart", cartService.getCart());
			return "cart";
		}

		// 数量更新処理の実行
		try {
			cartService.updateQuantity(
					productId,
					form.getQuantity());
			redirectAttributes.addFlashAttribute("successMessage",
					messageSource.getMessage("success.cart.quantity.updated", null, locale));
		} catch (BusinessException e) {
			model.addAttribute("errorMessage",
					messageSource.getMessage(e.getMessageKey(), e.getArgs(), locale));
			model.addAttribute("cart", cartService.getCart());
			return "cart";
		}

		return "redirect:/cart";
	}

	/**
	 * カート商品を削除する。
	 *
	 * @param productId 商品ID
	 * @param redirectAttributes リダイレクト属性
	 * @return カート画面へのリダイレクト
	 */
	@PostMapping("/cart/items/{productId}/delete")
	public String deleteItem(
			@PathVariable Integer productId,
			Locale locale,
			RedirectAttributes redirectAttributes) {

		// カート商品削除処理の実行
		cartService.deleteItem(productId);
		redirectAttributes.addFlashAttribute("successMessage",
				messageSource.getMessage("success.cart.item.deleted", null, locale));

		return "redirect:/cart";
	}

}
