package com.example.ec.service.model;

import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 画面表示向けの商品情報モデル。
 */
@Data
@NoArgsConstructor
public class ProductModel {
	/** 商品ID。 */
	private Integer productId;

	/** 商品名。 */
	private String name;

	/** 商品説明。 */
	private String description;

	/** 価格。 */
	private Integer price;

	/** 在庫数。 */
	private Integer stock;

	/** 販売状態。 */
	private String status;

	/** 画像URL。 */
	private String imageUrl;
}
