package com.example.ec.exception;

/**
 * サービス層の業務例外クラス。
 *
 * <p>メッセージIDと置換パラメータを保持し、
 * Controller 側で {@code MessageSource} を使ってメッセージ文字列に解決する。</p>
 */
public class BusinessException extends IllegalArgumentException {

    /** メッセージID（messages.properties のキー）。 */
    private final String messageKey;

    /** メッセージ置換パラメータ（{0}, {1} などに対応）。 */
    private final Object[] args;

    /**
     * メッセージIDとパラメータを指定して例外を生成する。
     *
     * @param messageKey messages.properties のキー
     * @param args       メッセージ置換パラメータ
     */
    public BusinessException(String messageKey, Object... args) {
        super(messageKey);
        this.messageKey = messageKey;
        this.args = args;
    }

    /**
     * メッセージIDを返す。
     *
     * @return メッセージID
     */
    public String getMessageKey() {
        return messageKey;
    }

    /**
     * メッセージ置換パラメータを返す。
     *
     * @return 置換パラメータ配列
     */
    public Object[] getArgs() {
        return args;
    }
}
