package com.example.ec.repository.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * カート明細エンティティ。
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class CartItemEntity {

    /** 商品ID。 */
    private Integer productId;

    /** 数量。 */
    private Integer quantity;
}
