package com.example.ec.repository.entity;

import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * productsテーブルに対応するエンティティクラス。
 */
@Data
@NoArgsConstructor
public class ProductEntity {

    /** 商品ID。 */
    private Integer productId;

    /** 商品名。 */
    private String name;

    /** 商品説明。 */
    private String description;

    /** 価格。 */
    private Integer price;

    /** 在庫数。 */
    private Integer stock;

    /** 販売状態（ON_SALE / STOPPED）。 */
    private String status;

    /** 画像URL。 */
    private String imageUrl;
}
