package com.example.ec.repository;

import org.apache.ibatis.annotations.Mapper;

import com.example.ec.repository.entity.OrderEntity;

/**
 * 注文情報のデータアクセスを提供するRepository。
 */
@Mapper
public interface OrderRepository {

	/**
	 * 注文情報を登録する。
	 *
	 * @param order 注文情報
	 * @return 登録件数
	 */
	int insert(OrderEntity order);

	/**
	 * 注文IDに一致する注文情報を取得する。
	 *
	 * @param orderId 注文ID
	 * @return 注文情報
	 */
	OrderEntity findByOrderId(Integer orderId);
}
