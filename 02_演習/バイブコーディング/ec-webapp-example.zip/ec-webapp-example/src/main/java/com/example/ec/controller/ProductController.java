package com.example.ec.controller;

import java.net.URI;
import java.util.Locale;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.example.ec.controller.form.ProductListItemForm;
import com.example.ec.exception.BusinessException;
import com.example.ec.service.CartService;
import com.example.ec.service.ProductService;
import com.example.ec.service.model.ProductModel;

/**
 * 商品一覧画面の表示を制御するコントローラクラス。
 */
@Controller
public class ProductController {

    /** 商品情報に関するサービス。 */
    @Autowired
    private ProductService productService;

    /** カート操作に関するサービス。 */
    @Autowired
    private CartService cartService;

    /** メッセージ設定。 */
    @Autowired
    private MessageSource messageSource;

    /**
     * 商品画面で共通利用するカート追加フォームを用意する。
     *
     * @return カート追加フォーム
     */
    @ModelAttribute("productListItemForm")
    public ProductListItemForm setUpProductListItemForm() {
        return new ProductListItemForm();
    }

    /**
     * トップページへのアクセスを商品一覧画面にリダイレクトする。
     *
     * @return 商品一覧画面へのリダイレクト
     */
    @GetMapping("/")
    public String redirectToProducts() {
        return "redirect:/products";
    }

    /**
     * 商品一覧画面を表示する。
     *
     * @param model 画面に受け渡すモデル
     * @return 商品一覧画面テンプレート名
     */
    @GetMapping("/products")
    public String showProducts(Model model) {
        // 販売中商品一覧の取得と画面への設定
        model.addAttribute("products", productService.getOnSaleProducts());
        return "products";
    }

    /**
     * 商品詳細画面を表示する。
     *
     * @param productId 商品ID
     * @param model 画面に受け渡すモデル
     * @return 商品詳細画面テンプレート名
     */
    @GetMapping("/products/{productId}")
    public String showProductDetail(@PathVariable Integer productId, Model model) {
        // 商品詳細情報の取得
        ProductModel product = productService.getOnSaleProduct(productId);

        // 商品が存在しない場合は商品一覧へリダイレクト
        if (product == null) {
            return "redirect:/products";
        }

        model.addAttribute("product", product);
        return "products-detail";
    }

    /**
     * 商品をカートに追加する。
     *
     * @param form カート追加フォーム
     * @param bindingResult バリデーション結果
     * @param referer リクエスト元URL
     * @param redirectAttributes リダイレクト属性
     * @return 追加元画面へのリダイレクト
     */
    @PostMapping("/cart/items")
    public String addItem(
            @Validated ProductListItemForm form,
            BindingResult bindingResult,
            @RequestHeader(value = "Referer", required = false) String referer,
            Model model,
            Locale locale,
            RedirectAttributes redirectAttributes) {

        String redirectPath = resolveReturnPath(referer);

        // バリデーションエラーの確認
        if (bindingResult.hasErrors()) {
            return renderReturnView(redirectPath, form.getProductId(), model,
                    messageSource.getMessage("error.cart.quantity.input", null, locale));
        }

        // カート追加処理の実行
        try {
            cartService.addItem(form.getProductId(), form.getQuantity());
            redirectAttributes.addFlashAttribute("successMessage",
                    messageSource.getMessage("success.cart.item.added", null, locale));
        } catch (BusinessException e) {
            return renderReturnView(redirectPath, form.getProductId(), model,
                    messageSource.getMessage(e.getMessageKey(), e.getArgs(), locale));
        }

        return "redirect:" + redirectPath;
    }

    private String renderReturnView(String returnPath, Integer productId, Model model, String errorMessage) {
        model.addAttribute("errorMessage", errorMessage);
        if ("/products".equals(returnPath)) {
            model.addAttribute("products", productService.getOnSaleProducts());
            return "products";
        }

        Integer detailProductId = extractProductId(returnPath, productId);
        ProductModel product = detailProductId == null ? null : productService.getOnSaleProduct(detailProductId);
        if (product == null) {
            model.addAttribute("products", productService.getOnSaleProducts());
            return "products";
        }

        model.addAttribute("product", product);
        return "products-detail";
    }

    private Integer extractProductId(String path, Integer fallbackProductId) {
        if (path == null) {
            return fallbackProductId;
        }
        if (path.matches("^/products/\\d+$")) {
            return Integer.valueOf(path.substring(path.lastIndexOf('/') + 1));
        }
        return fallbackProductId;
    }

    private String resolveReturnPath(String referer) {
        if (referer == null || referer.isBlank()) {
            return "/products";
        }

        String path = extractPath(referer);
        if (path.equals("/products") || path.matches("^/products/\\d+$")) {
            return path;
        }

        return "/products";
    }

    private String extractPath(String referer) {
        try {
            URI uri = URI.create(referer);
            return uri.getPath() == null ? "" : uri.getPath();
        } catch (IllegalArgumentException e) {
            return "";
        }
    }
}
