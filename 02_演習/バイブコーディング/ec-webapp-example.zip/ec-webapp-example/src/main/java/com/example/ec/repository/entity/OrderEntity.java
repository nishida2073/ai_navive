package com.example.ec.repository.entity;

import java.time.LocalDateTime;

import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * ordersテーブルに対応する注文ヘッダエンティティ。
 */
@Data
@NoArgsConstructor
public class OrderEntity {
	/** 注文ID。 */
	private Integer orderId;

	/** 注文者氏名。 */
	private String customerName;

	/** 郵便番号。 */
	private String postalCode;

	/** 住所。 */
	private String address;

	/** 電話番号。 */
	private String phoneNumber;

	/** 注文合計金額。 */
	private Integer totalAmount;

	/** 注文日時。 */
	private LocalDateTime orderedAt;
}
