package com.example.ec.service.model;

import java.time.LocalDateTime;
import java.util.List;

import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 注文確認画面全体で使用するモデル。
 */
@Data
@NoArgsConstructor
public class OrderModel {
	/** 注文番号。 */
	private Integer orderId;

	/** 注文者氏名。 */
	private String customerName;

	/** 郵便番号。 */
	private String postalCode;

	/** 住所。 */
	private String address;

	/** 電話番号。 */
	private String phoneNumber;

	/** 注文日時。 */
	private LocalDateTime orderedAt;

	/** 注文予定商品の一覧。 */
	private List<OrderItemModel> items;

	/** 合計数量。 */
	private Integer totalQuantity;

	/** 合計金額。 */
	private Integer totalAmount;

	/** カートが空かどうか。 */
	private Boolean empty;
}
