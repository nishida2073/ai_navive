package com.example.ec.controller.form;

import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * カート明細の入力値を受け取るフォームクラス。
 */
@Data
@NoArgsConstructor
public class CartItemForm {

	/** 数量（1〜99）。 */
	@NotNull
	@Min(1)
	@Max(99)
	private Integer quantity;
}
