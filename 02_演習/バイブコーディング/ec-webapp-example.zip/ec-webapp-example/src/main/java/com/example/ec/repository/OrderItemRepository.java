package com.example.ec.repository;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.example.ec.repository.entity.OrderItemEntity;

/**
 * 注文明細情報のデータアクセスを提供するRepository。
 */
@Mapper
public interface OrderItemRepository {

	/**
	 * 注文明細を登録する。
	 *
	 * @param orderItem 注文明細情報
	 * @return 登録件数
	 */
	int insert(OrderItemEntity orderItem);

	/**
	 * 指定した注文IDの注文明細一覧を取得する。
	 *
	 * @param orderId 注文ID
	 * @return 注文明細一覧
	 */
	List<OrderItemEntity> findByOrderId(@Param("orderId") Integer orderId);
}
