package com.example.ec.service.model;

import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * カート1行分の表示情報を保持するモデル。
 */
@Data
@NoArgsConstructor
public class CartItemModel {

	/** カート明細ID。 */
	private Integer cartItemId;

	/** 商品ID。 */
	private Integer productId;

	/** 商品名。 */
	private String name;

	/** 画像URL。 */
	private String imageUrl;

	/** 単価。 */
	private Integer price;

	/** 在庫数。 */
	private Integer stock;

	/** 数量。 */
	private Integer quantity;

	/** 小計（price * quantity）。 */
	private Integer subtotal;
}
