package com.example.ec.repository;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.example.ec.repository.entity.ProductEntity;

/**
 * 商品情報のデータアクセスを提供するRepository。
 */
@Mapper
public interface ProductRepository {

    /**
     * 販売中（ON_SALE）の商品を全件取得する。
     *
     * @return 販売中商品の一覧
     */
    List<ProductEntity> findOnSaleProducts();

    /**
     * 指定した商品IDに一致する販売中（ON_SALE）の商品を1件取得する。
     *
     * @param productId 商品ID
     * @return 商品情報
     */
    ProductEntity findOnSaleProductById(@Param("productId") Integer productId);

    /**
     * 指定した商品ID一覧に一致する販売中（ON_SALE）の商品を取得する。
     *
     * @param productIds 商品ID一覧
     * @return 販売中商品の一覧
     */
    List<ProductEntity> findOnSaleProductsByIds(@Param("productIds") List<Integer> productIds);

    /**
     * 指定した商品IDの在庫を注文数量分だけ減らす。
     *
     * @param productId 商品ID
     * @param quantity 注文数量
     * @return 更新件数
     */
    int decreaseStock(
	    @Param("productId") Integer productId,
	    @Param("quantity") Integer quantity);
}
