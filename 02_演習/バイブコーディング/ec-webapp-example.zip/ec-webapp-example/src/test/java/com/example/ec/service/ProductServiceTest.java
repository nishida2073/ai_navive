package com.example.ec.service;

import static org.assertj.core.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.util.Collections;
import java.util.List;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.dao.DataRetrievalFailureException;

import com.example.ec.repository.ProductRepository;
import com.example.ec.repository.entity.ProductEntity;
import com.example.ec.service.model.ProductModel;

/**
 * {@link ProductService#getOnSaleProducts()} の単体テストクラス。
 *
 * <p>データベースには接続せず、{@link ProductRepository} をMockに置き換えて
 * Service層のビジネスロジック（Entity→Model変換）を独立して検証する。</p>
 *
 * <p>テスト技法：同値分析、境界値分析、実行網羅（C0）、分岐網羅（C1）</p>
 */
@ExtendWith(MockitoExtension.class)
class ProductServiceTest {

    /** テスト対象の Service（依存はMockに置き換え）。 */
    @InjectMocks
    private ProductService productService;

    /** ProductRepository のモック。 */
    @Mock
    private ProductRepository productRepository;

    // =========================================================================
    // S-01: Repositoryが2件返した場合、2件のModelリストに変換される（C0・同値）
    // =========================================================================

    /**
     * S-01: Repositoryが返したEntityリストがModelリストに変換されることを検証する。
     *
     * <p>テスト技法：C0（getOnSaleProductsとtoModelの全文実行）、同値分析（正常クラス）</p>
     */
    @Test
    @DisplayName("S-01: Repositoryが2件のEntityを返した場合、2件のProductModelリストが返る")
    void s01_getOnSaleProducts_returnsConvertedModelList() {
        // Arrange
        ProductEntity entity1 = buildEntity(1, "商品A", "説明A", 1000, 10, "ON_SALE", "/img/1.png");
        ProductEntity entity2 = buildEntity(2, "商品B", "説明B", 2000,  5, "ON_SALE", "/img/2.png");
        when(productRepository.findOnSaleProducts()).thenReturn(List.of(entity1, entity2));

        // Act
        List<ProductModel> result = productService.getOnSaleProducts();

        // Assert
        assertThat(result).hasSize(2);
    }

    // =========================================================================
    // S-02: Repositoryが空リストを返した場合、空のModelリストが返る（境界値：件数ゼロ）
    // =========================================================================

    /**
     * S-02: Repositoryが空リストを返した場合に、空の（nullでない）Modelリストが返ることを検証する。
     *
     * <p>テスト技法：境界値分析（件数ゼロ）</p>
     */
    @Test
    @DisplayName("S-02: Repositoryが空リストを返した場合、nullではなく空のModelリストが返る")
    void s02_getOnSaleProducts_returnsEmptyListWhenRepositoryReturnsEmpty() {
        // Arrange
        when(productRepository.findOnSaleProducts()).thenReturn(Collections.emptyList());

        // Act
        List<ProductModel> result = productService.getOnSaleProducts();

        // Assert
        assertThat(result)
                .isNotNull()
                .isEmpty();
    }

    // =========================================================================
    // S-03: Repositoryが1件返した場合、1件のModelリストが返る（境界値：件数最小値）
    // =========================================================================

    /**
     * S-03: Repositoryが1件のEntityを返した場合に、1件のModelリストが返ることを検証する。
     *
     * <p>テスト技法：境界値分析（件数最小値 = 1）</p>
     */
    @Test
    @DisplayName("S-03: Repositoryが1件のEntityを返した場合、1件のProductModelリストが返る")
    void s03_getOnSaleProducts_returnsOneItemList() {
        // Arrange
        ProductEntity entity = buildEntity(1, "商品A", "説明A", 1000, 5, "ON_SALE", "/img/1.png");
        when(productRepository.findOnSaleProducts()).thenReturn(List.of(entity));

        // Act
        List<ProductModel> result = productService.getOnSaleProducts();

        // Assert
        assertThat(result).hasSize(1);
    }

    // =========================================================================
    // S-04: 変換後のProductModelにproductIdが正しくセットされる（C0：toModelフィールド変換）
    // =========================================================================

    /**
     * S-04: toModel変換後のProductModelにproductIdが正しくセットされることを検証する。
     *
     * <p>テスト技法：C0（toModel内の setProductId 実行確認）</p>
     */
    @Test
    @DisplayName("S-04: 変換後のProductModelのproductIdが、EntityのproductIdと一致する")
    void s04_getOnSaleProducts_productIdIsMappedCorrectly() {
        // Arrange
        ProductEntity entity = buildEntity(42, "商品", "説明", 1000, 5, "ON_SALE", "/img/1.png");
        when(productRepository.findOnSaleProducts()).thenReturn(List.of(entity));

        // Act
        List<ProductModel> result = productService.getOnSaleProducts();

        // Assert
        assertThat(result.get(0).getProductId()).isEqualTo(42);
    }

    // =========================================================================
    // S-05: 変換後のProductModelにnameが正しくセットされる（C0）
    // =========================================================================

    /**
     * S-05: toModel変換後のProductModelにnameが正しくセットされることを検証する。
     *
     * <p>テスト技法：C0（toModel内の setName 実行確認）</p>
     */
    @Test
    @DisplayName("S-05: 変換後のProductModelのnameが、Entityのnameと一致する")
    void s05_getOnSaleProducts_nameIsMappedCorrectly() {
        // Arrange
        ProductEntity entity = buildEntity(1, "ワイヤレスイヤホン", "説明", 1000, 5, "ON_SALE", "/img/1.png");
        when(productRepository.findOnSaleProducts()).thenReturn(List.of(entity));

        // Act
        List<ProductModel> result = productService.getOnSaleProducts();

        // Assert
        assertThat(result.get(0).getName()).isEqualTo("ワイヤレスイヤホン");
    }

    // =========================================================================
    // S-06: 変換後のProductModelにpriceが正しくセットされる（C0）
    // =========================================================================

    /**
     * S-06: toModel変換後のProductModelにpriceが正しくセットされることを検証する。
     *
     * <p>テスト技法：C0（toModel内の setPrice 実行確認）</p>
     */
    @Test
    @DisplayName("S-06: 変換後のProductModelのpriceが、Entityのpriceと一致する")
    void s06_getOnSaleProducts_priceIsMappedCorrectly() {
        // Arrange
        ProductEntity entity = buildEntity(1, "商品", "説明", 5980, 5, "ON_SALE", "/img/1.png");
        when(productRepository.findOnSaleProducts()).thenReturn(List.of(entity));

        // Act
        List<ProductModel> result = productService.getOnSaleProducts();

        // Assert
        assertThat(result.get(0).getPrice()).isEqualTo(5980);
    }

    // =========================================================================
    // S-07: stock=0のEntityが変換されてModelにstock=0がセットされる（境界値：stock=0）
    // =========================================================================

    /**
     * S-07: stock=0 のEntityがtoModelで変換されてModelにstock=0がセットされることを検証する。
     *
     * <p>テスト技法：境界値分析（在庫数ゼロ）、C0（setStock 実行確認）</p>
     */
    @Test
    @DisplayName("S-07: stock=0のEntityを変換した場合、ProductModelのstockも0になる（境界値：在庫ゼロ）")
    void s07_getOnSaleProducts_stockZeroIsMappedCorrectly() {
        // Arrange
        ProductEntity entity = buildEntity(1, "商品", "説明", 1000, 0, "ON_SALE", "/img/1.png");
        when(productRepository.findOnSaleProducts()).thenReturn(List.of(entity));

        // Act
        List<ProductModel> result = productService.getOnSaleProducts();

        // Assert
        assertThat(result.get(0).getStock()).isEqualTo(0);
    }

    // =========================================================================
    // S-08: stock=1のEntityが変換されてModelにstock=1がセットされる（境界値：stock=1）
    // =========================================================================

    /**
     * S-08: stock=1 のEntityがtoModelで変換されてModelにstock=1がセットされることを検証する。
     *
     * <p>テスト技法：境界値分析（在庫数最小値 = 1）</p>
     */
    @Test
    @DisplayName("S-08: stock=1のEntityを変換した場合、ProductModelのstockも1になる（境界値：在庫最小値）")
    void s08_getOnSaleProducts_stockOneIsMappedCorrectly() {
        // Arrange
        ProductEntity entity = buildEntity(1, "商品", "説明", 1000, 1, "ON_SALE", "/img/1.png");
        when(productRepository.findOnSaleProducts()).thenReturn(List.of(entity));

        // Act
        List<ProductModel> result = productService.getOnSaleProducts();

        // Assert
        assertThat(result.get(0).getStock()).isEqualTo(1);
    }

    // =========================================================================
    // S-09: 変換後のProductModelにstatusが正しくセットされる（C0）
    // =========================================================================

    /**
     * S-09: toModel変換後のProductModelにstatusが正しくセットされることを検証する。
     *
     * <p>テスト技法：C0（toModel内の setStatus 実行確認）</p>
     */
    @Test
    @DisplayName("S-09: 変換後のProductModelのstatusが、Entityのstatusと一致する")
    void s09_getOnSaleProducts_statusIsMappedCorrectly() {
        // Arrange
        ProductEntity entity = buildEntity(1, "商品", "説明", 1000, 5, "ON_SALE", "/img/1.png");
        when(productRepository.findOnSaleProducts()).thenReturn(List.of(entity));

        // Act
        List<ProductModel> result = productService.getOnSaleProducts();

        // Assert
        assertThat(result.get(0).getStatus()).isEqualTo("ON_SALE");
    }

    // =========================================================================
    // S-10: 変換後のProductModelにimageUrlが正しくセットされる（C0）
    // =========================================================================

    /**
     * S-10: toModel変換後のProductModelにimageUrlが正しくセットされることを検証する。
     *
     * <p>テスト技法：C0（toModel内の setImageUrl 実行確認）</p>
     */
    @Test
    @DisplayName("S-10: 変換後のProductModelのimageUrlが、EntityのimageUrlと一致する")
    void s10_getOnSaleProducts_imageUrlIsMappedCorrectly() {
        // Arrange
        ProductEntity entity = buildEntity(1, "商品", "説明", 1000, 5, "ON_SALE", "/images/products/1.png");
        when(productRepository.findOnSaleProducts()).thenReturn(List.of(entity));

        // Act
        List<ProductModel> result = productService.getOnSaleProducts();

        // Assert
        assertThat(result.get(0).getImageUrl()).isEqualTo("/images/products/1.png");
    }

    // =========================================================================
    // S-11: Repositoryが返した件数とModelリストの件数が一致する（C0）
    // =========================================================================

    /**
     * S-11: Repositoryが返したEntityの件数とModelリストのサイズが一致することを検証する。
     *
     * <p>テスト技法：C0（stream().map().toList() の件数変換確認）</p>
     */
    @Test
    @DisplayName("S-11: Repositoryが3件のEntityを返した場合、返却されるModelリストのサイズも3である")
    void s11_getOnSaleProducts_listSizeMatchesRepositoryResult() {
        // Arrange
        ProductEntity e1 = buildEntity(1, "商品A", "説明A", 1000, 5, "ON_SALE", "/img/1.png");
        ProductEntity e2 = buildEntity(2, "商品B", "説明B", 2000, 3, "ON_SALE", "/img/2.png");
        ProductEntity e3 = buildEntity(3, "商品C", "説明C", 3000, 0, "ON_SALE", "/img/3.png");
        when(productRepository.findOnSaleProducts()).thenReturn(List.of(e1, e2, e3));

        // Act
        List<ProductModel> result = productService.getOnSaleProducts();

        // Assert
        assertThat(result).hasSize(3);
    }

    // =========================================================================
    // S-12: Repositoryが例外をスローした場合、例外が呼び出し元に伝播する（C1：異常系分岐）
    // =========================================================================

    /**
     * S-12: Repositoryが例外をスローした場合に、例外がService層を素通りして
     * 呼び出し元に伝播することを検証する。
     *
     * <p>テスト技法：C1（例外発生時の分岐）、異常系</p>
     */
    @Test
    @DisplayName("S-12: Repositoryがデータアクセス例外をスローした場合、同じ例外が呼び出し元に伝播する")
    void s12_getOnSaleProducts_propagatesExceptionFromRepository() {
        // Arrange: Repository が DataRetrievalFailureException をスローするよう設定
        DataRetrievalFailureException expectedException =
                new DataRetrievalFailureException("DBアクセスエラー");
        when(productRepository.findOnSaleProducts()).thenThrow(expectedException);

        // Act & Assert: Service が例外を握りつぶさず伝播させることを確認
        assertThatThrownBy(() -> productService.getOnSaleProducts())
                .isInstanceOf(DataRetrievalFailureException.class)
                .hasMessage("DBアクセスエラー");
    }

    // =========================================================================
    // S-13: findOnSaleProductsがちょうど1回呼ばれることを確認（C0：メソッド呼び出し検証）
    // =========================================================================

    /**
     * S-13: getOnSaleProducts()の呼び出し時にRepository#findOnSaleProductsが
     * ちょうど1回だけ呼ばれることを検証する。
     *
     * <p>テスト技法：C0（Mockitoのverifyによるメソッド呼び出し確認）</p>
     */
    @Test
    @DisplayName("S-13: getOnSaleProducts()呼び出し時に、Repository#findOnSaleProductsがちょうど1回呼ばれる")
    void s13_getOnSaleProducts_callsRepositoryExactlyOnce() {
        // Arrange
        when(productRepository.findOnSaleProducts()).thenReturn(Collections.emptyList());

        // Act
        productService.getOnSaleProducts();

        // Assert: findOnSaleProducts がちょうど1回だけ呼ばれたことを確認
        verify(productRepository, times(1)).findOnSaleProducts();
        // 他のRepositoryメソッドが呼ばれていないことを確認
        verifyNoMoreInteractions(productRepository);
    }

    /**
     * S-14: findOnSaleProductById が1件返した場合に ProductModel へ変換されることを検証する。
     */
    @Test
    @DisplayName("S-14: findOnSaleProductById がEntityを返した場合、対応するProductModelが返る")
    void s14_getOnSaleProduct_returnsConvertedModel() {
        ProductEntity entity = buildEntity(10, "商品X", "説明X", 1234, 8, "ON_SALE", "/img/x.png");
        when(productRepository.findOnSaleProductById(10)).thenReturn(entity);

        ProductModel result = productService.getOnSaleProduct(10);

        assertThat(result).isNotNull();
        assertThat(result.getProductId()).isEqualTo(10);
        assertThat(result.getName()).isEqualTo("商品X");
    }

    /**
     * S-15: findOnSaleProductById が null を返した場合に null が返ることを検証する。
     */
    @Test
    @DisplayName("S-15: findOnSaleProductById がnullを返した場合、getOnSaleProduct も null を返す")
    void s15_getOnSaleProduct_returnsNullWhenRepositoryReturnsNull() {
        when(productRepository.findOnSaleProductById(9999)).thenReturn(null);

        ProductModel result = productService.getOnSaleProduct(9999);

        assertThat(result).isNull();
    }

    /**
     * S-16: 商品説明が正しくマッピングされることを検証する。
     */
    @Test
    @DisplayName("S-16: getOnSaleProduct で description が正しくマッピングされる")
    void s16_getOnSaleProduct_descriptionIsMappedCorrectly() {
        ProductEntity entity = buildEntity(1, "商品", "詳細説明テキスト", 1000, 5, "ON_SALE", "/img/1.png");
        when(productRepository.findOnSaleProductById(1)).thenReturn(entity);

        ProductModel result = productService.getOnSaleProduct(1);

        assertThat(result).isNotNull();
        assertThat(result.getDescription()).isEqualTo("詳細説明テキスト");
    }

    /**
     * S-17: 価格・在庫・ステータス・画像URLが正しくマッピングされることを検証する。
     */
    @Test
    @DisplayName("S-17: getOnSaleProduct で価格・在庫・ステータス・画像URLが正しくマッピングされる")
    void s17_getOnSaleProduct_fieldsAreMappedCorrectly() {
        ProductEntity entity = buildEntity(3, "USB-Cハブ", "5in1モデル", 2980, 0, "ON_SALE", "/images/products/3.png");
        when(productRepository.findOnSaleProductById(3)).thenReturn(entity);

        ProductModel result = productService.getOnSaleProduct(3);

        assertThat(result).isNotNull();
        assertThat(result.getPrice()).isEqualTo(2980);
        assertThat(result.getStock()).isZero();
        assertThat(result.getStatus()).isEqualTo("ON_SALE");
        assertThat(result.getImageUrl()).isEqualTo("/images/products/3.png");
    }

    /**
     * S-18: Repository 例外が伝播することを検証する。
     */
    @Test
    @DisplayName("S-18: findOnSaleProductById で例外が発生した場合、例外が伝播する")
    void s18_getOnSaleProduct_propagatesExceptionFromRepository() {
        when(productRepository.findOnSaleProductById(1))
                .thenThrow(new DataRetrievalFailureException("findById error"));

        assertThatThrownBy(() -> productService.getOnSaleProduct(1))
                .isInstanceOf(DataRetrievalFailureException.class)
                .hasMessage("findById error");
    }

    /**
     * S-19: Repository の対象メソッドが1回だけ呼ばれることを検証する。
     */
    @Test
    @DisplayName("S-19: getOnSaleProduct 呼び出し時に findOnSaleProductById が1回だけ呼ばれる")
    void s19_getOnSaleProduct_callsRepositoryExactlyOnce() {
        when(productRepository.findOnSaleProductById(5)).thenReturn(buildEntity(5, "商品", "説明", 1000, 1, "ON_SALE", "/img/5.png"));

        productService.getOnSaleProduct(5);

        verify(productRepository, times(1)).findOnSaleProductById(5);
        verifyNoMoreInteractions(productRepository);
    }

    // =========================================================================
    // ヘルパーメソッド
    // =========================================================================

    /**
     * テストデータ用の {@link ProductEntity} を生成するヘルパーメソッド。
     *
     * @param productId   商品ID
     * @param name        商品名
     * @param description 商品説明
     * @param price       価格
     * @param stock       在庫数
     * @param status      販売状態
     * @param imageUrl    画像URL
     * @return 生成した ProductEntity
     */
    private ProductEntity buildEntity(int productId, String name, String description,
            int price, int stock, String status, String imageUrl) {
        ProductEntity entity = new ProductEntity();
        entity.setProductId(productId);
        entity.setName(name);
        entity.setDescription(description);
        entity.setPrice(price);
        entity.setStock(stock);
        entity.setStatus(status);
        entity.setImageUrl(imageUrl);
        return entity;
    }
}
