package com.example.ec.repository;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.time.LocalDateTime;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.jdbc.core.JdbcTemplate;

import com.example.ec.repository.entity.OrderEntity;
import com.example.ec.repository.entity.OrderItemEntity;

/**
 * {@link OrderItemRepository} のテストクラス。
 */
@SpringBootTest
@DisplayName("OrderItemRepositoryテスト")
class OrderItemRepositoryTest {

    /** テストデータ操作用。 */
    @Autowired
    private JdbcTemplate jdbcTemplate;

    /** 注文Repository。 */
    @Autowired
    private OrderRepository orderRepository;

    /** テスト対象。 */
    @Autowired
    private OrderItemRepository orderItemRepository;

    /**
     * テスト前にテーブルを初期化する。
     */
    @BeforeEach
    void setUp() {
        jdbcTemplate.execute("DELETE FROM order_items");
        jdbcTemplate.execute("DELETE FROM orders");
        jdbcTemplate.execute("DELETE FROM cart_items");
        jdbcTemplate.execute("DELETE FROM products");

        jdbcTemplate.update(
                "INSERT INTO products (product_id, name, description, price, stock, status, image_url) VALUES (?, ?, ?, ?, ?, ?, ?)",
                1, "ワイヤレスイヤホン", "ノイズキャンセリング対応", 5980, 10, "ON_SALE", "/images/products/1.png");
    }

    /**
     * 注文明細を登録し、注文IDで取得できることを検証する。
     */
    @Test
    @DisplayName("insert/findByOrderId: 登録した注文明細を取得できる")
    void insert_and_findByOrderId() {
        OrderEntity order = new OrderEntity();
        order.setCustomerName("山田太郎");
        order.setPostalCode("1234567");
        order.setAddress("東京都千代田区1-1");
        order.setPhoneNumber("09012345678");
        order.setTotalAmount(5980);
        order.setOrderedAt(LocalDateTime.now());
        orderRepository.insert(order);

        OrderItemEntity item = new OrderItemEntity();
        item.setOrderId(order.getOrderId());
        item.setProductId(1);
        item.setProductName("ワイヤレスイヤホン");
        item.setUnitPrice(5980);
        item.setQuantity(1);
        item.setSubtotal(5980);

        int inserted = orderItemRepository.insert(item);
        List<OrderItemEntity> result = orderItemRepository.findByOrderId(order.getOrderId());

        assertEquals(1, inserted);
        assertNotNull(result);
        assertEquals(1, result.size());
        assertEquals(1, result.get(0).getProductId());
        assertEquals("ワイヤレスイヤホン", result.get(0).getProductName());
    }

    /**
     * 注文明細が存在しない注文IDでは空リストが返ることを検証する。
     */
    @Test
    @DisplayName("findByOrderId: 注文明細がない注文IDでは空リストを返す")
    void findByOrderId_returnsEmptyListWhenNoItems() {
        List<OrderItemEntity> result = orderItemRepository.findByOrderId(9999);
        assertNotNull(result);
        assertTrue(result.isEmpty());
    }

    /**
     * 注文明細1件（境界値 quantity=1）を検証する。
     */
    @Test
    @DisplayName("insert/findByOrderId: quantity=1（下限）の注文明細を保持できる")
    void insert_and_findByOrderId_quantityMinBoundary() {
        OrderEntity order = createOrder("山田太郎", "1234567", "東京都千代田区1-1", "09012345678", 5980);

        OrderItemEntity item = new OrderItemEntity();
        item.setOrderId(order.getOrderId());
        item.setProductId(1);
        item.setProductName("ワイヤレスイヤホン");
        item.setUnitPrice(5980);
        item.setQuantity(1);
        item.setSubtotal(5980);
        orderItemRepository.insert(item);

        List<OrderItemEntity> result = orderItemRepository.findByOrderId(order.getOrderId());

        assertNotNull(result);
        assertEquals(1, result.size());
        assertEquals(1, result.get(0).getQuantity());
    }

    /**
     * 注文明細1件（境界値 quantity=99）を検証する。
     */
    @Test
    @DisplayName("insert/findByOrderId: quantity=99（上限想定）を保持できる")
    void insert_and_findByOrderId_quantityMaxBoundary() {
        OrderEntity order = createOrder("山田太郎", "1234567", "東京都千代田区1-1", "09012345678", 592020);

        OrderItemEntity item = new OrderItemEntity();
        item.setOrderId(order.getOrderId());
        item.setProductId(1);
        item.setProductName("ワイヤレスイヤホン");
        item.setUnitPrice(5980);
        item.setQuantity(99);
        item.setSubtotal(592020);
        orderItemRepository.insert(item);

        List<OrderItemEntity> result = orderItemRepository.findByOrderId(order.getOrderId());

        assertNotNull(result);
        assertEquals(1, result.size());
        assertEquals(99, result.get(0).getQuantity());
    }

    /**
     * 単価0円の境界値を検証する。
     */
    @Test
    @DisplayName("insert/findByOrderId: unitPrice=0（下限）とsubtotal=0を保持できる")
    void insert_and_findByOrderId_unitPriceZeroBoundary() {
        OrderEntity order = createOrder("山田太郎", "1234567", "東京都千代田区1-1", "09012345678", 0);

        OrderItemEntity item = new OrderItemEntity();
        item.setOrderId(order.getOrderId());
        item.setProductId(1);
        item.setProductName("無料サンプル");
        item.setUnitPrice(0);
        item.setQuantity(1);
        item.setSubtotal(0);
        orderItemRepository.insert(item);

        List<OrderItemEntity> result = orderItemRepository.findByOrderId(order.getOrderId());

        assertNotNull(result);
        assertEquals(1, result.size());
        assertEquals(0, result.get(0).getUnitPrice());
        assertEquals(0, result.get(0).getSubtotal());
    }

    /**
     * 複数明細の取得を検証する。
     */
    @Test
    @DisplayName("findByOrderId: 同一注文の複数明細を取得できる")
    void findByOrderId_returnsMultipleItemsForSameOrder() {
        jdbcTemplate.update(
                "INSERT INTO products (product_id, name, description, price, stock, status, image_url) VALUES (?, ?, ?, ?, ?, ?, ?)",
                2, "ゲーミングマウス", "6ボタン搭載", 3980, 5, "ON_SALE", "/images/products/2.png");

        OrderEntity order = createOrder("山田太郎", "1234567", "東京都千代田区1-1", "09012345678", 9960);

        OrderItemEntity item1 = new OrderItemEntity();
        item1.setOrderId(order.getOrderId());
        item1.setProductId(1);
        item1.setProductName("ワイヤレスイヤホン");
        item1.setUnitPrice(5980);
        item1.setQuantity(1);
        item1.setSubtotal(5980);
        orderItemRepository.insert(item1);

        OrderItemEntity item2 = new OrderItemEntity();
        item2.setOrderId(order.getOrderId());
        item2.setProductId(2);
        item2.setProductName("ゲーミングマウス");
        item2.setUnitPrice(3980);
        item2.setQuantity(1);
        item2.setSubtotal(3980);
        orderItemRepository.insert(item2);

        List<OrderItemEntity> result = orderItemRepository.findByOrderId(order.getOrderId());

        assertNotNull(result);
        assertEquals(2, result.size());
    }

    /**
     * 異なる注文の明細が混在していても指定注文IDのみ取得できることを検証する。
     */
    @Test
    @DisplayName("findByOrderId: 異なる注文の明細が混在していても指定注文IDのみ返る")
    void findByOrderId_filtersItemsByOrderId() {
        OrderEntity order1 = createOrder("山田太郎", "1234567", "東京都千代田区1-1", "09012345678", 5980);
        OrderEntity order2 = createOrder("佐藤花子", "7654321", "大阪府大阪市1-1", "08012345678", 5980);

        OrderItemEntity item1 = new OrderItemEntity();
        item1.setOrderId(order1.getOrderId());
        item1.setProductId(1);
        item1.setProductName("ワイヤレスイヤホン");
        item1.setUnitPrice(5980);
        item1.setQuantity(1);
        item1.setSubtotal(5980);
        orderItemRepository.insert(item1);

        OrderItemEntity item2 = new OrderItemEntity();
        item2.setOrderId(order2.getOrderId());
        item2.setProductId(1);
        item2.setProductName("ワイヤレスイヤホン");
        item2.setUnitPrice(5980);
        item2.setQuantity(1);
        item2.setSubtotal(5980);
        orderItemRepository.insert(item2);

        List<OrderItemEntity> result = orderItemRepository.findByOrderId(order1.getOrderId());

        assertNotNull(result);
        assertEquals(1, result.size());
        assertEquals(order1.getOrderId(), result.get(0).getOrderId());
    }

    /**
     * ORDER BY order_item_id ASC の並び順を検証する。
     */
    @Test
    @DisplayName("findByOrderId: order_item_id 昇順で取得される")
    void findByOrderId_returnsItemsOrderedByOrderItemIdAsc() {
        jdbcTemplate.update(
                "INSERT INTO products (product_id, name, description, price, stock, status, image_url) VALUES (?, ?, ?, ?, ?, ?, ?)",
                2, "ゲーミングマウス", "6ボタン搭載", 3980, 5, "ON_SALE", "/images/products/2.png");

        OrderEntity order = createOrder("山田太郎", "1234567", "東京都千代田区1-1", "09012345678", 9960);

        OrderItemEntity item1 = new OrderItemEntity();
        item1.setOrderId(order.getOrderId());
        item1.setProductId(1);
        item1.setProductName("ワイヤレスイヤホン");
        item1.setUnitPrice(5980);
        item1.setQuantity(1);
        item1.setSubtotal(5980);
        orderItemRepository.insert(item1);

        OrderItemEntity item2 = new OrderItemEntity();
        item2.setOrderId(order.getOrderId());
        item2.setProductId(2);
        item2.setProductName("ゲーミングマウス");
        item2.setUnitPrice(3980);
        item2.setQuantity(1);
        item2.setSubtotal(3980);
        orderItemRepository.insert(item2);

        List<OrderItemEntity> result = orderItemRepository.findByOrderId(order.getOrderId());

        assertNotNull(result);
        assertEquals(2, result.size());
        assertTrue(result.get(0).getOrderItemId() < result.get(1).getOrderItemId());
    }

    /**
     * FK制約（order_id）を検証する。
     */
    @Test
    @DisplayName("insert: 存在しないorderIdで注文明細登録するとFK制約違反になる")
    void insert_throwsWhenOrderIdDoesNotExist() {
        OrderItemEntity item = new OrderItemEntity();
        item.setOrderId(9999);
        item.setProductId(1);
        item.setProductName("ワイヤレスイヤホン");
        item.setUnitPrice(5980);
        item.setQuantity(1);
        item.setSubtotal(5980);

        assertThrows(DataIntegrityViolationException.class,
                () -> orderItemRepository.insert(item));
    }

    /**
     * FK制約（product_id）を検証する。
     */
    @Test
    @DisplayName("insert: 存在しないproductIdで注文明細登録するとFK制約違反になる")
    void insert_throwsWhenProductIdDoesNotExist() {
        OrderEntity order = createOrder("山田太郎", "1234567", "東京都千代田区1-1", "09012345678", 5980);

        OrderItemEntity item = new OrderItemEntity();
        item.setOrderId(order.getOrderId());
        item.setProductId(9999);
        item.setProductName("不明商品");
        item.setUnitPrice(1000);
        item.setQuantity(1);
        item.setSubtotal(1000);

        assertThrows(DataIntegrityViolationException.class,
                () -> orderItemRepository.insert(item));
    }

    /**
     * NOT NULL制約を検証する。
     */
    @Test
    @DisplayName("insert: productName=nullで注文明細登録するとNOT NULL制約違反になる")
    void insert_throwsWhenProductNameIsNull() {
        OrderEntity order = createOrder("山田太郎", "1234567", "東京都千代田区1-1", "09012345678", 5980);

        OrderItemEntity item = new OrderItemEntity();
        item.setOrderId(order.getOrderId());
        item.setProductId(1);
        item.setProductName(null);
        item.setUnitPrice(5980);
        item.setQuantity(1);
        item.setSubtotal(5980);

        assertThrows(DataIntegrityViolationException.class,
                () -> orderItemRepository.insert(item));
    }

    /**
     * テスト用の注文を作成する。
     */
    private OrderEntity createOrder(String customerName, String postalCode, String address, String phoneNumber, int totalAmount) {
        OrderEntity order = new OrderEntity();
        order.setCustomerName(customerName);
        order.setPostalCode(postalCode);
        order.setAddress(address);
        order.setPhoneNumber(phoneNumber);
        order.setTotalAmount(totalAmount);
        order.setOrderedAt(LocalDateTime.now());
        orderRepository.insert(order);
        return order;
    }
}
