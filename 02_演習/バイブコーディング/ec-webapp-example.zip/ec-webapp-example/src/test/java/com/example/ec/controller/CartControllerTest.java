package com.example.ec.controller;

import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.hamcrest.Matchers.containsString;
import static org.hamcrest.Matchers.hasProperty;
import static org.hamcrest.Matchers.hasSize;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.not;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.flash;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.model;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.redirectedUrl;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.view;

import java.util.Collections;
import java.util.List;
import java.util.stream.Stream;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.MethodSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.webmvc.test.autoconfigure.WebMvcTest;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.servlet.MockMvc;

import com.example.ec.exception.BusinessException;
import com.example.ec.service.CartService;
import com.example.ec.service.OrderService;
import com.example.ec.service.ProductService;
import com.example.ec.service.model.CartItemModel;
import com.example.ec.service.model.CartModel;
import com.example.ec.service.model.OrderModel;

/**
 * カート画面（SCR-03）のController単体テストクラス。
 *
 * <p>実サーバーは起動せず、MockMvcでHTTPリクエストをシミュレートして
 * CartControllerの動作とThymeleaf表示を検証する。</p>
 */
@WebMvcTest({ CartController.class, OrderController.class, ProductController.class })
class CartControllerTest {

    /** HTTPリクエストをシミュレートするテストクライアント。 */
    @Autowired
    private MockMvc mockMvc;

    /** カートServiceのモック。 */
    @MockitoBean
    private CartService cartService;

    /** 注文Serviceのモック（遷移先エンドポイント確認用）。 */
    @MockitoBean
    private OrderService orderService;

    /** 商品Serviceのモック（遷移先エンドポイント確認用）。 */
    @MockitoBean
    private ProductService productService;

    /**
     * GET /cart の基本表示を検証する。
     */
    @Test
    @DisplayName("CT-C-001: GET /cart でHTTP 200、cartビュー、Modelにcartが設定される")
    void ctc001_showCart_returnsOkAndViewAndModel() throws Exception {
        when(cartService.getCart()).thenReturn(buildCart(false, List.of(buildItem(10, 1, "ワイヤレスイヤホン", 5980, 10, 2, 11960)), 2, 11960));

        mockMvc.perform(get("/cart"))
                .andExpect(status().isOk())
                .andExpect(view().name("cart"))
                .andExpect(model().attributeExists("cart"))
                .andExpect(model().attribute("cart", hasProperty("empty", is(false))))
                .andExpect(model().attribute("cart", hasProperty("items", hasSize(1))));
    }

    /**
     * GET /cart のThymeleaf表示内容（非空カート）を検証する。
     */
    @Test
    @DisplayName("CT-C-002: 非空カート時にタイトル・ヘッダー・商品情報・操作ボタンが表示される")
    void ctc002_showCart_rendersThymeleafContentsForNonEmptyCart() throws Exception {
        CartItemModel item = buildItem(10, 1, "ワイヤレスイヤホン", 5980, 10, 2, 11960);
        when(cartService.getCart()).thenReturn(buildCart(false, List.of(item), 2, 11960));

        mockMvc.perform(get("/cart"))
                .andExpect(status().isOk())
                .andExpect(content().string(containsString("<title>カート</title>")));
    }

    /**
     * 非空カート時に商品名が表示されることを検証する。
     */
    @Test
    @DisplayName("CT-C-002-1: 非空カート時に商品名が表示される")
    void ctc002_1_showCart_displaysItemName() throws Exception {
        CartItemModel item = buildItem(10, 1, "ワイヤレスイヤホン", 5980, 10, 2, 11960);
        when(cartService.getCart()).thenReturn(buildCart(false, List.of(item), 2, 11960));

        mockMvc.perform(get("/cart"))
                .andExpect(status().isOk())
                .andExpect(content().string(containsString("ワイヤレスイヤホン")));
    }

    /**
     * 非空カート時に合計金額が表示されることを検証する。
     */
    @Test
    @DisplayName("CT-C-002-2: 非空カート時に合計金額が表示される")
    void ctc002_2_showCart_displaysTotalAmount() throws Exception {
        CartItemModel item = buildItem(10, 1, "ワイヤレスイヤホン", 5980, 10, 2, 11960);
        when(cartService.getCart()).thenReturn(buildCart(false, List.of(item), 2, 11960));

        mockMvc.perform(get("/cart"))
                .andExpect(status().isOk())
                .andExpect(content().string(containsString("合計金額")));
    }

    /**
     * 非空カート時に注文手続き導線が表示されることを検証する。
     */
    @Test
    @DisplayName("CT-C-002-3: 非空カート時に注文手続き導線が表示される")
    void ctc002_3_showCart_displaysOrderConfirmLink() throws Exception {
        CartItemModel item = buildItem(10, 1, "ワイヤレスイヤホン", 5980, 10, 2, 11960);
        when(cartService.getCart()).thenReturn(buildCart(false, List.of(item), 2, 11960));

        mockMvc.perform(get("/cart"))
                .andExpect(status().isOk())
                .andExpect(content().string(containsString("/orders/confirm")));
    }

    /**
     * 非空カート時に商品IDが表示されることを検証する。
     */
    @Test
    @DisplayName("CT-C-002-4: 非空カート時に商品IDが表示される")
    void ctc002_4_showCart_displaysProductId() throws Exception {
        CartItemModel item = buildItem(10, 1, "ワイヤレスイヤホン", 5980, 10, 2, 11960);
        when(cartService.getCart()).thenReturn(buildCart(false, List.of(item), 2, 11960));

        mockMvc.perform(get("/cart"))
                .andExpect(status().isOk())
                .andExpect(content().string(containsString("商品ID")))
                .andExpect(content().string(containsString(">1<")));
    }

    /**
     * 非空カート時に単価が表示されることを検証する。
     */
    @Test
    @DisplayName("CT-C-002-5: 非空カート時に単価が表示される")
    void ctc002_5_showCart_displaysUnitPrice() throws Exception {
        CartItemModel item = buildItem(10, 1, "ワイヤレスイヤホン", 5980, 10, 2, 11960);
        when(cartService.getCart()).thenReturn(buildCart(false, List.of(item), 2, 11960));

        mockMvc.perform(get("/cart"))
                .andExpect(status().isOk())
                .andExpect(content().string(containsString("¥5,980")));
    }

    /**
     * 非空カート時に小計が表示されることを検証する。
     */
    @Test
    @DisplayName("CT-C-002-6: 非空カート時に小計が表示される")
    void ctc002_6_showCart_displaysSubtotal() throws Exception {
        CartItemModel item = buildItem(10, 1, "ワイヤレスイヤホン", 5980, 10, 2, 11960);
        when(cartService.getCart()).thenReturn(buildCart(false, List.of(item), 2, 11960));

        mockMvc.perform(get("/cart"))
                .andExpect(status().isOk())
                .andExpect(content().string(containsString("¥11,960")));
    }

    /**
     * 非空カート時に合計数量が表示されることを検証する。
     */
    @Test
    @DisplayName("CT-C-002-7: 非空カート時に合計数量が表示される")
    void ctc002_7_showCart_displaysTotalQuantity() throws Exception {
        CartItemModel item = buildItem(10, 1, "ワイヤレスイヤホン", 5980, 10, 2, 11960);
        when(cartService.getCart()).thenReturn(buildCart(false, List.of(item), 2, 11960));

        mockMvc.perform(get("/cart"))
                .andExpect(status().isOk())
                .andExpect(content().string(containsString("合計数量")))
                .andExpect(content().string(containsString("2点")));
    }

    /**
     * 非空カート時に数量更新ボタンと削除ボタンが表示されることを検証する。
     */
    @Test
    @DisplayName("CT-C-002-8: 非空カート時に数量更新と削除の操作ボタンが表示される")
    void ctc002_8_showCart_displaysActionButtons() throws Exception {
        CartItemModel item = buildItem(10, 1, "ワイヤレスイヤホン", 5980, 10, 2, 11960);
        when(cartService.getCart()).thenReturn(buildCart(false, List.of(item), 2, 11960));

        mockMvc.perform(get("/cart"))
                .andExpect(status().isOk())
                .andExpect(content().string(containsString("数量更新")))
                .andExpect(content().string(containsString("削除")));
    }

    /**
     * 非空カート時に個別商品の数量入力値が表示されることを検証する。（CT-C-011）
     */
    @Test
    @DisplayName("CT-C-011: 非空カート時に個別商品の数量入力値が表示される")
    void ctc002_9_showCart_displaysItemQuantityValue() throws Exception {
        CartItemModel item = buildItem(10, 1, "ワイヤレスイヤホン", 5980, 10, 2, 11960);
        when(cartService.getCart()).thenReturn(buildCart(false, List.of(item), 2, 11960));

        mockMvc.perform(get("/cart"))
                .andExpect(status().isOk())
                .andExpect(content().string(containsString("value=\"2\"")));
    }

    /**
     * GET /cart の空カート表示を検証する。
     */
    @Test
    @DisplayName("CT-C-003: 空カート時もHTTP 200で、空メッセージ表示かつ注文手続き導線は表示されない")
    void ctc003_showCart_rendersEmptyCartView() throws Exception {
        when(cartService.getCart()).thenReturn(buildCart(true, Collections.emptyList(), 0, 0));

        mockMvc.perform(get("/cart"))
                .andExpect(status().isOk())
                .andExpect(view().name("cart"))
                .andExpect(model().attribute("cart", hasProperty("empty", is(true))))
                .andExpect(model().attribute("cart", hasProperty("totalAmount", is(0))))
                .andExpect(content().string(containsString("カートに商品がありません。")))
                .andExpect(content().string(containsString("買い物を続ける")))
                .andExpect(content().string(not(containsString("注文手続きへ"))));
    }

    /**
     * GET /cart でService例外が発生した場合の異常系を検証する。
     */
    @Test
    @DisplayName("CT-C-004: GET /cart でService例外発生時は例外が伝播する")
    void ctc004_showCart_propagatesExceptionWhenServiceThrows() {
        when(cartService.getCart()).thenThrow(new RuntimeException("cart service failure"));

        assertThatThrownBy(() -> mockMvc.perform(get("/cart")))
                .hasRootCauseInstanceOf(RuntimeException.class)
                .hasRootCauseMessage("cart service failure");
    }

    /**
     * 数量1で更新できることを検証する。
     */
    @Test
    @DisplayName("CT-U-001: quantity=1でPOST更新するとServiceが呼び出され、/cartにリダイレクトされる")
    void ctu001_updateQuantity_callsServiceWithMinBoundary() throws Exception {
        mockMvc.perform(post("/cart/items/1/update")
                        .param("quantity", "1"))
                .andExpect(status().is3xxRedirection())
                .andExpect(redirectedUrl("/cart"))
                .andExpect(flash().attributeExists("successMessage"));

        verify(cartService, times(1)).updateQuantity(1, 1);
    }

    /**
     * 数量99で更新できることを検証する。
     */
    @Test
    @DisplayName("CT-U-002: quantity=99でPOST更新するとServiceが呼び出され、/cartにリダイレクトされる")
    void ctu002_updateQuantity_callsServiceWithMaxBoundary() throws Exception {
        mockMvc.perform(post("/cart/items/1/update")
                        .param("quantity", "99"))
                .andExpect(status().is3xxRedirection())
                .andExpect(redirectedUrl("/cart"))
                .andExpect(flash().attributeExists("successMessage"));

        verify(cartService, times(1)).updateQuantity(1, 99);
    }

    /**
     * quantity未入力の異常系を検証する。
     */
    @Test
    @DisplayName("CT-U-003: quantity未入力は異常系として扱われ、/cartにリダイレクトされる")
    void ctu003_updateQuantity_validationErrorWhenQuantityMissing() throws Exception {
        when(cartService.getCart()).thenReturn(buildCart(true, Collections.emptyList(), 0, 0));

        mockMvc.perform(post("/cart/items/1/update"))
            .andExpect(status().isOk())
            .andExpect(view().name("cart"))
            .andExpect(model().attributeExists("errorMessage"));

        verify(cartService, never()).updateQuantity(anyInt(), anyInt());
    }

    /**
     * quantity=0の異常系を検証する。
     */
    @Test
    @DisplayName("CT-U-004: quantity=0は異常系として扱われ、/cartにリダイレクトされる")
    void ctu004_updateQuantity_validationErrorWhenZero() throws Exception {
        when(cartService.getCart()).thenReturn(buildCart(true, Collections.emptyList(), 0, 0));

        mockMvc.perform(post("/cart/items/1/update")
                        .param("quantity", "0"))
            .andExpect(status().isOk())
            .andExpect(view().name("cart"))
            .andExpect(model().attributeExists("errorMessage"));

        verify(cartService, never()).updateQuantity(anyInt(), anyInt());
    }

    /**
     * quantity負数の異常系を検証する。
     */
    @Test
    @DisplayName("CT-U-005: quantity負数は異常系として扱われ、/cartにリダイレクトされる")
    void ctu005_updateQuantity_validationErrorWhenNegative() throws Exception {
        when(cartService.getCart()).thenReturn(buildCart(true, Collections.emptyList(), 0, 0));

        mockMvc.perform(post("/cart/items/1/update")
                        .param("quantity", "-1"))
            .andExpect(status().isOk())
            .andExpect(view().name("cart"))
            .andExpect(model().attributeExists("errorMessage"));

        verify(cartService, never()).updateQuantity(anyInt(), anyInt());
    }

    /**
     * quantity=100の異常系を検証する。
     */
    @Test
    @DisplayName("CT-U-006: quantity=100は異常系として扱われ、/cartにリダイレクトされる")
    void ctu006_updateQuantity_validationErrorWhenOverMax() throws Exception {
        when(cartService.getCart()).thenReturn(buildCart(true, Collections.emptyList(), 0, 0));

        mockMvc.perform(post("/cart/items/1/update")
                        .param("quantity", "100"))
            .andExpect(status().isOk())
            .andExpect(view().name("cart"))
            .andExpect(model().attributeExists("errorMessage"));

        verify(cartService, never()).updateQuantity(anyInt(), anyInt());
    }

    /**
     * quantityが非数値の異常系を検証する。
     */
    @Test
    @DisplayName("CT-U-007: quantityが数値以外は異常系として扱われ、/cartにリダイレクトされる")
    void ctu007_updateQuantity_validationErrorWhenNonNumeric() throws Exception {
        when(cartService.getCart()).thenReturn(buildCart(true, Collections.emptyList(), 0, 0));

        mockMvc.perform(post("/cart/items/1/update")
                        .param("quantity", "abc"))
            .andExpect(status().isOk())
            .andExpect(view().name("cart"))
            .andExpect(model().attributeExists("errorMessage"));

        verify(cartService, never()).updateQuantity(anyInt(), anyInt());
    }

    /**
     * quantityが小数の異常系を検証する。
     */
    @Test
    @DisplayName("CT-U-008: quantityが小数は異常系として扱われ、/cartにリダイレクトされる")
    void ctu008_updateQuantity_validationErrorWhenDecimal() throws Exception {
        when(cartService.getCart()).thenReturn(buildCart(true, Collections.emptyList(), 0, 0));

        mockMvc.perform(post("/cart/items/1/update")
                        .param("quantity", "1.5"))
            .andExpect(status().isOk())
            .andExpect(view().name("cart"))
            .andExpect(model().attributeExists("errorMessage"));

        verify(cartService, never()).updateQuantity(anyInt(), anyInt());
    }

    /**
     * 非存在商品ID更新時の業務例外ハンドリングを検証する。
     */
    @Test
    @DisplayName("CT-U-009: 存在しない商品ID更新時、エラーメッセージを設定して/cartにリダイレクトされる")
    void ctu009_updateQuantity_handlesIllegalArgumentException() throws Exception {
        doThrow(new BusinessException("error.cart.item.not.found"))
                .when(cartService).updateQuantity(9999, 5);
        when(cartService.getCart()).thenReturn(buildCart(true, Collections.emptyList(), 0, 0));

        mockMvc.perform(post("/cart/items/9999/update")
                        .param("quantity", "5"))
            .andExpect(status().isOk())
            .andExpect(view().name("cart"))
            .andExpect(model().attributeExists("errorMessage"));

        verify(cartService, times(1)).updateQuantity(9999, 5);
    }

    /**
     * 更新時にServiceが想定外例外を投げた場合の異常系を検証する。
     */
    @Test
    @DisplayName("CT-U-010: 更新時にServiceが想定外例外を投げた場合は例外が伝播する")
    void ctu010_updateQuantity_propagatesUnexpectedException() {
        doThrow(new RuntimeException("unexpected update failure"))
                .when(cartService).updateQuantity(1, 5);

        assertThatThrownBy(() -> mockMvc.perform(post("/cart/items/1/update")
                .param("quantity", "5")))
                .hasRootCauseInstanceOf(RuntimeException.class)
                .hasRootCauseMessage("unexpected update failure");
    }

    /**
     * 更新URLのPathVariableが非数値の場合の異常系を検証する。
     */
    @Test
    @DisplayName("CT-U-011: 更新URLのproductIdが非数値の場合、HTTP 400になる")
    void ctu011_updateQuantity_pathVariableTypeMismatch() throws Exception {
        mockMvc.perform(post("/cart/items/abc/update")
                        .param("quantity", "1"))
                .andExpect(status().isBadRequest());
    }

    /**
     * 数量異常入力の組合せをパラメータ化して検証する。
     */
    @ParameterizedTest
    @MethodSource("invalidCartQuantityProvider")
    @DisplayName("CT-U-012: 数量異常入力の組合せでは cart を再表示してエラー表示する")
    void ctu012_updateQuantity_invalidQuantityCombinations(String quantity) throws Exception {
        when(cartService.getCart()).thenReturn(buildCart(true, Collections.emptyList(), 0, 0));

        mockMvc.perform(post("/cart/items/1/update")
                        .param("quantity", quantity))
                .andExpect(status().isOk())
                .andExpect(view().name("cart"))
                .andExpect(model().attributeExists("errorMessage"));

        verify(cartService, never()).updateQuantity(anyInt(), anyInt());
    }

    /**
     * 更新URLのPathVariable異常入力をパラメータ化して検証する。
     */
    @ParameterizedTest
    @MethodSource("invalidPathVariableProvider")
    @DisplayName("CT-U-013: 更新URLのPathVariable異常入力の組合せはHTTP 400")
    void ctu013_updateQuantity_invalidPathVariableCombinations(String productIdPath) throws Exception {
        mockMvc.perform(post("/cart/items/{productId}/update", productIdPath)
                        .param("quantity", "1"))
                .andExpect(status().isBadRequest());
    }

    /**
     * 削除処理の正常系を検証する。
     */
    @Test
    @DisplayName("CT-D-001: 存在する商品ID削除時、Service削除処理が呼び出され/cartへリダイレクトされる")
    void ctd001_deleteItem_callsServiceAndRedirects() throws Exception {
        mockMvc.perform(post("/cart/items/1/delete"))
                .andExpect(status().is3xxRedirection())
                .andExpect(redirectedUrl("/cart"))
                .andExpect(flash().attributeExists("successMessage"));

        verify(cartService, times(1)).deleteItem(1);
    }

    /**
     * 複数商品中の1商品の削除呼び出しを検証する。
     */
    @Test
    @DisplayName("CT-D-002: 複数商品を想定しても指定productIdのみ削除処理が呼び出される")
    void ctd002_deleteItem_callsOnlySpecifiedProductId() throws Exception {
        mockMvc.perform(post("/cart/items/2/delete"))
                .andExpect(status().is3xxRedirection())
                .andExpect(redirectedUrl("/cart"));

        verify(cartService, times(1)).deleteItem(2);
        verify(cartService, never()).deleteItem(1);
        verify(cartService, never()).deleteItem(3);
    }

    /**
     * 非存在商品ID削除時の仕様準拠動作を検証する。
     */
    @Test
    @DisplayName("CT-D-003: 存在しない商品ID削除時でも仕様どおり/cartへリダイレクトされる")
    void ctd003_deleteItem_nonExistingProductStillRedirects() throws Exception {
        mockMvc.perform(post("/cart/items/9999/delete"))
                .andExpect(status().is3xxRedirection())
                .andExpect(redirectedUrl("/cart"));

        verify(cartService, times(1)).deleteItem(9999);
    }

    /**
     * 削除時にServiceが例外を投げた場合の異常系を検証する。
     */
    @Test
    @DisplayName("CT-D-004: 削除時にService例外が発生した場合は例外が伝播する")
    void ctd004_deleteItem_propagatesException() {
        doThrow(new RuntimeException("delete failure")).when(cartService).deleteItem(1);

        assertThatThrownBy(() -> mockMvc.perform(post("/cart/items/1/delete")))
                .hasRootCauseInstanceOf(RuntimeException.class)
                .hasRootCauseMessage("delete failure");
    }

    /**
     * 削除URLのPathVariableが非数値の場合の異常系を検証する。
     */
    @Test
    @DisplayName("CT-D-005: 削除URLのproductIdが非数値の場合、HTTP 400になる")
    void ctd005_deleteItem_pathVariableTypeMismatch() throws Exception {
        mockMvc.perform(post("/cart/items/abc/delete"))
                .andExpect(status().isBadRequest());
    }

    /**
     * 削除URLのPathVariable異常入力をパラメータ化して検証する。
     */
    @ParameterizedTest
    @MethodSource("invalidPathVariableProvider")
    @DisplayName("CT-D-006: 削除URLのPathVariable異常入力の組合せはHTTP 400")
    void ctd006_deleteItem_invalidPathVariableCombinations(String productIdPath) throws Exception {
        mockMvc.perform(post("/cart/items/{productId}/delete", productIdPath))
                .andExpect(status().isBadRequest());
    }

    /**
     * 注文手続きへの遷移先エンドポイントが利用可能であることを検証する。
     */
    @Test
    @DisplayName("CT-N-001: GET /orders/confirm にアクセスできる")
    void ctn001_navigation_toOrderConfirmEndpointAvailable() throws Exception {
        when(orderService.getOrderConfirmation()).thenReturn(buildOrderForConfirm());

        mockMvc.perform(get("/orders/confirm"))
                .andExpect(status().isOk())
                .andExpect(view().name("order-confirm"))
                .andExpect(model().attributeExists("order"))
                .andExpect(model().attributeExists("orderForm"));
    }

    /**
     * 買い物を続ける遷移先エンドポイントが利用可能であることを検証する。
     */
    @Test
    @DisplayName("CT-N-002: GET /products にアクセスできる")
    void ctn002_navigation_toProductsEndpointAvailable() throws Exception {
        when(productService.getOnSaleProducts()).thenReturn(Collections.emptyList());

        mockMvc.perform(get("/products"))
                .andExpect(status().isOk())
                .andExpect(view().name("products"));
    }

    /**
     * 注文確認画面へのリンクがカート画面に含まれることを検証する。
     */
    @Test
    @DisplayName("CT-N-003: 非空カート画面に /orders/confirm へのリンクが表示される")
    void ctn003_cartViewContainsOrderConfirmLink() throws Exception {
        when(cartService.getCart()).thenReturn(buildCart(false, List.of(buildItem(1, 1, "ワイヤレスイヤホン", 5980, 10, 1, 5980)), 1, 5980));

        mockMvc.perform(get("/cart"))
                .andExpect(status().isOk())
                .andExpect(content().string(containsString("href=\"/orders/confirm\"")));
    }

    /**
     * 商品一覧画面へのリンクがカート画面に含まれることを検証する。
     */
    @Test
    @DisplayName("CT-N-004: カート画面に /products へのリンクが表示される")
    void ctn004_cartViewContainsProductsLink() throws Exception {
        when(cartService.getCart()).thenReturn(buildCart(true, Collections.emptyList(), 0, 0));

        mockMvc.perform(get("/cart"))
                .andExpect(status().isOk())
                .andExpect(content().string(containsString("href=\"/products\"")));
    }

    /**
     * テスト用のCartModelを生成する。
     *
     * @param empty 空判定
     * @param items 明細
     * @param totalQuantity 合計数量
     * @param totalAmount 合計金額
     * @return カートモデル
     */
    private CartModel buildCart(Boolean empty, List<CartItemModel> items, Integer totalQuantity, Integer totalAmount) {
        CartModel cart = new CartModel();
        cart.setEmpty(empty);
        cart.setItems(items);
        cart.setTotalQuantity(totalQuantity);
        cart.setTotalAmount(totalAmount);
        return cart;
    }

    /**
     * テスト用のCartItemModelを生成する。
     *
     * @param cartItemId カート明細ID
     * @param productId 商品ID
     * @param name 商品名
     * @param price 単価
     * @param stock 在庫数
     * @param quantity 数量
     * @param subtotal 小計
     * @return カート明細モデル
     */
    private CartItemModel buildItem(Integer cartItemId, Integer productId, String name,
            Integer price, Integer stock, Integer quantity, Integer subtotal) {
        CartItemModel item = new CartItemModel();
        item.setCartItemId(cartItemId);
        item.setProductId(productId);
        item.setName(name);
        item.setPrice(price);
        item.setStock(stock);
        item.setQuantity(quantity);
        item.setSubtotal(subtotal);
        item.setImageUrl("/images/products/1.png");
        return item;
    }

    /**
     * 注文確認画面表示用のOrderModelを生成する。
     *
     * @return 注文モデル
     */
    private OrderModel buildOrderForConfirm() {
        OrderModel order = new OrderModel();
        order.setEmpty(false);
        order.setItems(Collections.emptyList());
        order.setTotalQuantity(0);
        order.setTotalAmount(0);
        return order;
    }

    private static Stream<String> invalidCartQuantityProvider() {
        return Stream.of("", "0", "-1", "100", "abc", "1.5");
    }

    private static Stream<String> invalidPathVariableProvider() {
        return Stream.of("abc", "1.5", "x-1");
    }
}
