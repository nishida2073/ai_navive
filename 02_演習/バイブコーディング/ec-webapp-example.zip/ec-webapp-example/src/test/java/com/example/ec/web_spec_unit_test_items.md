# ECサイト 単体テスト項目書（外部仕様ベース）

## 方針
- 受講生ごとの実装差分を吸収するため、内部実装（Serviceメソッド呼び出し有無など）は検証しない。
- 1つのテスト項目では1つの内容のみを検証する。
- HTTPリクエストに対する以下のみを検証する。
  - ステータスコード
  - リダイレクト先
  - 画面遷移先のURLパス
  - 初期データ表示
  - 要件で明示された固定文言（主にボタン名・遷移ラベル）
- エラーメッセージは実装差分が生じやすいため、文言自体は検証しない。

## テスト項目

| ID | 画面/機能 | リクエスト | 主な検証観点 |
|---|---|---|---|
| T01 | 商品一覧表示 | GET /products | ステータスが200 OK |
| T02 | 商品一覧表示 | GET /products | 要件文言「詳細を見る」を表示 |
| T03 | 商品一覧表示 | GET /products | 要件文言「カートに追加」を表示 |
| T04 | 商品一覧表示 | GET /products | 要件文言「カートを見る」を表示 |
| T05 | 商品一覧表示 | GET /products | 「詳細を見る」の遷移先URLパスが /products/{productId} |
| T06 | 商品一覧表示 | GET /products | 「カートに追加」フォームの送信先URLパスが /cart/items |
| T07 | 商品一覧表示 | GET /products | 「カートを見る」の遷移先URLパスが /cart |
| T08 | 商品一覧表示 | GET /products | 初期データ「ワイヤレスイヤホン」を表示 |
| T09 | 商品一覧表示 | GET /products | 初期データ「ゲーミングマウス」を表示 |
| T10 | 商品一覧表示 | GET /products | 初期データ「USB-Cハブ」を表示 |
| T11 | 商品一覧表示 | GET /products | 販売停止商品「Webカメラ」を表示しない |
| T12 | カート追加 | POST /cart/items | 商品一覧から追加時、リダイレクト先が /products |
| T13 | カート追加 | POST /cart/items | 商品詳細から追加時、リダイレクト先が /products/{productId} |
| T14 | 商品詳細表示 | GET /products/{productId} | ステータスが200 OK |
| T15 | 商品詳細表示 | GET /products/{productId} | 要件文言「カートに追加」を表示 |
| T16 | 商品詳細表示 | GET /products/{productId} | 要件文言「商品一覧に戻る」を表示 |
| T17 | 商品詳細表示 | GET /products/{productId} | 要件文言「カートを見る」を表示 |
| T18 | 商品詳細表示 | GET /products/{productId} | 「カートに追加」フォームの送信先URLパスが /cart/items |
| T19 | 商品詳細表示 | GET /products/{productId} | 「商品一覧に戻る」の遷移先URLパスが /products |
| T20 | 商品詳細表示 | GET /products/{productId} | 「カートを見る」の遷移先URLパスが /cart |
| T21 | 商品詳細表示 | GET /products/{productId} | 初期データ「ワイヤレスイヤホン」を表示 |
| T22 | カート画面表示（初期） | GET /cart | ステータスが200 OK |
| T23 | カート画面表示（初期） | GET /cart | 要件文言「買い物を続ける」を表示 |
| T24 | カート画面表示（初期） | GET /cart | 「買い物を続ける」の遷移先URLパスが /products |
| T25 | カート画面表示（商品追加後） | GET /cart | ステータスが200 OK |
| T26 | カート画面表示（商品追加後） | GET /cart | 追加済み商品「ワイヤレスイヤホン」を表示 |
| T27 | カート画面表示（商品追加後） | GET /cart | 要件文言「数量更新」を表示 |
| T28 | カート画面表示（商品追加後） | GET /cart | 要件文言「削除」を表示 |
| T29 | カート画面表示（商品追加後） | GET /cart | 要件文言「注文手続きへ」を表示 |
| T30 | カート画面表示（商品追加後） | GET /cart | 「数量更新」フォームの送信先URLパスが /cart/items/{productId}/update |
| T31 | カート画面表示（商品追加後） | GET /cart | 「削除」フォームの送信先URLパスが /cart/items/{productId}/delete |
| T32 | カート画面表示（商品追加後） | GET /cart | 「注文手続きへ」の遷移先URLパスが /orders/confirm |
| T33 | カート数量更新 | POST /cart/items/{productId}/update | リダイレクト先が /cart |
| T34 | カート削除 | POST /cart/items/{productId}/delete | リダイレクト先が /cart |
| T35 | 注文確認画面表示（商品あり） | GET /orders/confirm | ステータスが200 OK |
| T36 | 注文確認画面表示（商品あり） | GET /orders/confirm | 要件文言「注文を確定する」を表示 |
| T37 | 注文確認画面表示（商品あり） | GET /orders/confirm | 要件文言「カートに戻る」を表示 |
| T38 | 注文確認画面表示（商品あり） | GET /orders/confirm | 「カートに戻る」の遷移先URLパスが /cart |
| T39 | 注文確認画面表示（商品あり） | GET /orders/confirm | 「注文を確定する」フォームの送信先URLパスが /orders |
| T40 | 注文確定 | POST /orders | リダイレクト先が /orders/complete/{orderId} 形式 |
| T41 | 注文完了画面表示（IDあり） | GET /orders/complete/{orderId} | ステータスが200 OK |
| T42 | 注文完了画面表示（IDあり） | GET /orders/complete/{orderId} | 要件文言「商品一覧に戻る」を表示 |
| T43 | 注文完了画面表示（IDあり） | GET /orders/complete/{orderId} | 「商品一覧に戻る」の遷移先URLパスが /products |
| T44 | カート追加（在庫超過・商品一覧） | POST /cart/items | 在庫超過数量で送信した場合、ステータス200で商品一覧画面に留まる |
| T45 | カート追加（在庫超過・商品詳細） | POST /cart/items | 在庫超過数量で送信した場合、ステータス200で商品詳細画面に留まる（「商品一覧に戻る」「カートを見る」を表示） |
| T46 | カート数量更新（在庫超過） | POST /cart/items/{productId}/update | 在庫超過数量で送信した場合、ステータス200でカート画面に留まる |
| T47 | 注文確定（氏名: 空文字） | POST /orders | customerName が空文字の場合、ステータス200で注文確認画面に留まる |
| T48 | 注文確定（氏名: 101文字） | POST /orders | customerName が101文字の場合、ステータス200で注文確認画面に留まる |
| T49 | 注文確定（郵便番号: 6桁） | POST /orders | postalCode が6桁の場合、ステータス200で注文確認画面に留まる |
| T50 | 注文確定（郵便番号: 8桁） | POST /orders | postalCode が8桁の場合、ステータス200で注文確認画面に留まる |
| T51 | 注文確定（郵便番号: 7桁） | POST /orders | postalCode が7桁（他項目が適切）で送信した場合、/orders/complete/{orderId} 形式へリダイレクト |
| T52 | 注文確定（住所: 空文字） | POST /orders | address が空文字の場合、ステータス200で注文確認画面に留まる |
| T53 | 注文確定（住所: 256文字） | POST /orders | address が256文字の場合、ステータス200で注文確認画面に留まる |
| T54 | 注文確定（電話番号: 9桁） | POST /orders | phoneNumber が9桁の場合、ステータス200で注文確認画面に留まる |
| T55 | 注文確定（電話番号: 12桁） | POST /orders | phoneNumber が12桁の場合、ステータス200で注文確認画面に留まる |
| T56 | 注文確定（電話番号: 10桁） | POST /orders | phoneNumber が10桁（他項目が適切）で送信した場合、/orders/complete/{orderId} 形式へリダイレクト |
| T57 | 注文確定（電話番号: 11桁） | POST /orders | phoneNumber が11桁（他項目が適切）で送信した場合、/orders/complete/{orderId} 形式へリダイレクト |
| T58 | 注文確定（氏名: 100文字） | POST /orders | customerName が100文字（他項目が適切）で送信した場合、/orders/complete/{orderId} 形式へリダイレクト |
| T59 | 注文確定（住所: 255文字） | POST /orders | address が255文字（他項目が適切）で送信した場合、/orders/complete/{orderId} 形式へリダイレクト |
| T60 | カート追加（在庫0・商品一覧） | POST /cart/items | 在庫0の商品を追加した場合、ステータス200で商品一覧画面に留まる |
| T61 | カート追加（在庫0・商品詳細） | POST /cart/items | 在庫0の商品を追加した場合、ステータス200で商品詳細画面に留まる（「商品一覧に戻る」「カートを見る」を表示） |
| T62 | 注文確認画面表示（商品あり） | GET /orders/confirm | カートに追加した商品「ワイヤレスイヤホン」を表示 |
