package com.example.ec;

import java.util.UUID;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.DynamicPropertyRegistry;
import org.springframework.test.context.DynamicPropertySource;

@SpringBootTest
class EcWebappApplicationTests {

	@DynamicPropertySource
	static void overrideDatasourceUrl(DynamicPropertyRegistry registry) {
		registry.add(
				"spring.datasource.url",
				() -> "jdbc:h2:mem:ecdbtest-" + UUID.randomUUID() + ";DB_CLOSE_ON_EXIT=FALSE");
	}

	@Test
	void contextLoads() {
	}

}
