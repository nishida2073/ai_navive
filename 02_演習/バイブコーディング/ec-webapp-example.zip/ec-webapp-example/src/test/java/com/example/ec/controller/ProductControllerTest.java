package com.example.ec.controller;

import static org.assertj.core.api.Assertions.*;
import static org.hamcrest.Matchers.*;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

import java.util.Collections;
import java.util.List;
import java.util.stream.Stream;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.webmvc.test.autoconfigure.WebMvcTest;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;

import com.example.ec.controller.form.ProductListItemForm;
import com.example.ec.exception.BusinessException;
import com.example.ec.service.CartService;
import com.example.ec.service.ProductService;
import com.example.ec.service.model.ProductModel;

/**
 * {@link ProductController#showProducts(org.springframework.ui.Model)} の単体テストクラス。
 *
 * <p>実サーバーは起動せず、{@link MockMvc} によりHTTPリクエストをシミュレートして
 * Controllerの動作とThymeleafテンプレートの表示内容を検証する。</p>
 *
 * <p>テスト技法：同値分析、境界値分析、実行網羅（C0）、分岐網羅（C1）</p>
 */
@WebMvcTest(ProductController.class)
class ProductControllerTest {

    /** HTTPリクエストをシミュレートするテストクライアント。 */
    @Autowired
    private MockMvc mockMvc;

    /** ProductService のモック。 */
    @MockitoBean
    private ProductService productService;

    /** ProductController のコンストラクタ依存を満たすためのモック。 */
    @MockitoBean
    private CartService cartService;

    /**
     * C-01: 販売中商品が複数件ある場合に一覧表示できることと、
     * Thymeleaf で主要な表示項目が描画されることを検証する。
     */
    @Test
    @DisplayName("C-01: 販売中商品が複数件ある場合、HTTP 200でproducts画面が表示されThymeleafで商品情報が描画される")
    void c01_showProducts_rendersProductListAndThymeleafContents() throws Exception {
        // Arrange
        ProductModel product1 = buildProduct(1, "ワイヤレスイヤホン", "ノイズキャンセリング対応", 5980, 10, "ON_SALE",
                "/images/products/1.png");
        ProductModel product2 = buildProduct(2, "USB-Cハブ", "5in1モデル", 2980, 0, "ON_SALE",
                "/images/products/3.png");
        when(productService.getOnSaleProducts()).thenReturn(List.of(product1, product2));

        // Act & Assert
        mockMvc.perform(get("/products"))
                .andExpect(status().isOk())
                .andExpect(view().name("products"))
                .andExpect(model().attributeExists("products"))
                .andExpect(model().attribute("products", hasSize(2)))
                .andExpect(content().string(containsString("ワイヤレスイヤホン")));
    }

    /**
     * C-01-1: 商品価格が表示されることを検証する。
     */
    @Test
    @DisplayName("C-01-1: 商品一覧で価格が表示される")
    void c01_1_showProducts_displaysPrice() throws Exception {
        ProductModel product = buildProduct(1, "ワイヤレスイヤホン", "ノイズキャンセリング対応", 5980, 10, "ON_SALE",
                "/images/products/1.png");
        when(productService.getOnSaleProducts()).thenReturn(List.of(product));

        mockMvc.perform(get("/products"))
                .andExpect(status().isOk())
                .andExpect(content().string(containsString("¥5,980")));
    }

    /**
     * C-01-2: 在庫数が表示されることを検証する。
     */
    @Test
    @DisplayName("C-01-2: 商品一覧で在庫数が表示される")
    void c01_2_showProducts_displaysStockCount() throws Exception {
        ProductModel product = buildProduct(1, "ワイヤレスイヤホン", "ノイズキャンセリング対応", 5980, 10, "ON_SALE",
                "/images/products/1.png");
        when(productService.getOnSaleProducts()).thenReturn(List.of(product));

        mockMvc.perform(get("/products"))
                .andExpect(status().isOk())
                .andExpect(content().string(containsString("在庫数: 10")));
    }

    /**
     * C-01-3: 販売ステータスが表示されることを検証する。
     */
    @Test
    @DisplayName("C-01-3: 商品一覧で販売ステータスが表示される")
    void c01_3_showProducts_displaysStatus() throws Exception {
        ProductModel product = buildProduct(1, "ワイヤレスイヤホン", "ノイズキャンセリング対応", 5980, 10, "ON_SALE",
                "/images/products/1.png");
        when(productService.getOnSaleProducts()).thenReturn(List.of(product));

        mockMvc.perform(get("/products"))
                .andExpect(status().isOk())
                .andExpect(content().string(containsString("販売ステータス: 販売中")));
    }

    /**
     * C-01-4: 在庫切れ商品のボタンが無効化されることを検証する。
     */
    @Test
    @DisplayName("C-01-4: 在庫切れ商品ではカート追加ボタンが無効になる")
    void c01_4_showProducts_disablesCartButtonWhenOutOfStock() throws Exception {
        ProductModel product = buildProduct(3, "USB-Cハブ", "5in1モデル", 2980, 0, "ON_SALE", "/images/products/3.png");
        when(productService.getOnSaleProducts()).thenReturn(List.of(product));

        mockMvc.perform(get("/products"))
                .andExpect(status().isOk())
                .andExpect(content().string(containsString("disabled=\"disabled\"")));
    }

    /**
     * C-01-5: 商品一覧で在庫状態が表示されることを検証する。
     */
    @Test
    @DisplayName("C-01-5: 商品一覧で在庫なし表示が描画される")
    void c01_5_showProducts_displaysOutOfStockStatus() throws Exception {
        ProductModel product = buildProduct(3, "USB-Cハブ", "5in1モデル", 2980, 0, "ON_SALE", "/images/products/3.png");
        when(productService.getOnSaleProducts()).thenReturn(List.of(product));

        mockMvc.perform(get("/products"))
                .andExpect(status().isOk())
                .andExpect(content().string(containsString("在庫なし")));
    }

    /**
     * C-01-6: 商品一覧で商品詳細リンクが表示されることを検証する。
     */
    @Test
    @DisplayName("C-01-6: 商品一覧で詳細画面へのリンクが表示される")
    void c01_6_showProducts_displaysDetailLink() throws Exception {
        ProductModel product = buildProduct(1, "ワイヤレスイヤホン", "ノイズキャンセリング対応", 5980, 10, "ON_SALE",
                "/images/products/1.png");
        when(productService.getOnSaleProducts()).thenReturn(List.of(product));

        mockMvc.perform(get("/products"))
                .andExpect(status().isOk())
                .andExpect(content().string(containsString("/products/1")))
                .andExpect(content().string(containsString("詳細を見る")));
    }

    /**
     * C-01-7: 商品一覧でヘッダーのカートリンクが表示されることを検証する。
     */
    @Test
    @DisplayName("C-01-7: 商品一覧でヘッダーのカートリンクが表示される")
    void c01_7_showProducts_displaysCartHeaderLink() throws Exception {
        when(productService.getOnSaleProducts()).thenReturn(Collections.emptyList());

        mockMvc.perform(get("/products"))
                .andExpect(status().isOk())
                .andExpect(content().string(containsString("href=\"/cart\"")))
                .andExpect(content().string(containsString("カートを見る")));
    }

    /**
     * C-01-8: 商品一覧で商品画像のsrc属性が表示されることを検証する。（PL-C-020）
     */
    @Test
    @DisplayName("C-01-8: 商品一覧で商品画像のsrc属性が表示される")
    void c01_8_showProducts_displaysProductImage() throws Exception {
        ProductModel product = buildProduct(1, "ワイヤレスイヤホン", "ノイズキャンセリング対応", 5980, 10, "ON_SALE",
                "/images/products/1.png");
        when(productService.getOnSaleProducts()).thenReturn(List.of(product));

        mockMvc.perform(get("/products"))
                .andExpect(status().isOk())
                .andExpect(content().string(containsString("src=\"/images/products/1.png\"")));
    }

    /**
     * C-02: 販売中商品が1件のみの場合に一覧表示できることを検証する。
     */
    @Test
    @DisplayName("C-02: 販売中商品が1件のみの場合、Modelに1件のリストが設定される")
    void c02_showProducts_setsSingleItemListToModel() throws Exception {
        // Arrange
        ProductModel product = buildProduct(1, "商品A", "説明A", 1000, 1, "ON_SALE", "/images/products/1.png");
        when(productService.getOnSaleProducts()).thenReturn(List.of(product));

        // Act & Assert
        mockMvc.perform(get("/products"))
                .andExpect(status().isOk())
                .andExpect(model().attribute("products", hasSize(1)));
    }

    /**
     * C-03: 販売中商品が0件の場合に空リストが設定されることを検証する。
     */
    @Test
    @DisplayName("C-03: 販売中商品が0件の場合、Modelに空リストが設定される")
    void c03_showProducts_setsEmptyListToModel() throws Exception {
        // Arrange
        when(productService.getOnSaleProducts()).thenReturn(Collections.emptyList());

        // Act & Assert
        mockMvc.perform(get("/products"))
                .andExpect(status().isOk())
                .andExpect(model().attribute("products", hasSize(0)));
    }

    /**
     * C-04: ProductService#getOnSaleProducts が1回だけ呼ばれることを検証する。
     */
    @Test
    @DisplayName("C-04: GET /products 実行時に productService.getOnSaleProducts() が1回だけ呼ばれる")
    void c04_showProducts_callsServiceExactlyOnce() throws Exception {
        // Arrange
        when(productService.getOnSaleProducts()).thenReturn(Collections.emptyList());

        // Act
        mockMvc.perform(get("/products"))
                .andExpect(status().isOk());

        // Assert
        verify(productService, times(1)).getOnSaleProducts();
        verifyNoMoreInteractions(productService);
    }

    /**
     * C-05: ビュー名が products であることを検証する。
     */
    @Test
    @DisplayName("C-05: GET /products の戻りビュー名は products")
    void c05_showProducts_returnsProductsViewName() throws Exception {
        // Arrange
        when(productService.getOnSaleProducts()).thenReturn(Collections.emptyList());

        // Act & Assert
        mockMvc.perform(get("/products"))
                .andExpect(status().isOk())
                .andExpect(view().name("products"));
    }

    /**
     * C-06: @ModelAttribute で productListItemForm がModelに設定されることを検証する。
     */
    @Test
    @DisplayName("C-06: productListItemForm がModelに ProductListItemForm として設定される")
    void c06_showProducts_setsProductListItemFormToModel() throws Exception {
        // Arrange
        when(productService.getOnSaleProducts()).thenReturn(Collections.emptyList());

        // Act & Assert
        mockMvc.perform(get("/products"))
                .andExpect(status().isOk())
                .andExpect(model().attributeExists("productListItemForm"))
                .andExpect(model().attribute("productListItemForm", instanceOf(ProductListItemForm.class)));
    }

    /**
     * C-07: Serviceが例外をスローした場合に例外が伝播することを検証する。
     */
    @Test
    @DisplayName("C-07: Serviceが例外をスローした場合、例外が伝播する")
    void c07_showProducts_propagatesExceptionWhenServiceThrows() {
        // Arrange
        when(productService.getOnSaleProducts()).thenThrow(new RuntimeException("service failure"));

        // Act & Assert
        assertThatThrownBy(() -> mockMvc.perform(get("/products")))
                .hasRootCauseInstanceOf(RuntimeException.class)
                .hasRootCauseMessage("service failure");
    }

    /**
     * C-08: 商品詳細画面が表示されることを検証する。
     */
    @Test
    @DisplayName("C-08: 有効な商品IDで商品詳細画面を表示できる")
    void c08_showProductDetail_rendersProductsDetailView() throws Exception {
        ProductModel product = buildProduct(1, "ワイヤレスイヤホン", "ノイズキャンセリング対応", 5980, 10, "ON_SALE",
                "/images/products/1.png");
        when(productService.getOnSaleProduct(1)).thenReturn(product);

        mockMvc.perform(get("/products/1"))
                .andExpect(status().isOk())
                .andExpect(view().name("products-detail"))
                .andExpect(model().attributeExists("product"))
                .andExpect(content().string(containsString("ワイヤレスイヤホン")));
    }

    /**
     * C-08-1: 商品説明が表示されることを検証する。
     */
    @Test
    @DisplayName("C-08-1: 商品詳細画面で商品説明が表示される")
    void c08_1_showProductDetail_displaysDescription() throws Exception {
        ProductModel product = buildProduct(1, "ワイヤレスイヤホン", "ノイズキャンセリング対応", 5980, 10, "ON_SALE",
                "/images/products/1.png");
        when(productService.getOnSaleProduct(1)).thenReturn(product);

        mockMvc.perform(get("/products/1"))
                .andExpect(status().isOk())
                .andExpect(content().string(containsString("ノイズキャンセリング対応")));
    }

    /**
     * C-08-2: 商品IDが表示されることを検証する。
     */
    @Test
    @DisplayName("C-08-2: 商品詳細画面で商品IDが表示される")
    void c08_2_showProductDetail_displaysProductId() throws Exception {
        ProductModel product = buildProduct(1, "ワイヤレスイヤホン", "ノイズキャンセリング対応", 5980, 10, "ON_SALE",
                "/images/products/1.png");
        when(productService.getOnSaleProduct(1)).thenReturn(product);

        mockMvc.perform(get("/products/1"))
                .andExpect(status().isOk())
                .andExpect(content().string(containsString("商品ID")))
                .andExpect(content().string(containsString(">1<")));
    }

    /**
     * C-08-3: 価格が表示されることを検証する。
     */
    @Test
    @DisplayName("C-08-3: 商品詳細画面で価格が表示される")
    void c08_3_showProductDetail_displaysPrice() throws Exception {
        ProductModel product = buildProduct(1, "ワイヤレスイヤホン", "ノイズキャンセリング対応", 5980, 10, "ON_SALE",
                "/images/products/1.png");
        when(productService.getOnSaleProduct(1)).thenReturn(product);

        mockMvc.perform(get("/products/1"))
                .andExpect(status().isOk())
                .andExpect(content().string(containsString("¥5,980")));
    }

    /**
     * C-08-4: 在庫状況と販売ステータスが表示されることを検証する。
     */
    @Test
    @DisplayName("C-08-4: 商品詳細画面で在庫状況と販売ステータスが表示される")
    void c08_4_showProductDetail_displaysStockStatusAndSaleStatus() throws Exception {
        ProductModel product = buildProduct(1, "ワイヤレスイヤホン", "ノイズキャンセリング対応", 5980, 10, "ON_SALE",
                "/images/products/1.png");
        when(productService.getOnSaleProduct(1)).thenReturn(product);

        mockMvc.perform(get("/products/1"))
                .andExpect(status().isOk())
                .andExpect(content().string(containsString("在庫あり")))
                .andExpect(content().string(containsString("販売中")));
    }

    /**
     * C-08-5: 商品詳細画面でカートリンクが表示されることを検証する。
     */
    @Test
    @DisplayName("C-08-5: 商品詳細画面でカート画面へのリンクが表示される")
    void c08_5_showProductDetail_displaysCartLink() throws Exception {
        ProductModel product = buildProduct(1, "ワイヤレスイヤホン", "ノイズキャンセリング対応", 5980, 10, "ON_SALE",
                "/images/products/1.png");
        when(productService.getOnSaleProduct(1)).thenReturn(product);

        mockMvc.perform(get("/products/1"))
                .andExpect(status().isOk())
                .andExpect(content().string(containsString("href=\"/cart\"")))
                .andExpect(content().string(containsString("カートを見る")));
    }

    /**
     * C-08-6: 商品詳細画面で一覧への戻りリンクが表示されることを検証する。
     */
    @Test
    @DisplayName("C-08-6: 商品詳細画面で商品一覧に戻るリンクが表示される")
    void c08_6_showProductDetail_displaysBackToProductsLink() throws Exception {
        ProductModel product = buildProduct(1, "ワイヤレスイヤホン", "ノイズキャンセリング対応", 5980, 10, "ON_SALE",
                "/images/products/1.png");
        when(productService.getOnSaleProduct(1)).thenReturn(product);

        mockMvc.perform(get("/products/1"))
                .andExpect(status().isOk())
                .andExpect(content().string(containsString("href=\"/products\"")))
                .andExpect(content().string(containsString("商品一覧に戻る")));
    }

    /**
     * C-08-7: 商品詳細画面で在庫数の数値が表示されることを検証する。（PD-C-008）
     */
    @Test
    @DisplayName("C-08-7: 商品詳細画面で在庫数の数値が表示される")
    void c08_7_showProductDetail_displaysStockCount() throws Exception {
        ProductModel product = buildProduct(1, "ワイヤレスイヤホン", "ノイズキャンセリング対応", 5980, 10, "ON_SALE",
                "/images/products/1.png");
        when(productService.getOnSaleProduct(1)).thenReturn(product);

        mockMvc.perform(get("/products/1"))
                .andExpect(status().isOk())
                .andExpect(content().string(containsString("10点")));
    }

    /**
     * C-08-8: 商品詳細画面でstock=0の場合「在庫なし」が表示されることを検証する。（PD-C-009）
     */
    @Test
    @DisplayName("C-08-8: 商品詳細画面でstock=0の場合「在庫なし」が表示される")
    void c08_8_showProductDetail_displaysOutOfStockWhenZero() throws Exception {
        ProductModel product = buildProduct(1, "ワイヤレスイヤホン", "ノイズキャンセリング対応", 5980, 0, "ON_SALE",
                "/images/products/1.png");
        when(productService.getOnSaleProduct(1)).thenReturn(product);

        mockMvc.perform(get("/products/1"))
                .andExpect(status().isOk())
                .andExpect(content().string(containsString("在庫なし")));
    }

    /**
     * C-08-9: 商品詳細画面で商品画像のsrc属性が表示されることを検証する。（PD-C-018）
     */
    @Test
    @DisplayName("C-08-9: 商品詳細画面で商品画像のsrc属性が表示される")
    void c08_9_showProductDetail_displaysProductImage() throws Exception {
        ProductModel product = buildProduct(1, "ワイヤレスイヤホン", "ノイズキャンセリング対応", 5980, 10, "ON_SALE",
                "/images/products/1.png");
        when(productService.getOnSaleProduct(1)).thenReturn(product);

        mockMvc.perform(get("/products/1"))
                .andExpect(status().isOk())
                .andExpect(content().string(containsString("src=\"/images/products/1.png\"")));
    }

    /**
     * C-08-10: 商品詳細画面で数量入力フォームが表示されることを検証する。（PD-C-019）
     */
    @Test
    @DisplayName("C-08-10: 商品詳細画面で数量入力フォームが表示される")
    void c08_10_showProductDetail_displaysQuantityInput() throws Exception {
        ProductModel product = buildProduct(1, "ワイヤレスイヤホン", "ノイズキャンセリング対応", 5980, 10, "ON_SALE",
                "/images/products/1.png");
        when(productService.getOnSaleProduct(1)).thenReturn(product);

        mockMvc.perform(get("/products/1"))
                .andExpect(status().isOk())
                .andExpect(content().string(containsString("name=\"quantity\"")));
    }

    /**
     * C-08-11: 商品詳細画面でstock=0の場合カート追加ボタンがdisabledになることを検証する。（PD-C-020）
     */
    @Test
    @DisplayName("C-08-11: 商品詳細画面でstock=0の場合カート追加ボタンがdisabledになる")
    void c08_11_showProductDetail_disablesCartButtonWhenOutOfStock() throws Exception {
        ProductModel product = buildProduct(1, "ワイヤレスイヤホン", "ノイズキャンセリング対応", 5980, 0, "ON_SALE",
                "/images/products/1.png");
        when(productService.getOnSaleProduct(1)).thenReturn(product);

        mockMvc.perform(get("/products/1"))
                .andExpect(status().isOk())
                .andExpect(content().string(containsString("disabled")));
    }

    /**
     * C-09: 存在しない商品ID指定時は商品一覧にリダイレクトすることを検証する。
     */
    @Test
    @DisplayName("C-09: 存在しない商品ID指定時は /products にリダイレクトする")
    void c09_showProductDetail_redirectsWhenProductNotFound() throws Exception {
        when(productService.getOnSaleProduct(9999)).thenReturn(null);

        mockMvc.perform(get("/products/9999"))
                .andExpect(status().is3xxRedirection())
                .andExpect(redirectedUrl("/products"));
    }

    /**
     * C-10: カート追加が成功し、元画面へリダイレクトされることを検証する。
     */
    @Test
    @DisplayName("C-10: POST /cart/items の成功時はReferer先にリダイレクトされる")
    void c10_addItem_redirectsBackToRefererOnSuccess() throws Exception {
        mockMvc.perform(post("/cart/items")
                        .header("Referer", "http://localhost/products/1")
                        .param("productId", "1")
                        .param("quantity", "1"))
                .andExpect(status().is3xxRedirection())
                .andExpect(redirectedUrl("/products/1"))
                .andExpect(flash().attributeExists("successMessage"));

        verify(cartService, times(1)).addItem(1, 1);
    }

    /**
     * C-11: Referer がない場合は商品一覧へ戻ることを検証する。
     */
    @Test
    @DisplayName("C-11: RefererなしのPOST /cart/items 成功時は /products にリダイレクトされる")
    void c11_addItem_redirectsToProductsWhenRefererMissing() throws Exception {
        mockMvc.perform(post("/cart/items")
                        .param("productId", "1")
                        .param("quantity", "1"))
                .andExpect(status().is3xxRedirection())
                .andExpect(redirectedUrl("/products"))
                .andExpect(flash().attributeExists("successMessage"));

        verify(cartService, times(1)).addItem(1, 1);
    }

    /**
     * C-12: 不正な Referer は商品一覧へフォールバックすることを検証する。
     */
    @Test
    @DisplayName("C-12: 不正なRefererのPOST /cart/items 成功時は /products にリダイレクトされる")
    void c12_addItem_redirectsToProductsWhenRefererIsUnsupported() throws Exception {
        mockMvc.perform(post("/cart/items")
                        .header("Referer", "http://localhost/orders/confirm")
                        .param("productId", "1")
                        .param("quantity", "1"))
                .andExpect(status().is3xxRedirection())
                .andExpect(redirectedUrl("/products"))
                .andExpect(flash().attributeExists("successMessage"));

        verify(cartService, times(1)).addItem(1, 1);
    }

    /**
     * C-13: 詳細画面のバリデーションエラー時は同画面を再表示することを検証する。
     */
    @Test
    @DisplayName("C-13: 商品詳細画面から数量不正でPOSTした場合は products-detail を再表示する")
    void c13_addItem_rendersDetailViewWhenValidationFailsFromDetail() throws Exception {
        ProductModel product = buildProduct(1, "ワイヤレスイヤホン", "ノイズキャンセリング対応", 5980, 10, "ON_SALE",
                "/images/products/1.png");
        when(productService.getOnSaleProduct(1)).thenReturn(product);

        mockMvc.perform(post("/cart/items")
                        .header("Referer", "http://localhost/products/1")
                        .param("productId", "1")
                        .param("quantity", "0"))
                .andExpect(status().isOk())
                .andExpect(view().name("products-detail"))
                .andExpect(model().attributeExists("product"))
                .andExpect(model().attributeExists("errorMessage"))
                .andExpect(content().string(containsString("ワイヤレスイヤホン")));

        verify(cartService, never()).addItem(1, 0);
    }

    /**
     * C-14: 業務例外時に一覧画面へフォールバックできることを検証する。
     */
    @Test
    @DisplayName("C-14: 一覧画面からのカート追加で業務例外時は products を再表示する")
    void c14_addItem_rendersProductsViewWhenBusinessErrorOccursFromList() throws Exception {
        ProductModel product = buildProduct(1, "ワイヤレスイヤホン", "ノイズキャンセリング対応", 5980, 10, "ON_SALE",
                "/images/products/1.png");
        when(productService.getOnSaleProducts()).thenReturn(List.of(product));
        doThrow(new BusinessException("error.cart.out.of.stock"))
                .when(cartService).addItem(1, 1);

        mockMvc.perform(post("/cart/items")
                        .header("Referer", "http://localhost/products")
                        .param("productId", "1")
                        .param("quantity", "1"))
                .andExpect(status().isOk())
                .andExpect(view().name("products"))
                .andExpect(model().attributeExists("products"))
                .andExpect(model().attributeExists("errorMessage"))
                .andExpect(content().string(containsString("在庫切れのためカートに追加できません。")));
    }

        /**
         * C-15: 商品詳細画面からの数量異常入力を組合せで検証する。
         */
        @ParameterizedTest
        @MethodSource("invalidQuantityProvider")
        @DisplayName("C-15: 商品詳細画面から数量異常入力時は products-detail を再表示してエラー表示する")
        void c15_addItem_invalidQuantityFromDetail_rendersDetail(String quantity) throws Exception {
                ProductModel product = buildProduct(1, "ワイヤレスイヤホン", "ノイズキャンセリング対応", 5980, 10, "ON_SALE",
                                "/images/products/1.png");
                when(productService.getOnSaleProduct(1)).thenReturn(product);

                mockMvc.perform(post("/cart/items")
                                                .header("Referer", "http://localhost/products/1")
                                                .param("productId", "1")
                                                .param("quantity", quantity))
                                .andExpect(status().isOk())
                                .andExpect(view().name("products-detail"))
                                .andExpect(model().attributeExists("errorMessage"));

                verify(cartService, never()).addItem(anyInt(), anyInt());
        }

        /**
         * C-16: 商品一覧画面からの数量異常入力を組合せで検証する。
         */
        @ParameterizedTest
        @MethodSource("invalidQuantityProvider")
        @DisplayName("C-16: 商品一覧画面から数量異常入力時は products を再表示してエラー表示する")
        void c16_addItem_invalidQuantityFromList_rendersList(String quantity) throws Exception {
                ProductModel product = buildProduct(1, "ワイヤレスイヤホン", "ノイズキャンセリング対応", 5980, 10, "ON_SALE",
                                "/images/products/1.png");
                when(productService.getOnSaleProducts()).thenReturn(List.of(product));

                mockMvc.perform(post("/cart/items")
                                                .header("Referer", "http://localhost/products")
                                                .param("productId", "1")
                                                .param("quantity", quantity))
                                .andExpect(status().isOk())
                                .andExpect(view().name("products"))
                                .andExpect(model().attributeExists("errorMessage"));

                verify(cartService, never()).addItem(anyInt(), anyInt());
        }

        /**
         * C-17: Referer の組合せに応じたリダイレクト先を検証する。
         */
        @ParameterizedTest
        @MethodSource("refererRedirectProvider")
        @DisplayName("C-17: Referer の組合せに応じてPOST /cart/items 成功時の遷移先が決まる")
        void c17_addItem_redirectsByRefererCombination(String referer, String expectedRedirect) throws Exception {
                MockHttpServletRequestBuilder request = post("/cart/items")
                                .param("productId", "1")
                                .param("quantity", "1");
                if (referer != null) {
                        request.header("Referer", referer);
                }

                mockMvc.perform(request)
                                .andExpect(status().is3xxRedirection())
                                .andExpect(redirectedUrl(expectedRedirect));

                verify(cartService, times(1)).addItem(1, 1);
        }

        /**
         * C-18: 商品詳細のPathVariable異常入力を検証する。
         */
        @ParameterizedTest
        @MethodSource("invalidProductIdProvider")
        @DisplayName("C-18: 商品詳細URLのproductIdが非数値の場合はHTTP 400")
        void c18_showProductDetail_invalidPathVariable_returnsBadRequest(String productId) throws Exception {
                mockMvc.perform(get("/products/{productId}", productId))
                                .andExpect(status().isBadRequest());
        }

        private static Stream<String> invalidQuantityProvider() {
                return Stream.of("", "0", "-1", "100", "abc", "1.5");
        }

        private static Stream<Arguments> refererRedirectProvider() {
                return Stream.of(
                                Arguments.of("http://localhost/products", "/products"),
                                Arguments.of("http://localhost/products/1", "/products/1"),
                                Arguments.of("https://example.com/products/2", "/products/2"),
                                Arguments.of("http://localhost/orders/confirm", "/products"),
                                Arguments.of("not-a-uri", "/products"),
                                Arguments.of("", "/products"),
                                Arguments.of(null, "/products"));
        }

        private static Stream<String> invalidProductIdProvider() {
                return Stream.of("abc", "1.5", "x-1");
        }

    /**
     * テスト用の商品モデルを生成する。
     *
     * @param productId 商品ID
     * @param name 商品名
     * @param description 商品説明
     * @param price 価格
     * @param stock 在庫数
     * @param status 販売状態
     * @param imageUrl 画像URL
     * @return 生成した商品モデル
     */
    private ProductModel buildProduct(Integer productId, String name, String description,
            Integer price, Integer stock, String status, String imageUrl) {
        ProductModel model = new ProductModel();
        model.setProductId(productId);
        model.setName(name);
        model.setDescription(description);
        model.setPrice(price);
        model.setStock(stock);
        model.setStatus(status);
        model.setImageUrl(imageUrl);
        return model;
    }
}