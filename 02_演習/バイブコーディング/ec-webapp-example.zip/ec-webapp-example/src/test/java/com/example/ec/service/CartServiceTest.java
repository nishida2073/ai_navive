package com.example.ec.service;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.argThat;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoInteractions;
import static org.mockito.Mockito.when;

import java.util.Collections;
import java.util.List;
import java.util.stream.Stream;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.dao.DataRetrievalFailureException;

import com.example.ec.repository.CartRepository;
import com.example.ec.repository.ProductRepository;
import com.example.ec.repository.entity.CartItemEntity;
import com.example.ec.repository.entity.ProductEntity;
import com.example.ec.service.model.CartItemModel;
import com.example.ec.service.model.CartModel;

/**
 * {@link CartService} の単体テストクラス。
 *
 * <p>データベースには接続せず、Repository を Mockito でモック化し、
 * Service 層のモデル変換・計算・更新・削除ロジックを検証する。</p>
 */
@ExtendWith(MockitoExtension.class)
class CartServiceTest {

    /** テスト対象の Service。 */
    @InjectMocks
    private CartService cartService;

    /** CartRepository のモック。 */
    @Mock
    private CartRepository cartRepository;

    /** ProductRepository のモック。 */
    @Mock
    private ProductRepository productRepository;

    /**
     * CT-S-001: カートに1件ある場合にCartModelを生成できることを検証する。
     */
    @Test
    @DisplayName("CT-S-001: カートに1件ある場合、CartModelに1件のCartItemModelが作成される")
    void ctS001_getCart_singleItem() {
        when(cartRepository.findAll()).thenReturn(List.of(cartItem(1, 1)));
        when(productRepository.findOnSaleProductsByIds(List.of(1)))
                .thenReturn(List.of(product(1, "ワイヤレスイヤホン", 5980, 10, "/images/products/1.png")));

        CartModel result = cartService.getCart();

        assertThat(result.getEmpty()).isFalse();
        assertThat(result.getItems()).hasSize(1);
        CartItemModel item = result.getItems().get(0);
        assertThat(item.getProductId()).isEqualTo(1);
        assertThat(item.getName()).isEqualTo("ワイヤレスイヤホン");
        assertThat(item.getPrice()).isEqualTo(5980);
        assertThat(item.getQuantity()).isEqualTo(1);
        assertThat(item.getSubtotal()).isEqualTo(5980);
        assertThat(result.getTotalAmount()).isEqualTo(5980);
        assertThat(result.getTotalQuantity()).isEqualTo(1);
    }

    /**
     * CT-S-002: カートに複数件ある場合に全件のCartItemModelを生成できることを検証する。
     */
    @Test
    @DisplayName("CT-S-002: カートに複数件ある場合、すべてのCartItemModelが作成される")
    void ctS002_getCart_multipleItems() {
        when(cartRepository.findAll()).thenReturn(List.of(cartItem(1, 2), cartItem(2, 1)));
        when(productRepository.findOnSaleProductsByIds(List.of(1, 2)))
                .thenReturn(List.of(
                        product(1, "ワイヤレスイヤホン", 5980, 10, "/images/products/1.png"),
                        product(2, "ゲーミングマウス", 3980, 5, "/images/products/2.png")));

        CartModel result = cartService.getCart();

        assertThat(result.getItems()).hasSize(2);
        assertThat(result.getItems().get(0).getSubtotal()).isEqualTo(11960);
        assertThat(result.getItems().get(1).getSubtotal()).isEqualTo(3980);
        assertThat(result.getTotalAmount()).isEqualTo(15940);
        assertThat(result.getTotalQuantity()).isEqualTo(3);
        assertThat(result.getEmpty()).isFalse();
    }

    /**
     * CT-S-003: Repository が空リストを返した場合に空のCartModelを返すことを検証する。
     */
    @Test
    @DisplayName("CT-S-003: cartRepositoryが空リストを返した場合、空のCartModelが返る")
    void ctS003_getCart_emptyList() {
        when(cartRepository.findAll()).thenReturn(Collections.emptyList());

        CartModel result = cartService.getCart();

        assertThat(result.getEmpty()).isTrue();
        assertThat(result.getItems()).isEmpty();
        assertThat(result.getTotalAmount()).isZero();
        assertThat(result.getTotalQuantity()).isZero();
        verifyNoInteractions(productRepository);
    }

    /**
     * CT-S-004: Repository が null を返した場合に空のCartModelを返すことを検証する。
     */
    @Test
    @DisplayName("CT-S-004: cartRepositoryがnullを返した場合でも異常終了せず空のCartModelが返る")
    void ctS004_getCart_nullList() {
        when(cartRepository.findAll()).thenReturn(null);

        CartModel result = cartService.getCart();

        assertThat(result.getEmpty()).isTrue();
        assertThat(result.getItems()).isEmpty();
        assertThat(result.getTotalAmount()).isZero();
        assertThat(result.getTotalQuantity()).isZero();
        verifyNoInteractions(productRepository);
    }

    /**
     * CT-S-005: 販売停止・非存在商品が除外されることを検証する。
     */
    @Test
    @DisplayName("CT-S-005: 商品Repositoryで取得できない商品IDはカート表示から除外される")
    void ctS005_getCart_excludesUnavailableProducts() {
        when(cartRepository.findAll()).thenReturn(List.of(cartItem(1, 2), cartItem(9999, 5)));
        when(productRepository.findOnSaleProductsByIds(List.of(1, 9999)))
                .thenReturn(List.of(product(1, "ワイヤレスイヤホン", 5980, 10, "/images/products/1.png")));

        CartModel result = cartService.getCart();

        assertThat(result.getItems()).hasSize(1);
        assertThat(result.getItems().get(0).getProductId()).isEqualTo(1);
        assertThat(result.getTotalAmount()).isEqualTo(11960);
        assertThat(result.getTotalQuantity()).isEqualTo(2);
    }

    /**
     * CT-S-006: 価格0円の商品があっても計算できることを検証する。
     */
    @Test
    @DisplayName("CT-S-006: 価格0円の商品を含む場合でも小計・合計が正しく計算される")
    void ctS006_getCart_zeroPrice() {
        when(cartRepository.findAll()).thenReturn(List.of(cartItem(1, 1), cartItem(2, 2)));
        when(productRepository.findOnSaleProductsByIds(List.of(1, 2)))
                .thenReturn(List.of(
                        product(1, "無料サンプル", 0, 99, "/images/products/free.png"),
                        product(2, "ワイヤレスイヤホン", 5980, 10, "/images/products/1.png")));

        CartModel result = cartService.getCart();

        assertThat(result.getItems()).hasSize(2);
        assertThat(result.getItems().get(0).getSubtotal()).isZero();
        assertThat(result.getItems().get(1).getSubtotal()).isEqualTo(11960);
        assertThat(result.getTotalAmount()).isEqualTo(11960);
        assertThat(result.getTotalQuantity()).isEqualTo(3);
    }

    /**
     * CT-S-007: 数量1の境界値計算を検証する。
     */
    @Test
    @DisplayName("CT-S-007: 単価5980円・数量1の小計が5980円になる")
    void ctS007_getCart_subtotalBoundaryQuantityOne() {
        when(cartRepository.findAll()).thenReturn(List.of(cartItem(1, 1)));
        when(productRepository.findOnSaleProductsByIds(List.of(1)))
                .thenReturn(List.of(product(1, "ワイヤレスイヤホン", 5980, 10, "/images/products/1.png")));

        CartModel result = cartService.getCart();

        assertThat(result.getItems().get(0).getSubtotal()).isEqualTo(5980);
    }

    /**
     * CT-S-008: 数量99の境界値計算を検証する。
     */
    @Test
    @DisplayName("CT-S-008: 単価5980円・数量99の小計が592020円になる")
    void ctS008_getCart_subtotalBoundaryQuantityNinetyNine() {
        when(cartRepository.findAll()).thenReturn(List.of(cartItem(1, 99)));
        when(productRepository.findOnSaleProductsByIds(List.of(1)))
                .thenReturn(List.of(product(1, "ワイヤレスイヤホン", 5980, 100, "/images/products/1.png")));

        CartModel result = cartService.getCart();

        assertThat(result.getItems().get(0).getSubtotal()).isEqualTo(592020);
        assertThat(result.getTotalAmount()).isEqualTo(592020);
    }

    /**
     * CT-S-009: 単価null/数量nullを0として扱えることを検証する。
     */
    @Test
    @DisplayName("CT-S-009: 単価null・数量nullは0として扱われ、小計計算で異常終了しない")
    void ctS009_getCart_nullPriceAndQuantityHandledAsZero() {
        ProductEntity product = product(1, "ワイヤレスイヤホン", null, 10, "/images/products/1.png");
        when(cartRepository.findAll()).thenReturn(List.of(cartItem(1, null)));
        when(productRepository.findOnSaleProductsByIds(List.of(1))).thenReturn(List.of(product));

        CartModel result = cartService.getCart();

        assertThat(result.getItems()).hasSize(1);
        assertThat(result.getItems().get(0).getPrice()).isZero();
        assertThat(result.getItems().get(0).getQuantity()).isZero();
        assertThat(result.getItems().get(0).getSubtotal()).isZero();
        assertThat(result.getTotalAmount()).isZero();
        assertThat(result.getTotalQuantity()).isZero();
    }

    /**
     * CT-S-010: Repository例外が呼び出し元へ伝播することを検証する。
     */
    @Test
    @DisplayName("CT-S-010: cartRepository.findAllで例外が発生した場合、例外が伝播する")
    void ctS010_getCart_propagatesRepositoryException() {
        when(cartRepository.findAll()).thenThrow(new DataRetrievalFailureException("cart findAll error"));

        assertThatThrownBy(() -> cartService.getCart())
                .isInstanceOf(DataRetrievalFailureException.class)
                .hasMessage("cart findAll error");
    }

    /**
     * CT-S-011: 数量1で更新処理が呼び出されることを検証する。
     */
    @Test
    @DisplayName("CT-S-011: 数量1でupdateQuantityを呼ぶとRepository更新が実行される")
    void ctS011_updateQuantity_minBoundary() {
        when(cartRepository.findByProductId(1)).thenReturn(cartItem(1, 5));
        when(productRepository.findOnSaleProductById(1)).thenReturn(product(1, "ワイヤレスイヤホン", 5980, 10, "/images/products/1.png"));

        cartService.updateQuantity(1, 1);

        verify(cartRepository, times(1)).updateQuantity(1, 1);
    }

    /**
     * CT-S-012: 数量99で更新処理が呼び出されることを検証する。
     */
    @Test
    @DisplayName("CT-S-012: 数量99でupdateQuantityを呼ぶとRepository更新が実行される")
    void ctS012_updateQuantity_maxBoundary() {
        when(cartRepository.findByProductId(1)).thenReturn(cartItem(1, 5));
        when(productRepository.findOnSaleProductById(1)).thenReturn(product(1, "ワイヤレスイヤホン", 5980, 120, "/images/products/1.png"));

        cartService.updateQuantity(1, 99);

        verify(cartRepository, times(1)).updateQuantity(1, 99);
    }

    /**
     * CT-S-013: 数量nullを異常系として扱うことを検証する。
     */
    @Test
    @DisplayName("CT-S-013: 数量nullは範囲外としてIllegalArgumentExceptionになる")
    void ctS013_updateQuantity_null() {
        assertThatThrownBy(() -> cartService.updateQuantity(1, null))
                .isInstanceOf(IllegalArgumentException.class)
                .hasMessage("error.cart.quantity.range");

        verifyNoInteractions(cartRepository, productRepository);
    }

    /**
     * CT-S-014: 数量0を異常系として扱うことを検証する。
     */
    @Test
    @DisplayName("CT-S-014: 数量0は範囲外としてIllegalArgumentExceptionになる")
    void ctS014_updateQuantity_zero() {
        assertThatThrownBy(() -> cartService.updateQuantity(1, 0))
                .isInstanceOf(IllegalArgumentException.class)
                .hasMessage("error.cart.quantity.range");

        verifyNoInteractions(cartRepository, productRepository);
    }

    /**
     * CT-S-015: 数量負数を異常系として扱うことを検証する。
     */
    @Test
    @DisplayName("CT-S-015: 数量-1は範囲外としてIllegalArgumentExceptionになる")
    void ctS015_updateQuantity_negative() {
        assertThatThrownBy(() -> cartService.updateQuantity(1, -1))
                .isInstanceOf(IllegalArgumentException.class)
                .hasMessage("error.cart.quantity.range");

        verifyNoInteractions(cartRepository, productRepository);
    }

    /**
     * CT-S-016: 数量100を異常系として扱うことを検証する。
     */
    @Test
    @DisplayName("CT-S-016: 数量100は範囲外としてIllegalArgumentExceptionになる")
    void ctS016_updateQuantity_overMax() {
        assertThatThrownBy(() -> cartService.updateQuantity(1, 100))
                .isInstanceOf(IllegalArgumentException.class)
                .hasMessage("error.cart.quantity.range");

        verifyNoInteractions(cartRepository, productRepository);
    }

    /**
     * CT-S-017: 存在しない商品ID更新で例外となることを検証する。
     */
    @Test
    @DisplayName("CT-S-017: カートに存在しない商品IDを更新すると業務例外になる")
    void ctS017_updateQuantity_nonExistingCartItem() {
        when(cartRepository.findByProductId(9999)).thenReturn(null);

        assertThatThrownBy(() -> cartService.updateQuantity(9999, 5))
                .isInstanceOf(IllegalArgumentException.class)
                .hasMessage("error.cart.item.not.found");

        verify(cartRepository, times(1)).findByProductId(9999);
        verify(productRepository, never()).findOnSaleProductById(9999);
        verify(cartRepository, never()).updateQuantity(9999, 5);
    }

    /**
     * CT-S-018: 販売停止商品更新で例外となることを検証する。
     */
    @Test
    @DisplayName("CT-S-018: 販売中でない商品を更新すると業務例外になる")
    void ctS018_updateQuantity_productNotOnSale() {
        when(cartRepository.findByProductId(1)).thenReturn(cartItem(1, 2));
        when(productRepository.findOnSaleProductById(1)).thenReturn(null);

        assertThatThrownBy(() -> cartService.updateQuantity(1, 3))
                .isInstanceOf(IllegalArgumentException.class)
                .hasMessage("error.cart.product.not.on.sale");

        verify(cartRepository, never()).updateQuantity(1, 3);
    }

    /**
     * CT-S-019: 在庫超過更新で例外となることを検証する。
     */
    @Test
    @DisplayName("CT-S-019: 在庫数を超える数量を指定した場合は業務例外になる")
    void ctS019_updateQuantity_exceedsStock() {
        when(cartRepository.findByProductId(1)).thenReturn(cartItem(1, 2));
        when(productRepository.findOnSaleProductById(1)).thenReturn(product(1, "ワイヤレスイヤホン", 5980, 5, "/images/products/1.png"));

        assertThatThrownBy(() -> cartService.updateQuantity(1, 10))
                .isInstanceOf(IllegalArgumentException.class)
                .hasMessage("error.cart.quantity.over.stock");

        verify(cartRepository, never()).updateQuantity(1, 10);
    }

    /**
     * CT-S-020: 更新処理中のRepository例外が伝播することを検証する。
     */
    @Test
    @DisplayName("CT-S-020: cartRepository.updateQuantityで例外が発生した場合、例外が伝播する")
    void ctS020_updateQuantity_propagatesRepositoryException() {
        when(cartRepository.findByProductId(1)).thenReturn(cartItem(1, 2));
        when(productRepository.findOnSaleProductById(1)).thenReturn(product(1, "ワイヤレスイヤホン", 5980, 10, "/images/products/1.png"));
        when(cartRepository.updateQuantity(1, 2)).thenThrow(new DataRetrievalFailureException("update error"));

        assertThatThrownBy(() -> cartService.updateQuantity(1, 2))
                .isInstanceOf(DataRetrievalFailureException.class)
                .hasMessage("update error");
    }

    /**
     * CT-S-021: 存在する商品IDを指定した削除を検証する。
     */
    @Test
    @DisplayName("CT-S-021: 存在する商品IDを削除するとdeleteByProductIdが呼ばれる")
    void ctS021_deleteItem_existing() {
        when(cartRepository.findByProductId(1)).thenReturn(cartItem(1, 1));

        cartService.deleteItem(1);

        verify(cartRepository, times(1)).deleteByProductId(1);
    }

    /**
     * CT-S-022: 存在しない商品IDを指定した削除を検証する。
     */
    @Test
    @DisplayName("CT-S-022: 存在しない商品IDを削除した場合は静かに終了する")
    void ctS022_deleteItem_nonExisting() {
        when(cartRepository.findByProductId(9999)).thenReturn(null);

        cartService.deleteItem(9999);

        verify(cartRepository, times(1)).findByProductId(9999);
        verify(cartRepository, never()).deleteByProductId(9999);
    }

    /**
     * CT-S-023: 削除後のカート内容を再取得したとき、Repository応答どおりになることを検証する。
     */
    @Test
    @DisplayName("CT-S-023: 削除後にgetCartを呼ぶと、削除後データに基づいてモデルが作成される")
    void ctS023_deleteItem_thenGetCartReflectsRepositoryState() {
        when(cartRepository.findByProductId(2)).thenReturn(cartItem(2, 1));

        when(cartRepository.findAll())
                .thenReturn(List.of(cartItem(1, 2), cartItem(2, 1)))
                .thenReturn(List.of(cartItem(1, 2)));
        when(productRepository.findOnSaleProductsByIds(anyList()))
                .thenReturn(List.of(
                        product(1, "ワイヤレスイヤホン", 5980, 10, "/images/products/1.png"),
                        product(2, "ゲーミングマウス", 3980, 5, "/images/products/2.png")))
                .thenReturn(List.of(product(1, "ワイヤレスイヤホン", 5980, 10, "/images/products/1.png")));

        CartModel before = cartService.getCart();
        cartService.deleteItem(2);
        CartModel after = cartService.getCart();

        assertThat(before.getItems()).hasSize(2);
        assertThat(after.getItems()).hasSize(1);
        assertThat(after.getItems().get(0).getProductId()).isEqualTo(1);
        verify(cartRepository, times(1)).deleteByProductId(2);
    }

    /**
     * CT-S-024: 削除時のRepository例外が伝播することを検証する。
     */
    @Test
    @DisplayName("CT-S-024: cartRepository.findByProductIdで例外が発生した場合、例外が伝播する")
    void ctS024_deleteItem_propagatesRepositoryException() {
        when(cartRepository.findByProductId(1)).thenThrow(new DataRetrievalFailureException("delete find error"));

        assertThatThrownBy(() -> cartService.deleteItem(1))
                .isInstanceOf(DataRetrievalFailureException.class)
                .hasMessage("delete find error");
    }

    /**
     * CT-S-025: 在庫null時に在庫0として在庫超過判定されることを検証する。
     */
    @Test
    @DisplayName("CT-S-025: 商品在庫がnullの場合、在庫0として在庫超過例外になる")
    void ctS025_updateQuantity_nullStock() {
        when(cartRepository.findByProductId(1)).thenReturn(cartItem(1, 1));
        when(productRepository.findOnSaleProductById(1)).thenReturn(product(1, "ワイヤレスイヤホン", 5980, null, "/images/products/1.png"));

        assertThatThrownBy(() -> cartService.updateQuantity(1, 1))
                .isInstanceOf(IllegalArgumentException.class)
                .hasMessage("error.cart.quantity.over.stock");

        verify(cartRepository, never()).updateQuantity(1, 1);
    }

    /**
     * CT-S-026: 新規商品の最小数量追加を検証する。
     */
    @Test
    @DisplayName("CT-S-026: 新規商品を数量1で追加するとinsertが呼ばれる")
    void ctS026_addItem_newProductWithMinQuantity() {
        when(productRepository.findOnSaleProductById(1)).thenReturn(product(1, "ワイヤレスイヤホン", 5980, 10, "/images/products/1.png"));
        when(cartRepository.findByProductId(1)).thenReturn(null);

        cartService.addItem(1, 1);

        verify(cartRepository, times(1)).insert(argThat(item -> item.getProductId().equals(1) && item.getQuantity().equals(1)));
        verify(cartRepository, never()).updateQuantity(1, 1);
    }

    /**
     * CT-S-027: 新規商品の最大数量追加を検証する。
     */
    @Test
    @DisplayName("CT-S-027: 新規商品を数量99で追加するとinsertが呼ばれる")
    void ctS027_addItem_newProductWithMaxQuantity() {
        when(productRepository.findOnSaleProductById(1)).thenReturn(product(1, "ワイヤレスイヤホン", 5980, 120, "/images/products/1.png"));
        when(cartRepository.findByProductId(1)).thenReturn(null);

        cartService.addItem(1, 99);

        verify(cartRepository, times(1)).insert(argThat(item -> item.getProductId().equals(1) && item.getQuantity().equals(99)));
    }

    /**
     * CT-S-028: 数量null追加を異常系として扱うことを検証する。
     */
    @Test
    @DisplayName("CT-S-028: 数量nullでaddItemするとIllegalArgumentExceptionになる")
    void ctS028_addItem_nullQuantity() {
        assertThatThrownBy(() -> cartService.addItem(1, null))
                .isInstanceOf(IllegalArgumentException.class)
                .hasMessage("error.cart.quantity.range");

        verifyNoInteractions(cartRepository, productRepository);
    }

    /**
     * CT-S-029: 数量0追加を異常系として扱うことを検証する。
     */
    @Test
    @DisplayName("CT-S-029: 数量0でaddItemするとIllegalArgumentExceptionになる")
    void ctS029_addItem_zeroQuantity() {
        assertThatThrownBy(() -> cartService.addItem(1, 0))
                .isInstanceOf(IllegalArgumentException.class)
                .hasMessage("error.cart.quantity.range");

        verifyNoInteractions(cartRepository, productRepository);
    }

    /**
     * CT-S-030: 数量100追加を異常系として扱うことを検証する。
     */
    @Test
    @DisplayName("CT-S-030: 数量100でaddItemするとIllegalArgumentExceptionになる")
    void ctS030_addItem_overMaxQuantity() {
        assertThatThrownBy(() -> cartService.addItem(1, 100))
                .isInstanceOf(IllegalArgumentException.class)
                .hasMessage("error.cart.quantity.range");

        verifyNoInteractions(cartRepository, productRepository);
    }

    /**
     * CT-S-031: 販売中でない商品追加を異常系として扱うことを検証する。
     */
    @Test
    @DisplayName("CT-S-031: 販売中でない商品をaddItemすると業務例外になる")
    void ctS031_addItem_productNotOnSale() {
        when(productRepository.findOnSaleProductById(1)).thenReturn(null);

        assertThatThrownBy(() -> cartService.addItem(1, 1))
                .isInstanceOf(IllegalArgumentException.class)
                .hasMessage("error.cart.product.not.on.sale");

        verify(cartRepository, never()).insert(any());
    }

    /**
     * CT-S-032: 在庫切れ商品の追加を異常系として扱うことを検証する。
     */
    @Test
    @DisplayName("CT-S-032: 在庫0の商品をaddItemすると在庫切れ例外になる")
    void ctS032_addItem_outOfStock() {
        when(productRepository.findOnSaleProductById(1)).thenReturn(product(1, "USB-Cハブ", 2980, 0, "/images/products/3.png"));

        assertThatThrownBy(() -> cartService.addItem(1, 1))
                .isInstanceOf(IllegalArgumentException.class)
                .hasMessage("error.cart.out.of.stock");

        verify(cartRepository, never()).insert(any());
    }

    /**
     * CT-S-033: 在庫数超過追加を異常系として扱うことを検証する。
     */
    @Test
    @DisplayName("CT-S-033: 在庫数を超える数量でaddItemすると業務例外になる")
    void ctS033_addItem_quantityExceedsStock() {
        when(productRepository.findOnSaleProductById(1)).thenReturn(product(1, "ワイヤレスイヤホン", 5980, 5, "/images/products/1.png"));

        assertThatThrownBy(() -> cartService.addItem(1, 6))
                .isInstanceOf(IllegalArgumentException.class)
                .hasMessage("error.cart.quantity.over.stock");

        verify(cartRepository, never()).insert(any());
    }

    /**
     * CT-S-034: 既存商品追加時に数量が加算更新されることを検証する。
     */
    @Test
    @DisplayName("CT-S-034: 既存商品に数量を追加すると合計数量でupdateQuantityが呼ばれる")
    void ctS034_addItem_existingItemUpdatesMergedQuantity() {
        when(productRepository.findOnSaleProductById(1)).thenReturn(product(1, "ワイヤレスイヤホン", 5980, 10, "/images/products/1.png"));
        when(cartRepository.findByProductId(1)).thenReturn(cartItem(1, 2));

        cartService.addItem(1, 3);

        verify(cartRepository, times(1)).updateQuantity(1, 5);
        verify(cartRepository, never()).insert(any());
    }

    /**
     * CT-S-035: 既存数量nullは0として加算されることを検証する。
     */
    @Test
    @DisplayName("CT-S-035: 既存数量nullの商品にaddItemすると数量0起点で加算更新される")
    void ctS035_addItem_existingNullQuantityHandledAsZero() {
        when(productRepository.findOnSaleProductById(1)).thenReturn(product(1, "ワイヤレスイヤホン", 5980, 10, "/images/products/1.png"));
        when(cartRepository.findByProductId(1)).thenReturn(cartItem(1, null));

        cartService.addItem(1, 2);

        verify(cartRepository, times(1)).updateQuantity(1, 2);
    }

    /**
     * CT-S-036: 加算後数量が99超過の場合に例外となることを検証する。
     */
    @Test
    @DisplayName("CT-S-036: 既存数量と追加数量の合計が100以上なら業務例外になる")
    void ctS036_addItem_totalQuantityExceedsMax() {
        when(productRepository.findOnSaleProductById(1)).thenReturn(product(1, "ワイヤレスイヤホン", 5980, 150, "/images/products/1.png"));
        when(cartRepository.findByProductId(1)).thenReturn(cartItem(1, 98));

        assertThatThrownBy(() -> cartService.addItem(1, 2))
                .isInstanceOf(IllegalArgumentException.class)
                .hasMessage("error.cart.quantity.over.max");

        verify(cartRepository, never()).updateQuantity(1, 100);
    }

    /**
     * CT-S-037: 加算後数量が在庫超過の場合に例外となることを検証する。
     */
    @Test
    @DisplayName("CT-S-037: 既存数量と追加数量の合計が在庫数を超えると業務例外になる")
    void ctS037_addItem_totalQuantityExceedsStock() {
        when(productRepository.findOnSaleProductById(1)).thenReturn(product(1, "ワイヤレスイヤホン", 5980, 5, "/images/products/1.png"));
        when(cartRepository.findByProductId(1)).thenReturn(cartItem(1, 4));

        assertThatThrownBy(() -> cartService.addItem(1, 2))
                .isInstanceOf(IllegalArgumentException.class)
                .hasMessage("error.cart.total.quantity.over.stock");

        verify(cartRepository, never()).updateQuantity(1, 6);
    }

    /**
     * CT-S-038: 新規追加時のRepository例外が伝播することを検証する。
     */
    @Test
    @DisplayName("CT-S-038: addItem の insert で例外が発生した場合、例外が伝播する")
    void ctS038_addItem_insertExceptionPropagates() {
        when(productRepository.findOnSaleProductById(1)).thenReturn(product(1, "ワイヤレスイヤホン", 5980, 10, "/images/products/1.png"));
        when(cartRepository.findByProductId(1)).thenReturn(null);
        doThrow(new DataRetrievalFailureException("insert error")).when(cartRepository).insert(any(CartItemEntity.class));

        assertThatThrownBy(() -> cartService.addItem(1, 1))
                .isInstanceOf(DataRetrievalFailureException.class)
                .hasMessage("insert error");
    }

    /**
     * CT-S-039: 既存商品更新時のRepository例外が伝播することを検証する。
     */
    @Test
    @DisplayName("CT-S-039: addItem の updateQuantity で例外が発生した場合、例外が伝播する")
    void ctS039_addItem_updateExceptionPropagates() {
        when(productRepository.findOnSaleProductById(1)).thenReturn(product(1, "ワイヤレスイヤホン", 5980, 10, "/images/products/1.png"));
        when(cartRepository.findByProductId(1)).thenReturn(cartItem(1, 2));
        when(cartRepository.updateQuantity(1, 3)).thenThrow(new DataRetrievalFailureException("merge update error"));

        assertThatThrownBy(() -> cartService.addItem(1, 1))
                .isInstanceOf(DataRetrievalFailureException.class)
                .hasMessage("merge update error");
    }

    /**
     * CT-S-040: 単価×数量の直積ケースで小計・合計計算を検証する。
     */
    @ParameterizedTest
    @MethodSource("priceQuantityCartesianProvider")
    @DisplayName("CT-S-040: 単価×数量の直積ケースで getCart の小計・合計が正しい")
    void ctS040_getCart_priceQuantityCartesian(Integer price, Integer quantity, Integer expectedSubtotal) {
        when(cartRepository.findAll()).thenReturn(List.of(cartItem(1, quantity)));
        when(productRepository.findOnSaleProductsByIds(List.of(1)))
                .thenReturn(List.of(product(1, "テスト商品", price, 200, "/images/products/1.png")));

        CartModel result = cartService.getCart();

        assertThat(result.getItems()).hasSize(1);
        assertThat(result.getItems().get(0).getSubtotal()).isEqualTo(expectedSubtotal);
        assertThat(result.getTotalAmount()).isEqualTo(expectedSubtotal);
        assertThat(result.getTotalQuantity()).isEqualTo(quantity);
    }

    /**
     * CT-S-041: 在庫×数量の直積ケースで addItem の成否を検証する。
     */
    @ParameterizedTest
    @MethodSource("stockQuantityCartesianProvider")
    @DisplayName("CT-S-041: 在庫×数量の直積ケースで addItem の分岐が期待どおりになる")
    void ctS041_addItem_stockQuantityCartesian(Integer stock, Integer quantity, boolean shouldSucceed, String expectedMessage) {
        when(productRepository.findOnSaleProductById(1)).thenReturn(product(1, "テスト商品", 1000, stock, "/images/products/1.png"));

        if (shouldSucceed) {
            when(cartRepository.findByProductId(1)).thenReturn(null);
            cartService.addItem(1, quantity);
            verify(cartRepository, times(1)).insert(any(CartItemEntity.class));
            return;
        }

        assertThatThrownBy(() -> cartService.addItem(1, quantity))
                .isInstanceOf(IllegalArgumentException.class)
                .hasMessage(expectedMessage);
        verify(cartRepository, never()).insert(any(CartItemEntity.class));
    }

    private static Stream<Arguments> priceQuantityCartesianProvider() {
        return Stream.of(
                Arguments.of(0, 1, 0),
                Arguments.of(0, 99, 0),
                Arguments.of(1000, 1, 1000),
                Arguments.of(1000, 10, 10000),
                Arguments.of(5980, 1, 5980),
                Arguments.of(5980, 99, 592020));
    }

    private static Stream<Arguments> stockQuantityCartesianProvider() {
        return Stream.of(
                Arguments.of(0, 1, false, "error.cart.out.of.stock"),
                Arguments.of(1, 1, true, null),
                Arguments.of(1, 2, false, "error.cart.quantity.over.stock"),
                Arguments.of(5, 1, true, null),
                Arguments.of(5, 5, true, null),
                Arguments.of(5, 6, false, "error.cart.quantity.over.stock"),
                Arguments.of(10, 10, true, null),
                Arguments.of(10, 99, false, "error.cart.quantity.over.stock"));
    }

    /**
     * CartItemEntity を作るテスト用ヘルパー。
     *
     * @param productId 商品ID
     * @param quantity 数量
     * @return カート明細エンティティ
     */
    private CartItemEntity cartItem(Integer productId, Integer quantity) {
        return new CartItemEntity(productId, quantity);
    }

    /**
     * ProductEntity を作るテスト用ヘルパー。
     *
     * @param productId 商品ID
     * @param name 商品名
     * @param price 単価
     * @param stock 在庫
     * @param imageUrl 画像URL
     * @return 商品エンティティ
     */
    private ProductEntity product(Integer productId, String name, Integer price, Integer stock, String imageUrl) {
        ProductEntity entity = new ProductEntity();
        entity.setProductId(productId);
        entity.setName(name);
        entity.setPrice(price);
        entity.setStock(stock);
        entity.setImageUrl(imageUrl);
        entity.setStatus("ON_SALE");
        return entity;
    }
}
