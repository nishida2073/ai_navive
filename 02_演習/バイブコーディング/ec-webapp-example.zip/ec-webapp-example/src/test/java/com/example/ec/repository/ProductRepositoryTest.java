package com.example.ec.repository;

import static org.assertj.core.api.Assertions.*;

import java.util.List;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mybatis.spring.boot.test.autoconfigure.MybatisTest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.jdbc.Sql;

import com.example.ec.repository.entity.ProductEntity;

/**
 * {@link ProductRepository#findOnSaleProducts()} の単体テストクラス。
 *
 * <p>H2 インメモリデータベースを使用してデータアクセスの動作を検証する。
 * {@code @MybatisTest} によりテストごとにトランザクションがロールバックされるため、
 * テストデータが他のテストに影響しない。</p>
 *
 * <p>テスト技法：同値分析、境界値分析、実行網羅（C0）、分岐網羅（C1）</p>
 */
@MybatisTest
// 各テスト実行前に products テーブルのデータを全件削除して初期化する
@Sql(statements = "DELETE FROM products")
class ProductRepositoryTest {

    /** テスト対象の Repository。 */
    @Autowired
    private ProductRepository productRepository;

    /** テストデータ投入用の JDBC テンプレート。 */
    @Autowired
    private JdbcTemplate jdbcTemplate;

    // =========================================================================
    // R-01: 件数確認 - ON_SALEの商品が全件取得できる（同値分析：正常クラス）
    // =========================================================================

    /**
     * R-01: ON_SALEの商品が全件取得できることを検証する。
     *
     * <p>テスト技法：同値分析（正常クラス）、C0（findOnSaleProductsの全文実行）</p>
     */
    @Test
    @DisplayName("R-01: ON_SALEの商品3件とSTOPPEDの商品1件がある場合、ON_SALEの3件のみ返る")
    void r01_findOnSaleProducts_returnsOnlyOnSaleProducts() {
        // ON_SALE: 3件、STOPPED: 1件 を INSERT
        insertProduct(1, "商品A", "説明A", 1000, 10, "ON_SALE", "/img/1.png");
        insertProduct(2, "商品B", "説明B", 2000, 5,  "ON_SALE", "/img/2.png");
        insertProduct(3, "商品C", "説明C", 3000, 0,  "ON_SALE", "/img/3.png");
        insertProduct(4, "商品D", "説明D", 4000, 8,  "STOPPED", "/img/4.png");

        List<ProductEntity> result = productRepository.findOnSaleProducts();

        assertThat(result).hasSize(3);
    }

    // =========================================================================
    // R-02: STOPPEDの商品は取得されない（同値分析：無効クラス、C1：WHERE句false分岐）
    // =========================================================================

    /**
     * R-02: STOPPEDの商品は取得されないことを検証する。
     *
     * <p>テスト技法：同値分析（無効クラス）、C1（WHERE status='ON_SALE' が false となる分岐）</p>
     */
    @Test
    @DisplayName("R-02: STOPPEDの商品のみ存在する場合、空リストが返る")
    void r02_findOnSaleProducts_excludesStoppedProducts() {
        // STOPPED のみ INSERT
        insertProduct(1, "停止商品", "説明", 1000, 5, "STOPPED", "/img/1.png");

        List<ProductEntity> result = productRepository.findOnSaleProducts();

        assertThat(result).isEmpty();
    }

    // =========================================================================
    // R-03: 商品が0件のとき空リストが返る（境界値分析：件数ゼロ）
    // =========================================================================

    /**
     * R-03: テーブルが空の場合に空リスト（null でない）が返ることを検証する。
     *
     * <p>テスト技法：境界値分析（件数ゼロ）</p>
     */
    @Test
    @DisplayName("R-03: productsテーブルが空の場合、nullではなく空リストが返る")
    void r03_findOnSaleProducts_returnsEmptyListWhenNoData() {
        // データなし（@Sql で削除済み）

        List<ProductEntity> result = productRepository.findOnSaleProducts();

        assertThat(result)
                .isNotNull()
                .isEmpty();
    }

    // =========================================================================
    // R-04: 商品が1件のみのとき1件のリストが返る（境界値分析：件数最小値）
    // =========================================================================

    /**
     * R-04: ON_SALEの商品が1件のみの場合に1件のリストが返ることを検証する。
     *
     * <p>テスト技法：境界値分析（件数最小値 = 1）</p>
     */
    @Test
    @DisplayName("R-04: ON_SALEの商品が1件のみの場合、1件のリストが返る")
    void r04_findOnSaleProducts_returnsOneItemList() {
        insertProduct(1, "商品A", "説明A", 1000, 5, "ON_SALE", "/img/1.png");

        List<ProductEntity> result = productRepository.findOnSaleProducts();

        assertThat(result).hasSize(1);
    }

    // =========================================================================
    // R-05: 結果が product_id 昇順で返る（C0：ORDER BY 句の確認）
    // =========================================================================

    /**
     * R-05: 取得結果が product_id の昇順になっていることを検証する。
     *
     * <p>テスト技法：C0（ORDER BY 句が実行されることの確認）</p>
     */
    @Test
    @DisplayName("R-05: INSERT順に関わらず、結果がproduct_id昇順（1,2,3）で返る")
    void r05_findOnSaleProducts_orderedByProductIdAsc() {
        // 意図的に逆順で INSERT
        insertProduct(3, "商品C", "説明C", 3000, 5, "ON_SALE", "/img/3.png");
        insertProduct(1, "商品A", "説明A", 1000, 5, "ON_SALE", "/img/1.png");
        insertProduct(2, "商品B", "説明B", 2000, 5, "ON_SALE", "/img/2.png");

        List<ProductEntity> result = productRepository.findOnSaleProducts();

        assertThat(result)
                .extracting(ProductEntity::getProductId)
                .containsExactly(1, 2, 3);
    }

    // =========================================================================
    // R-06: 在庫数0のON_SALE商品も取得される（境界値分析：stock=0）
    // =========================================================================

    /**
     * R-06: stock=0 の ON_SALE 商品も取得対象であることを検証する。
     *
     * <p>テスト技法：境界値分析（stock=0 は在庫切れだが ON_SALE なら取得対象）</p>
     */
    @Test
    @DisplayName("R-06: stock=0のON_SALE商品も取得対象に含まれる（境界値：在庫ゼロ）")
    void r06_findOnSaleProducts_includesStockZeroProduct() {
        insertProduct(1, "在庫切れ商品", "説明", 1000, 0, "ON_SALE", "/img/1.png");

        List<ProductEntity> result = productRepository.findOnSaleProducts();

        assertThat(result).hasSize(1);
        assertThat(result.get(0).getStock()).isEqualTo(0);
    }

    // =========================================================================
    // R-07: 在庫数1のON_SALE商品が取得される（境界値分析：stock=1）
    // =========================================================================

    /**
     * R-07: stock=1 の ON_SALE 商品が取得されることを検証する。
     *
     * <p>テスト技法：境界値分析（stock=1 は在庫あり最小値）</p>
     */
    @Test
    @DisplayName("R-07: stock=1のON_SALE商品が取得対象に含まれる（境界値：在庫最小値）")
    void r07_findOnSaleProducts_includesStockOneProduct() {
        insertProduct(1, "在庫1件商品", "説明", 1000, 1, "ON_SALE", "/img/1.png");

        List<ProductEntity> result = productRepository.findOnSaleProducts();

        assertThat(result).hasSize(1);
        assertThat(result.get(0).getStock()).isEqualTo(1);
    }

    // =========================================================================
    // R-08: 全フィールドが正しくマッピングされる（C0：ResultType マッピングの確認）
    // =========================================================================

    /**
     * R-08: 取得した商品エンティティの全フィールドが正しくマッピングされることを検証する。
     *
     * <p>テスト技法：C0（map-underscore-to-camel-case を含む全フィールドのマッピング確認）</p>
     */
    @Test
    @DisplayName("R-08: 取得したProductEntityの全フィールドが期待値と一致する")
    void r08_findOnSaleProducts_allFieldsMappedCorrectly() {
        insertProduct(1, "テスト商品", "説明テキスト", 100, 5, "ON_SALE", "/img/1.png");

        List<ProductEntity> result = productRepository.findOnSaleProducts();

        assertThat(result).hasSize(1);
        ProductEntity entity = result.get(0);
        // アンダースコアからキャメルケースへの変換を含む全フィールドを検証
        assertThat(entity.getProductId()).isEqualTo(1);
        assertThat(entity.getName()).isEqualTo("テスト商品");
        assertThat(entity.getDescription()).isEqualTo("説明テキスト");
        assertThat(entity.getPrice()).isEqualTo(100);
        assertThat(entity.getStock()).isEqualTo(5);
        assertThat(entity.getStatus()).isEqualTo("ON_SALE");
        assertThat(entity.getImageUrl()).isEqualTo("/img/1.png");
    }

    // =========================================================================
    // R-09: price=0 の商品も正しくマッピングされる（境界値分析：price 最小値）
    // =========================================================================

    /**
     * R-09: price=0 の商品が正しくマッピングされることを検証する。
     *
     * <p>テスト技法：境界値分析（price 最小値 = 0）</p>
     */
    @Test
    @DisplayName("R-09: price=0のON_SALE商品でも price フィールドが 0 として取得される（境界値：price最小値）")
    void r09_findOnSaleProducts_priceZeroMappedCorrectly() {
        insertProduct(1, "無料商品", "説明", 0, 5, "ON_SALE", "/img/1.png");

        List<ProductEntity> result = productRepository.findOnSaleProducts();

        assertThat(result).hasSize(1);
        assertThat(result.get(0).getPrice()).isEqualTo(0);
    }

    // =========================================================================
    // R-10: ON_SALEとSTOPPEDが混在するときON_SALEのみ取得される（C1：WHERE句の両分岐）
    // =========================================================================

    /**
     * R-10: ON_SALE と STOPPED が混在するとき、ON_SALE のみが取得されることを検証する。
     *
     * <p>テスト技法：C1（WHERE status='ON_SALE' の true / false 両分岐を1テストで確認）</p>
     */
    @Test
    @DisplayName("R-10: ON_SALEとSTOPPEDが混在する場合、ON_SALEの2件のみ返り全要素のstatusがON_SALEである")
    void r10_findOnSaleProducts_mixedStatusReturnsOnlyOnSale() {
        insertProduct(1, "販売中A", "説明A", 1000, 5, "ON_SALE", "/img/1.png");
        insertProduct(2, "販売中B", "説明B", 2000, 5, "ON_SALE", "/img/2.png");
        insertProduct(3, "停止中C", "説明C", 3000, 5, "STOPPED", "/img/3.png");
        insertProduct(4, "停止中D", "説明D", 4000, 5, "STOPPED", "/img/4.png");

        List<ProductEntity> result = productRepository.findOnSaleProducts();

        assertThat(result).hasSize(2);
        // 全要素の status が ON_SALE であることを確認
        assertThat(result)
                .extracting(ProductEntity::getStatus)
                .containsOnly("ON_SALE");
    }

    // =========================================================================
    // R-11〜R-18: findOnSaleProductById の件数・境界値・混在系
    // =========================================================================

    /**
     * R-11: 指定IDの販売中商品を1件取得できることを検証する。
     */
    @Test
    @DisplayName("R-11: findOnSaleProductById はON_SALE商品ID指定で1件返す")
    void r11_findOnSaleProductById_returnsSingleOnSaleProduct() {
        insertProduct(1, "商品A", "説明A", 1000, 5, "ON_SALE", "/img/1.png");

        ProductEntity result = productRepository.findOnSaleProductById(1);

        assertThat(result).isNotNull();
        assertThat(result.getProductId()).isEqualTo(1);
    }

    /**
     * R-12: 存在しない商品ID指定時に null を返すことを検証する。
     */
    @Test
    @DisplayName("R-12: findOnSaleProductById は未存在商品IDでnullを返す")
    void r12_findOnSaleProductById_returnsNullWhenNotFound() {
        insertProduct(1, "商品A", "説明A", 1000, 5, "ON_SALE", "/img/1.png");

        ProductEntity result = productRepository.findOnSaleProductById(9999);

        assertThat(result).isNull();
    }

    /**
     * R-13: 販売停止商品ID指定時に null を返すことを検証する。
     */
    @Test
    @DisplayName("R-13: findOnSaleProductById はSTOPPED商品IDでnullを返す")
    void r13_findOnSaleProductById_returnsNullForStoppedProduct() {
        insertProduct(1, "停止商品", "説明", 1000, 5, "STOPPED", "/img/1.png");

        ProductEntity result = productRepository.findOnSaleProductById(1);

        assertThat(result).isNull();
    }

    /**
     * R-14: ON_SALE/STOPPED混在時にON_SALEのみ取得できることを検証する。
     */
    @Test
    @DisplayName("R-14: findOnSaleProductById は混在時にON_SALE商品のみ返す")
    void r14_findOnSaleProductById_mixedStatusReturnsOnlyOnSale() {
        insertProduct(1, "販売中商品", "説明", 1000, 5, "ON_SALE", "/img/1.png");
        insertProduct(2, "停止商品", "説明", 2000, 5, "STOPPED", "/img/2.png");

        ProductEntity onSale = productRepository.findOnSaleProductById(1);
        ProductEntity stopped = productRepository.findOnSaleProductById(2);

        assertThat(onSale).isNotNull();
        assertThat(onSale.getStatus()).isEqualTo("ON_SALE");
        assertThat(stopped).isNull();
    }

    /**
     * R-15: stock=0 の境界値を検証する。
     */
    @Test
    @DisplayName("R-15: findOnSaleProductById はstock=0のON_SALE商品を取得できる")
    void r15_findOnSaleProductById_includesStockZeroBoundary() {
        insertProduct(3, "在庫切れ商品", "説明", 2980, 0, "ON_SALE", "/img/3.png");

        ProductEntity result = productRepository.findOnSaleProductById(3);

        assertThat(result).isNotNull();
        assertThat(result.getStock()).isZero();
    }

    /**
     * R-16: stock=1 の境界値を検証する。
     */
    @Test
    @DisplayName("R-16: findOnSaleProductById はstock=1のON_SALE商品を取得できる")
    void r16_findOnSaleProductById_includesStockOneBoundary() {
        insertProduct(4, "在庫1商品", "説明", 2980, 1, "ON_SALE", "/img/4.png");

        ProductEntity result = productRepository.findOnSaleProductById(4);

        assertThat(result).isNotNull();
        assertThat(result.getStock()).isEqualTo(1);
    }

    /**
     * R-17: price=0 の境界値を検証する。
     */
    @Test
    @DisplayName("R-17: findOnSaleProductById はprice=0のON_SALE商品を取得できる")
    void r17_findOnSaleProductById_includesPriceZeroBoundary() {
        insertProduct(5, "無料商品", "説明", 0, 5, "ON_SALE", "/img/5.png");

        ProductEntity result = productRepository.findOnSaleProductById(5);

        assertThat(result).isNotNull();
        assertThat(result.getPrice()).isZero();
    }

    /**
     * R-18: findOnSaleProductById の全フィールドマッピングを検証する。
     */
    @Test
    @DisplayName("R-18: findOnSaleProductById の取得結果は全フィールドが正しくマッピングされる")
    void r18_findOnSaleProductById_allFieldsMappedCorrectly() {
        insertProduct(10, "テスト商品", "説明テキスト", 1234, 8, "ON_SALE", "/img/10.png");

        ProductEntity result = productRepository.findOnSaleProductById(10);

        assertThat(result).isNotNull();
        assertThat(result.getProductId()).isEqualTo(10);
        assertThat(result.getName()).isEqualTo("テスト商品");
        assertThat(result.getDescription()).isEqualTo("説明テキスト");
        assertThat(result.getPrice()).isEqualTo(1234);
        assertThat(result.getStock()).isEqualTo(8);
        assertThat(result.getStatus()).isEqualTo("ON_SALE");
        assertThat(result.getImageUrl()).isEqualTo("/img/10.png");
    }

    /**
     * R-19: products の主キー重複時にDB制約違反となることを検証する。
     */
    @Test
    @DisplayName("R-19: products に同一product_idを重複登録するとDB制約違反になる")
    void r19_insertProduct_duplicatePrimaryKey_throwsConstraintViolation() {
        insertProduct(1, "商品A", "説明A", 1000, 5, "ON_SALE", "/img/1.png");

        assertThatThrownBy(() -> insertProduct(1, "商品B", "説明B", 2000, 8, "ON_SALE", "/img/2.png"))
                .isInstanceOf(DataIntegrityViolationException.class);
    }

    // =========================================================================
    // ヘルパーメソッド
    // =========================================================================

    /**
     * products テーブルにテストデータを1件 INSERT するヘルパーメソッド。
     *
     * @param productId 商品ID
     * @param name      商品名
     * @param description 商品説明
     * @param price     価格
     * @param stock     在庫数
     * @param status    販売状態（ON_SALE / STOPPED）
     * @param imageUrl  画像URL
     */
    private void insertProduct(int productId, String name, String description,
            int price, int stock, String status, String imageUrl) {
        jdbcTemplate.update(
                "INSERT INTO products (product_id, name, description, price, stock, status, image_url)"
                + " VALUES (?, ?, ?, ?, ?, ?, ?)",
                productId, name, description, price, stock, status, imageUrl);
    }
}
