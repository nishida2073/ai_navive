package com.example.ec.service;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doAnswer;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoInteractions;
import static org.mockito.Mockito.when;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Stream;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.dao.DataAccessResourceFailureException;
import org.springframework.dao.DataIntegrityViolationException;

import com.example.ec.repository.CartRepository;
import com.example.ec.repository.OrderItemRepository;
import com.example.ec.repository.OrderRepository;
import com.example.ec.repository.ProductRepository;
import com.example.ec.repository.entity.OrderEntity;
import com.example.ec.repository.entity.OrderItemEntity;
import com.example.ec.service.model.CartItemModel;
import com.example.ec.service.model.CartModel;
import com.example.ec.service.model.OrderItemModel;
import com.example.ec.service.model.OrderModel;

/**
 * {@link OrderService} の単体テストクラス。
 *
 * <p>データベースには接続せず、Repository は Mockito でモック化して
 * 注文確認画面向けモデル作成処理と注文確定処理の分岐を検証する。</p>
 */
@ExtendWith(MockitoExtension.class)
class OrderServiceTest {

    /** テスト対象。 */
    @InjectMocks
    private OrderService orderService;

    /** CartService モック。 */
    @Mock
    private CartService cartService;

    /** OrderRepository モック。 */
    @Mock
    private OrderRepository orderRepository;

    /** OrderItemRepository モック。 */
    @Mock
    private OrderItemRepository orderItemRepository;

    /** ProductRepository モック。 */
    @Mock
    private ProductRepository productRepository;

    /** CartRepository モック。 */
    @Mock
    private CartRepository cartRepository;

    /**
     * OC-S-001: カート1件時に注文確認モデルを作成できることを検証する。
     */
    @Test
    @DisplayName("OC-S-001: カート1件で注文確認モデルを作成できる")
    void ocS001_getOrderConfirmation_singleItem() {
        when(cartService.getCart()).thenReturn(cartModel(List.of(cartItem(1, "ワイヤレスイヤホン", 5980, 1, 10)), 1, 5980, false));

        OrderModel result = orderService.getOrderConfirmation();

        assertThat(result.getEmpty()).isFalse();
        assertThat(result.getItems()).hasSize(1);
        OrderItemModel item = result.getItems().get(0);
        assertThat(item.getProductId()).isEqualTo(1);
        assertThat(item.getName()).isEqualTo("ワイヤレスイヤホン");
        assertThat(item.getUnitPrice()).isEqualTo(5980);
        assertThat(item.getQuantity()).isEqualTo(1);
        assertThat(item.getSubtotal()).isEqualTo(5980);
        assertThat(result.getTotalAmount()).isEqualTo(5980);
        assertThat(result.getTotalQuantity()).isEqualTo(1);
    }

    /**
     * OC-S-002: カート複数件時に全明細をモデル化できることを検証する。
     */
    @Test
    @DisplayName("OC-S-002: カート複数件で全OrderItemModelを作成できる")
    void ocS002_getOrderConfirmation_multipleItems() {
        when(cartService.getCart()).thenReturn(cartModel(
                List.of(
                        cartItem(1, "ワイヤレスイヤホン", 5980, 2, 10),
                        cartItem(2, "ゲーミングマウス", 3980, 1, 5)),
                3,
                15940,
                false));

        OrderModel result = orderService.getOrderConfirmation();

        assertThat(result.getItems()).hasSize(2);
        assertThat(result.getItems().get(0).getProductId()).isEqualTo(1);
        assertThat(result.getItems().get(1).getProductId()).isEqualTo(2);
        assertThat(result.getItems().get(0).getSubtotal()).isEqualTo(11960);
        assertThat(result.getItems().get(1).getSubtotal()).isEqualTo(3980);
        assertThat(result.getTotalAmount()).isEqualTo(15940);
        assertThat(result.getTotalQuantity()).isEqualTo(3);
    }

    /**
     * OC-S-003: カート空時の仕様どおりの空モデル返却を検証する。
     */
    @Test
    @DisplayName("OC-S-003: カートが空の場合はempty=trueの空モデルを返す")
    void ocS003_getOrderConfirmation_emptyCart() {
        when(cartService.getCart()).thenReturn(cartModel(List.of(), 0, 0, true));

        OrderModel result = orderService.getOrderConfirmation();

        assertThat(result.getEmpty()).isTrue();
        assertThat(result.getItems()).isEmpty();
        assertThat(result.getTotalAmount()).isZero();
        assertThat(result.getTotalQuantity()).isZero();
    }

    /**
     * OC-S-004: CartService が null を返しても空モデル返却となることを検証する。
     */
    @Test
    @DisplayName("OC-S-004: CartServiceがnullを返す場合でも空モデルを返す")
    void ocS004_getOrderConfirmation_nullCart() {
        when(cartService.getCart()).thenReturn(null);

        OrderModel result = orderService.getOrderConfirmation();

        assertThat(result.getEmpty()).isTrue();
        assertThat(result.getItems()).isEmpty();
        assertThat(result.getTotalAmount()).isZero();
        assertThat(result.getTotalQuantity()).isZero();
    }

    /**
     * OC-S-005: 小計計算（5980 * 1）を保持できることを検証する。
     */
    @Test
    @DisplayName("OC-S-005: 単価5980円・数量1の小計5980円を保持できる")
    void ocS005_getOrderConfirmation_subtotal5980x1() {
        when(cartService.getCart()).thenReturn(cartModel(List.of(cartItem(1, "ワイヤレスイヤホン", 5980, 1, 10)), 1, 5980, false));

        OrderModel result = orderService.getOrderConfirmation();

        assertThat(result.getItems().get(0).getSubtotal()).isEqualTo(5980);
        assertThat(result.getTotalAmount()).isEqualTo(5980);
    }

    /**
     * OC-S-006: 小計計算（5980 * 2）を保持できることを検証する。
     */
    @Test
    @DisplayName("OC-S-006: 単価5980円・数量2の小計11960円を保持できる")
    void ocS006_getOrderConfirmation_subtotal5980x2() {
        when(cartService.getCart()).thenReturn(cartModel(List.of(cartItem(1, "ワイヤレスイヤホン", 5980, 2, 10)), 2, 11960, false));

        OrderModel result = orderService.getOrderConfirmation();

        assertThat(result.getItems().get(0).getSubtotal()).isEqualTo(11960);
        assertThat(result.getTotalAmount()).isEqualTo(11960);
    }

    /**
     * OC-S-007: 数量境界値1で計算結果を保持できることを検証する。
     */
    @Test
    @DisplayName("OC-S-007: 数量境界値1の計算結果を保持できる")
    void ocS007_getOrderConfirmation_boundaryQuantity1() {
        when(cartService.getCart()).thenReturn(cartModel(List.of(cartItem(1, "ワイヤレスイヤホン", 5980, 1, 10)), 1, 5980, false));

        OrderModel result = orderService.getOrderConfirmation();

        assertThat(result.getItems().get(0).getQuantity()).isEqualTo(1);
        assertThat(result.getItems().get(0).getSubtotal()).isEqualTo(5980);
    }

    /**
     * OC-S-008: 数量境界値99で計算結果を保持できることを検証する。
     */
    @Test
    @DisplayName("OC-S-008: 数量境界値99の計算結果を保持できる")
    void ocS008_getOrderConfirmation_boundaryQuantity99() {
        when(cartService.getCart()).thenReturn(cartModel(List.of(cartItem(1, "ワイヤレスイヤホン", 5980, 99, 120)), 99, 592020, false));

        OrderModel result = orderService.getOrderConfirmation();

        assertThat(result.getItems().get(0).getQuantity()).isEqualTo(99);
        assertThat(result.getItems().get(0).getSubtotal()).isEqualTo(592020);
        assertThat(result.getTotalAmount()).isEqualTo(592020);
    }

    /**
     * OC-S-009: 価格0円商品を含む合計計算を保持できることを検証する。
     */
    @Test
    @DisplayName("OC-S-009: 価格0円商品を含む場合でも合計金額を正しく保持できる")
    void ocS009_getOrderConfirmation_zeroPrice() {
        when(cartService.getCart()).thenReturn(cartModel(
                List.of(
                        cartItem(1, "無料サンプル", 0, 2, 99),
                        cartItem(2, "ゲーミングマウス", 3980, 1, 5)),
                3,
                3980,
                false));

        OrderModel result = orderService.getOrderConfirmation();

        assertThat(result.getItems().get(0).getSubtotal()).isZero();
        assertThat(result.getItems().get(1).getSubtotal()).isEqualTo(3980);
        assertThat(result.getTotalAmount()).isEqualTo(3980);
    }

    /**
     * OC-S-010: 正常注文時にヘッダ登録・明細登録が呼び出されることを検証する。
     */
    @Test
    @DisplayName("OC-S-010: 正常注文時に注文ヘッダ登録と注文明細登録が呼び出される")
    void ocS010_placeOrder_successCallsRepositories() {
        CartItemModel cartItem1 = cartItem(1, "ワイヤレスイヤホン", 5980, 1, 10);
        CartItemModel cartItem2 = cartItem(2, "ゲーミングマウス", 3980, 2, 5);
        when(cartService.getCart()).thenReturn(cartModel(List.of(cartItem1, cartItem2), 3, 13940, false));

        doAnswer(invocation -> {
            OrderEntity entity = invocation.getArgument(0);
            entity.setOrderId(1001);
            return 1;
        }).when(orderRepository).insert(any(OrderEntity.class));
        when(productRepository.decreaseStock(1, 1)).thenReturn(1);
        when(productRepository.decreaseStock(2, 2)).thenReturn(1);
        when(orderItemRepository.insert(any(OrderItemEntity.class))).thenReturn(1);

        OrderModel input = orderInput("山田太郎", "1234567", "東京都千代田区1-1", "09012345678");

        Integer orderId = orderService.placeOrder(input);

        assertThat(orderId).isEqualTo(1001);
        verify(orderRepository, times(1)).insert(any(OrderEntity.class));
        verify(orderItemRepository, times(2)).insert(any(OrderItemEntity.class));
        verify(cartRepository, times(1)).deleteAll();
    }

    /**
     * OC-S-011: 注文ヘッダに配送先情報と合計金額・注文日時が設定されることを検証する。
     */
    @Test
    @DisplayName("OC-S-011: 注文ヘッダ登録値（配送先情報・合計金額・注文日時）が正しく設定される")
    void ocS011_placeOrder_headerFieldsMapped() {
        CartItemModel cartItem = cartItem(1, "ワイヤレスイヤホン", 5980, 2, 10);
        when(cartService.getCart()).thenReturn(cartModel(List.of(cartItem), 2, 11960, false));
        doAnswer(invocation -> {
            OrderEntity entity = invocation.getArgument(0);
            entity.setOrderId(2001);
            return 1;
        }).when(orderRepository).insert(any(OrderEntity.class));
        when(productRepository.decreaseStock(1, 2)).thenReturn(1);
        when(orderItemRepository.insert(any(OrderItemEntity.class))).thenReturn(1);

        orderService.placeOrder(orderInput("佐藤花子", "7654321", "大阪府大阪市1-1", "08012345678"));

        ArgumentCaptor<OrderEntity> captor = ArgumentCaptor.forClass(OrderEntity.class);
        verify(orderRepository).insert(captor.capture());
        OrderEntity captured = captor.getValue();
        assertThat(captured.getCustomerName()).isEqualTo("佐藤花子");
        assertThat(captured.getPostalCode()).isEqualTo("7654321");
        assertThat(captured.getAddress()).isEqualTo("大阪府大阪市1-1");
        assertThat(captured.getPhoneNumber()).isEqualTo("08012345678");
        assertThat(captured.getTotalAmount()).isEqualTo(11960);
        assertThat(captured.getOrderedAt()).isNotNull();
    }

    /**
     * OC-S-012: 注文明細に注文時点の商品名・単価・数量・小計が設定されることを検証する。
     */
    @Test
    @DisplayName("OC-S-012: 注文明細登録値（注文ID・商品情報・小計）が正しく設定される")
    void ocS012_placeOrder_detailFieldsMapped() {
        CartItemModel cartItem = cartItem(1, "注文時点イヤホン", 5980, 2, 10);
        when(cartService.getCart()).thenReturn(cartModel(List.of(cartItem), 2, 11960, false));
        doAnswer(invocation -> {
            OrderEntity entity = invocation.getArgument(0);
            entity.setOrderId(3001);
            return 1;
        }).when(orderRepository).insert(any(OrderEntity.class));
        when(productRepository.decreaseStock(1, 2)).thenReturn(1);
        when(orderItemRepository.insert(any(OrderItemEntity.class))).thenReturn(1);

        orderService.placeOrder(orderInput("高橋次郎", "1112222", "北海道札幌市2-2", "09099998888"));

        ArgumentCaptor<OrderItemEntity> captor = ArgumentCaptor.forClass(OrderItemEntity.class);
        verify(orderItemRepository).insert(captor.capture());
        OrderItemEntity detail = captor.getValue();
        assertThat(detail.getOrderId()).isEqualTo(3001);
        assertThat(detail.getProductId()).isEqualTo(1);
        assertThat(detail.getProductName()).isEqualTo("注文時点イヤホン");
        assertThat(detail.getUnitPrice()).isEqualTo(5980);
        assertThat(detail.getQuantity()).isEqualTo(2);
        assertThat(detail.getSubtotal()).isEqualTo(11960);
    }

    /**
     * OC-S-013: カートが空の場合は注文確定で業務例外となることを検証する。
     */
    @Test
    @DisplayName("OC-S-013: カートが空の状態で注文確定すると業務例外になる")
    void ocS013_placeOrder_emptyCartThrows() {
        when(cartService.getCart()).thenReturn(cartModel(List.of(), 0, 0, true));

        assertThatThrownBy(() -> orderService.placeOrder(orderInput("山田太郎", "1234567", "住所", "09012345678")))
                .isInstanceOf(IllegalArgumentException.class)
                .hasMessage("error.order.cart.empty");

        verifyNoInteractions(orderRepository, orderItemRepository, productRepository);
        verify(cartRepository, never()).deleteAll();
    }

    /**
     * OC-S-014: カート内商品の在庫不足時に業務例外となることを検証する。
     */
    @Test
    @DisplayName("OC-S-014: カート内商品の在庫不足時は業務例外になる")
    void ocS014_placeOrder_quantityExceedsStockThrows() {
        CartItemModel cartItem = cartItem(1, "ワイヤレスイヤホン", 5980, 6, 5);
        when(cartService.getCart()).thenReturn(cartModel(List.of(cartItem), 6, 35880, false));
        doAnswer(invocation -> {
            OrderEntity entity = invocation.getArgument(0);
            entity.setOrderId(4001);
            return 1;
        }).when(orderRepository).insert(any(OrderEntity.class));

        assertThatThrownBy(() -> orderService.placeOrder(orderInput("山田太郎", "1234567", "住所", "09012345678")))
                .isInstanceOf(IllegalArgumentException.class)
                .hasMessage("error.order.stock.insufficient");

        verify(productRepository, never()).decreaseStock(any(), any());
        verify(orderItemRepository, never()).insert(any());
    }

    /**
     * OC-S-015: products側に存在しない想定（在庫更新0件）の場合に業務例外となることを検証する。
     */
    @Test
    @DisplayName("OC-S-015: products側に存在しない想定で在庫更新0件の場合は業務例外になる")
    void ocS015_placeOrder_productNotFoundLikeDecreaseStockZero() {
        CartItemModel cartItem = cartItem(9999, "不明商品", 1000, 1, 10);
        when(cartService.getCart()).thenReturn(cartModel(List.of(cartItem), 1, 1000, false));
        doAnswer(invocation -> {
            OrderEntity entity = invocation.getArgument(0);
            entity.setOrderId(5001);
            return 1;
        }).when(orderRepository).insert(any(OrderEntity.class));
        when(productRepository.decreaseStock(9999, 1)).thenReturn(0);

        assertThatThrownBy(() -> orderService.placeOrder(orderInput("山田太郎", "1234567", "住所", "09012345678")))
                .isInstanceOf(IllegalArgumentException.class)
                .hasMessage("error.order.stock.stopped");

        verify(orderItemRepository, never()).insert(any());
        verify(cartRepository, never()).deleteAll();
    }

    /**
     * OC-S-016: 注文ヘッダ登録でRepository例外が発生した場合に伝播することを検証する。
     */
    @Test
    @DisplayName("OC-S-016: 注文ヘッダ登録時のRepository例外はServiceから伝播する")
    void ocS016_placeOrder_orderRepositoryException() {
        CartItemModel cartItem = cartItem(1, "ワイヤレスイヤホン", 5980, 1, 10);
        when(cartService.getCart()).thenReturn(cartModel(List.of(cartItem), 1, 5980, false));
        when(orderRepository.insert(any(OrderEntity.class))).thenThrow(new DataAccessResourceFailureException("order insert error"));

        assertThatThrownBy(() -> orderService.placeOrder(orderInput("山田太郎", "1234567", "住所", "09012345678")))
                .isInstanceOf(DataAccessResourceFailureException.class)
                .hasMessage("order insert error");

        verify(productRepository, never()).decreaseStock(any(), any());
        verify(orderItemRepository, never()).insert(any());
    }

    /**
     * OC-S-017: 注文明細登録でRepository例外が発生した場合に伝播することを検証する。
     */
    @Test
    @DisplayName("OC-S-017: 注文明細登録時のRepository例外はServiceから伝播する")
    void ocS017_placeOrder_orderItemRepositoryException() {
        CartItemModel cartItem = cartItem(1, "ワイヤレスイヤホン", 5980, 1, 10);
        when(cartService.getCart()).thenReturn(cartModel(List.of(cartItem), 1, 5980, false));
        doAnswer(invocation -> {
            OrderEntity entity = invocation.getArgument(0);
            entity.setOrderId(7001);
            return 1;
        }).when(orderRepository).insert(any(OrderEntity.class));
        when(productRepository.decreaseStock(1, 1)).thenReturn(1);
        when(orderItemRepository.insert(any(OrderItemEntity.class))).thenThrow(new DataAccessResourceFailureException("order item insert error"));

        assertThatThrownBy(() -> orderService.placeOrder(orderInput("山田太郎", "1234567", "住所", "09012345678")))
                .isInstanceOf(DataAccessResourceFailureException.class)
                .hasMessage("order item insert error");

        verify(cartRepository, never()).deleteAll();
    }

    /**
     * OC-S-018: 配送先情報の妥当値（境界値）で注文登録に進めることを検証する。
     */
    @ParameterizedTest
    @MethodSource("validOrderInputProvider")
    @DisplayName("OC-S-018: 配送先情報の妥当値（境界値）で正常に注文登録処理へ進む")
    void ocS018_placeOrder_validDeliveryInputs(String customerName, String postalCode, String address, String phoneNumber) {
        CartItemModel cartItem = cartItem(1, "ワイヤレスイヤホン", 5980, 1, 10);
        when(cartService.getCart()).thenReturn(cartModel(List.of(cartItem), 1, 5980, false));
        doAnswer(invocation -> {
            OrderEntity entity = invocation.getArgument(0);
            entity.setOrderId(8001);
            return 1;
        }).when(orderRepository).insert(any(OrderEntity.class));
        when(productRepository.decreaseStock(1, 1)).thenReturn(1);
        when(orderItemRepository.insert(any(OrderItemEntity.class))).thenReturn(1);

        Integer orderId = orderService.placeOrder(orderInput(customerName, postalCode, address, phoneNumber));

        assertThat(orderId).isEqualTo(8001);
    }

    /**
     * OC-S-019: 配送先情報の不正値はRepository例外としてServiceが扱うことを検証する。
     */
    @ParameterizedTest
    @MethodSource("invalidOrderInputProvider")
    @DisplayName("OC-S-019: 配送先情報の不正値はRepository例外としてServiceが伝播する")
    void ocS019_placeOrder_invalidDeliveryInputs(String customerName, String postalCode, String address, String phoneNumber) {
        CartItemModel cartItem = cartItem(1, "ワイヤレスイヤホン", 5980, 1, 10);
        when(cartService.getCart()).thenReturn(cartModel(List.of(cartItem), 1, 5980, false));
        when(orderRepository.insert(any(OrderEntity.class))).thenThrow(new DataIntegrityViolationException("delivery validation error"));

        assertThatThrownBy(() -> orderService.placeOrder(orderInput(customerName, postalCode, address, phoneNumber)))
                .isInstanceOf(DataIntegrityViolationException.class)
                .hasMessage("delivery validation error");

        verify(orderItemRepository, never()).insert(any());
        verify(productRepository, never()).decreaseStock(any(), any());
    }

    /**
     * OC-S-020: 注文時点の値（商品名・単価）が注文明細に設定されることを検証する。
     */
    @Test
    @DisplayName("OC-S-020: 注文時点の商品名・単価が注文明細に設定される")
    void ocS020_placeOrder_snapshotFieldsFromCart() {
        CartItemModel cartItem = cartItem(1, "注文時点商品名", 7777, 2, 10);
        when(cartService.getCart()).thenReturn(cartModel(List.of(cartItem), 2, 15554, false));
        doAnswer(invocation -> {
            OrderEntity entity = invocation.getArgument(0);
            entity.setOrderId(9001);
            return 1;
        }).when(orderRepository).insert(any(OrderEntity.class));
        when(productRepository.decreaseStock(1, 2)).thenReturn(1);
        when(orderItemRepository.insert(any(OrderItemEntity.class))).thenReturn(1);

        orderService.placeOrder(orderInput("山田太郎", "1234567", "住所", "09012345678"));

        ArgumentCaptor<OrderItemEntity> captor = ArgumentCaptor.forClass(OrderItemEntity.class);
        verify(orderItemRepository).insert(captor.capture());
        OrderItemEntity captured = captor.getValue();
        assertThat(captured.getProductName()).isEqualTo("注文時点商品名");
        assertThat(captured.getUnitPrice()).isEqualTo(7777);
        assertThat(captured.getSubtotal()).isEqualTo(15554);
    }

    /**
     * OC-S-021: 注文完了画面向けの注文情報を取得できることを検証する。
     */
    @Test
    @DisplayName("OC-S-021: getCompletedOrder は注文明細を含むOrderModelを返す")
    void ocS021_getCompletedOrder_returnsCompletedOrder() {
        OrderEntity order = new OrderEntity();
        order.setOrderId(1);
        order.setCustomerName("山田太郎");
        order.setPostalCode("1234567");
        order.setAddress("東京都千代田区1-1");
        order.setPhoneNumber("09012345678");
        order.setTotalAmount(9960);

        OrderItemEntity item1 = new OrderItemEntity();
        item1.setOrderId(1);
        item1.setProductId(1);
        item1.setProductName("ワイヤレスイヤホン");
        item1.setUnitPrice(5980);
        item1.setQuantity(1);
        item1.setSubtotal(5980);

        OrderItemEntity item2 = new OrderItemEntity();
        item2.setOrderId(1);
        item2.setProductId(2);
        item2.setProductName("ゲーミングマウス");
        item2.setUnitPrice(3980);
        item2.setQuantity(1);
        item2.setSubtotal(3980);

        when(orderRepository.findByOrderId(1)).thenReturn(order);
        when(orderItemRepository.findByOrderId(1)).thenReturn(List.of(item1, item2));

        OrderModel result = orderService.getCompletedOrder(1);

        assertThat(result).isNotNull();
        assertThat(result.getOrderId()).isEqualTo(1);
        assertThat(result.getItems()).hasSize(2);
        assertThat(result.getTotalQuantity()).isEqualTo(2);
        assertThat(result.getTotalAmount()).isEqualTo(9960);
    }

    /**
     * OC-S-022: 指定注文が存在しない場合は null を返すことを検証する。
     */
    @Test
    @DisplayName("OC-S-022: getCompletedOrder は存在しない注文IDで null を返す")
    void ocS022_getCompletedOrder_returnsNullWhenNotFound() {
        when(orderRepository.findByOrderId(9999)).thenReturn(null);

        OrderModel result = orderService.getCompletedOrder(9999);

        assertThat(result).isNull();
        verify(orderItemRepository, never()).findByOrderId(any());
    }

    /**
     * OC-S-023: 注文ヘッダの各項目が完了画面用モデルへ正しくマッピングされることを検証する。
     */
    @Test
    @DisplayName("OC-S-023: getCompletedOrder は注文ヘッダの顧客情報を正しくマッピングする")
    void ocS023_getCompletedOrder_mapsHeaderFields() {
        LocalDateTime orderedAt = LocalDateTime.of(2026, 6, 1, 10, 30, 0);
        OrderEntity order = new OrderEntity();
        order.setOrderId(10);
        order.setCustomerName("佐藤花子");
        order.setPostalCode("7654321");
        order.setAddress("大阪府大阪市1-1");
        order.setPhoneNumber("08012345678");
        order.setTotalAmount(11960);
        order.setOrderedAt(orderedAt);
        when(orderRepository.findByOrderId(10)).thenReturn(order);
        when(orderItemRepository.findByOrderId(10)).thenReturn(List.of());

        OrderModel result = orderService.getCompletedOrder(10);

        assertThat(result).isNotNull();
        assertThat(result.getCustomerName()).isEqualTo("佐藤花子");
        assertThat(result.getPostalCode()).isEqualTo("7654321");
        assertThat(result.getAddress()).isEqualTo("大阪府大阪市1-1");
        assertThat(result.getPhoneNumber()).isEqualTo("08012345678");
        assertThat(result.getOrderedAt()).isEqualTo(orderedAt);
    }

    /**
     * OC-S-024: 注文明細の各項目が完了画面用モデルへ正しくマッピングされることを検証する。
     */
    @Test
    @DisplayName("OC-S-024: getCompletedOrder は注文明細の各項目を正しくマッピングする")
    void ocS024_getCompletedOrder_mapsItemFields() {
        OrderEntity order = new OrderEntity();
        order.setOrderId(1);
        order.setCustomerName("山田太郎");
        order.setPostalCode("1234567");
        order.setAddress("東京都千代田区1-1");
        order.setPhoneNumber("09012345678");
        order.setTotalAmount(5980);

        OrderItemEntity item = new OrderItemEntity();
        item.setOrderId(1);
        item.setProductId(3);
        item.setProductName("USB-Cハブ");
        item.setUnitPrice(2980);
        item.setQuantity(2);
        item.setSubtotal(5960);

        when(orderRepository.findByOrderId(1)).thenReturn(order);
        when(orderItemRepository.findByOrderId(1)).thenReturn(List.of(item));

        OrderModel result = orderService.getCompletedOrder(1);

        assertThat(result).isNotNull();
        assertThat(result.getItems()).hasSize(1);
        OrderItemModel mapped = result.getItems().get(0);
        assertThat(mapped.getProductId()).isEqualTo(3);
        assertThat(mapped.getName()).isEqualTo("USB-Cハブ");
        assertThat(mapped.getUnitPrice()).isEqualTo(2980);
        assertThat(mapped.getQuantity()).isEqualTo(2);
        assertThat(mapped.getSubtotal()).isEqualTo(5960);
    }

    /**
     * OC-S-025: 注文明細の数量合計が totalQuantity に反映されることを検証する。
     */
    @Test
    @DisplayName("OC-S-025: getCompletedOrder は注文明細の数量合計を totalQuantity に設定する")
    void ocS025_getCompletedOrder_calculatesTotalQuantity() {
        OrderEntity order = new OrderEntity();
        order.setOrderId(1);
        order.setCustomerName("山田太郎");
        order.setPostalCode("1234567");
        order.setAddress("東京都千代田区1-1");
        order.setPhoneNumber("09012345678");
        order.setTotalAmount(13940);

        OrderItemEntity item1 = new OrderItemEntity();
        item1.setOrderId(1);
        item1.setProductId(1);
        item1.setProductName("ワイヤレスイヤホン");
        item1.setUnitPrice(5980);
        item1.setQuantity(2);
        item1.setSubtotal(11960);

        OrderItemEntity item2 = new OrderItemEntity();
        item2.setOrderId(1);
        item2.setProductId(2);
        item2.setProductName("ゲーミングマウス");
        item2.setUnitPrice(1980);
        item2.setQuantity(1);
        item2.setSubtotal(1980);

        when(orderRepository.findByOrderId(1)).thenReturn(order);
        when(orderItemRepository.findByOrderId(1)).thenReturn(List.of(item1, item2));

        OrderModel result = orderService.getCompletedOrder(1);

        assertThat(result).isNotNull();
        assertThat(result.getTotalQuantity()).isEqualTo(3);
        assertThat(result.getEmpty()).isFalse();
    }

    /**
     * OC-S-026: 注文明細が空の場合に empty=true となることを検証する。
     */
    @Test
    @DisplayName("OC-S-026: getCompletedOrder は注文明細が空なら empty=true と totalQuantity=0 を返す")
    void ocS026_getCompletedOrder_returnsEmptyWhenNoItems() {
        OrderEntity order = new OrderEntity();
        order.setOrderId(2);
        order.setCustomerName("山田太郎");
        order.setPostalCode("1234567");
        order.setAddress("東京都千代田区1-1");
        order.setPhoneNumber("09012345678");
        order.setTotalAmount(0);

        when(orderRepository.findByOrderId(2)).thenReturn(order);
        when(orderItemRepository.findByOrderId(2)).thenReturn(List.of());

        OrderModel result = orderService.getCompletedOrder(2);

        assertThat(result).isNotNull();
        assertThat(result.getItems()).isEmpty();
        assertThat(result.getTotalQuantity()).isZero();
        assertThat(result.getEmpty()).isTrue();
    }

    /**
     * OC-S-027: 注文ヘッダ取得時のRepository例外が伝播することを検証する。
     */
    @Test
    @DisplayName("OC-S-027: getCompletedOrder の注文ヘッダ取得で例外が発生した場合、例外が伝播する")
    void ocS027_getCompletedOrder_propagatesOrderRepositoryException() {
        when(orderRepository.findByOrderId(1)).thenThrow(new DataAccessResourceFailureException("order find error"));

        assertThatThrownBy(() -> orderService.getCompletedOrder(1))
                .isInstanceOf(DataAccessResourceFailureException.class)
                .hasMessage("order find error");
    }

    /**
     * OC-S-028: 注文明細取得時のRepository例外が伝播することを検証する。
     */
    @Test
    @DisplayName("OC-S-028: getCompletedOrder の注文明細取得で例外が発生した場合、例外が伝播する")
    void ocS028_getCompletedOrder_propagatesOrderItemRepositoryException() {
        OrderEntity order = new OrderEntity();
        order.setOrderId(1);
        when(orderRepository.findByOrderId(1)).thenReturn(order);
        when(orderItemRepository.findByOrderId(1)).thenThrow(new DataAccessResourceFailureException("order item find error"));

        assertThatThrownBy(() -> orderService.getCompletedOrder(1))
                .isInstanceOf(DataAccessResourceFailureException.class)
                .hasMessage("order item find error");
    }

    /**
     * OC-S-029: 単価×数量の直積ケースで注文確認モデルの小計・合計を検証する。
     */
    @ParameterizedTest
    @MethodSource("priceQuantityCartesianProvider")
    @DisplayName("OC-S-029: 単価×数量の直積ケースで getOrderConfirmation の小計・合計が正しい")
    void ocS029_getOrderConfirmation_priceQuantityCartesian(int price, int quantity, int expectedSubtotal) {
        when(cartService.getCart()).thenReturn(cartModel(List.of(cartItem(1, "テスト商品", price, quantity, 200)), quantity, expectedSubtotal, false));

        OrderModel result = orderService.getOrderConfirmation();

        assertThat(result.getItems()).hasSize(1);
        assertThat(result.getItems().get(0).getSubtotal()).isEqualTo(expectedSubtotal);
        assertThat(result.getTotalAmount()).isEqualTo(expectedSubtotal);
        assertThat(result.getTotalQuantity()).isEqualTo(quantity);
    }

    /**
     * OC-S-030: 在庫×数量×金額の直積ケースで注文確定時の分岐を検証する。
     */
    @ParameterizedTest
    @MethodSource("stockQuantityAmountCartesianProvider")
    @DisplayName("OC-S-030: 在庫×数量×金額の直積ケースで placeOrder の成否が期待どおりになる")
    void ocS030_placeOrder_stockQuantityAmountCartesian(int stock, int quantity, int unitPrice, boolean shouldSucceed,
            String expectedMessage) {
        int subtotal = unitPrice * quantity;
        CartItemModel cartItem = cartItem(1, "テスト商品", unitPrice, quantity, stock);
        when(cartService.getCart()).thenReturn(cartModel(List.of(cartItem), quantity, subtotal, false));

        if (shouldSucceed) {
            doAnswer(invocation -> {
                OrderEntity entity = invocation.getArgument(0);
                entity.setOrderId(9901);
                return 1;
            }).when(orderRepository).insert(any(OrderEntity.class));
            when(productRepository.decreaseStock(1, quantity)).thenReturn(1);
            when(orderItemRepository.insert(any(OrderItemEntity.class))).thenReturn(1);

            Integer orderId = orderService.placeOrder(orderInput("山田太郎", "1234567", "住所", "09012345678"));

            assertThat(orderId).isEqualTo(9901);
            verify(orderItemRepository, times(1)).insert(any(OrderItemEntity.class));
            return;
        }

        doAnswer(invocation -> {
            OrderEntity entity = invocation.getArgument(0);
            entity.setOrderId(9902);
            return 1;
        }).when(orderRepository).insert(any(OrderEntity.class));

        assertThatThrownBy(() -> orderService.placeOrder(orderInput("山田太郎", "1234567", "住所", "09012345678")))
                .isInstanceOf(IllegalArgumentException.class)
                .hasMessage(expectedMessage);
    }

    private static Stream<Arguments> priceQuantityCartesianProvider() {
        return Stream.of(
                Arguments.of(0, 1, 0),
                Arguments.of(0, 99, 0),
                Arguments.of(1000, 1, 1000),
                Arguments.of(1000, 10, 10000),
                Arguments.of(5980, 1, 5980),
                Arguments.of(5980, 99, 592020));
    }

    private static Stream<Arguments> stockQuantityAmountCartesianProvider() {
        return Stream.of(
                Arguments.of(1, 1, 1000, true, null),
                Arguments.of(5, 5, 1000, true, null),
                Arguments.of(10, 10, 5980, true, null),
                Arguments.of(1, 2, 1000, false, "error.order.stock.insufficient"),
                Arguments.of(5, 6, 1000, false, "error.order.stock.insufficient"),
                Arguments.of(0, 1, 1000, false, "error.order.stock.insufficient"));
    }

    /**
     * 正常入力の配送先情報を返す。
     *
     * @return 正常入力パターン
     */
    private static Stream<Arguments> validOrderInputProvider() {
        return Stream.of(
                Arguments.of("山", "1234567", "東", "0312345678"),
                Arguments.of("a".repeat(100), "7654321", "b".repeat(255), "09012345678"),
                Arguments.of("田中一郎", "0000001", "東京都千代田区", "0901234567"));
    }

    /**
     * 異常入力の配送先情報を返す。
     *
     * @return 異常入力パターン
     */
    private static Stream<Arguments> invalidOrderInputProvider() {
        return Stream.of(
                Arguments.of(null, "1234567", "住所", "09012345678"),
                Arguments.of("x".repeat(101), "1234567", "住所", "09012345678"),
                Arguments.of("山田太郎", null, "住所", "09012345678"),
                Arguments.of("山田太郎", "123456", "住所", "09012345678"),
                Arguments.of("山田太郎", "12345678", "住所", "09012345678"),
                Arguments.of("山田太郎", "12A4567", "住所", "09012345678"),
                Arguments.of("山田太郎", "1234567", null, "09012345678"),
                Arguments.of("山田太郎", "1234567", "y".repeat(256), "09012345678"),
                Arguments.of("山田太郎", "1234567", "住所", null),
                Arguments.of("山田太郎", "1234567", "住所", "090123456"),
                Arguments.of("山田太郎", "1234567", "住所", "090123456789"),
                Arguments.of("山田太郎", "1234567", "住所", "09012AB567"));
    }

    /**
     * テスト用の注文入力モデルを生成する。
     *
     * @param customerName 氏名
     * @param postalCode 郵便番号
     * @param address 住所
     * @param phoneNumber 電話番号
     * @return 注文入力モデル
     */
    private static OrderModel orderInput(String customerName, String postalCode, String address, String phoneNumber) {
        OrderModel model = new OrderModel();
        model.setCustomerName(customerName);
        model.setPostalCode(postalCode);
        model.setAddress(address);
        model.setPhoneNumber(phoneNumber);
        return model;
    }

    /**
     * テスト用のカートモデルを生成する。
     *
     * @param items 商品一覧
     * @param totalQuantity 合計数量
     * @param totalAmount 合計金額
     * @param empty 空フラグ
     * @return カートモデル
     */
    private static CartModel cartModel(List<CartItemModel> items, int totalQuantity, int totalAmount, boolean empty) {
        CartModel model = new CartModel();
        model.setItems(items);
        model.setTotalQuantity(totalQuantity);
        model.setTotalAmount(totalAmount);
        model.setEmpty(empty);
        return model;
    }

    /**
     * テスト用のカート明細を生成する。
     *
     * @param productId 商品ID
     * @param name 商品名
     * @param price 単価
     * @param quantity 数量
     * @param stock 在庫
     * @return カート明細
     */
    private static CartItemModel cartItem(int productId, String name, int price, int quantity, int stock) {
        CartItemModel item = new CartItemModel();
        item.setProductId(productId);
        item.setName(name);
        item.setPrice(price);
        item.setQuantity(quantity);
        item.setStock(stock);
        item.setSubtotal(price * quantity);
        return item;
    }
}
