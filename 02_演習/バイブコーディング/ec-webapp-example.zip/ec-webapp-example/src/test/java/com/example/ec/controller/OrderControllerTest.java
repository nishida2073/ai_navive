package com.example.ec.controller;

import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.hamcrest.Matchers.containsString;
import static org.hamcrest.Matchers.hasProperty;
import static org.hamcrest.Matchers.hasSize;
import static org.hamcrest.Matchers.instanceOf;
import static org.hamcrest.Matchers.is;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.flash;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.model;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.redirectedUrl;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.view;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Stream;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.mockito.ArgumentCaptor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.webmvc.test.autoconfigure.WebMvcTest;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.servlet.MockMvc;

import com.example.ec.controller.form.OrderForm;
import com.example.ec.exception.BusinessException;
import com.example.ec.service.OrderService;
import com.example.ec.service.model.OrderItemModel;
import com.example.ec.service.model.OrderModel;

/**
 * {@link OrderController} の単体テストクラス。
 *
 * <p>実サーバーは起動せず、MockMvc で HTTP リクエストをシミュレートして
 * Controller の動作と Thymeleaf 表示内容を検証する。</p>
 */
@WebMvcTest(OrderController.class)
class OrderControllerTest {

    /** HTTPリクエストをシミュレートするテストクライアント。 */
    @Autowired
    private MockMvc mockMvc;

    /** OrderService のモック。 */
    @MockitoBean
    private OrderService orderService;

    /**
     * OC-C-001〜OC-C-007: GET /orders/confirm の基本表示とThymeleaf要素を検証する。
     */
    @Test
    @DisplayName("OC-C-001〜007: GET /orders/confirm で注文確認画面が表示され主要要素が描画される")
    void occ001To007_getOrderConfirm_rendersOrderConfirmPage() throws Exception {
        when(orderService.getOrderConfirmation()).thenReturn(orderModelForConfirm(false));

        mockMvc.perform(get("/orders/confirm"))
                .andExpect(status().isOk())
                .andExpect(view().name("order-confirm"))
                .andExpect(model().attributeExists("order"))
                .andExpect(model().attribute("order", hasProperty("items", hasSize(1))))
                .andExpect(model().attributeExists("orderForm"))
                .andExpect(model().attribute("orderForm", instanceOf(OrderForm.class)));

        verify(orderService, times(1)).getOrderConfirmation();
    }

    /**
     * 注文確認画面で注文内容が表示されることを検証する。
     */
    @Test
    @DisplayName("GET /orders/confirm で注文内容ラベルが表示される")
    void getOrderConfirm_displaysOrderContentLabel() throws Exception {
        when(orderService.getOrderConfirmation()).thenReturn(orderModelForConfirm(false));

        mockMvc.perform(get("/orders/confirm"))
                .andExpect(status().isOk())
                .andExpect(content().string(containsString("注文内容")));
    }

    /**
     * 注文確認画面で合計金額が表示されることを検証する。
     */
    @Test
    @DisplayName("GET /orders/confirm で合計金額ラベルが表示される")
    void getOrderConfirm_displaysTotalAmountLabel() throws Exception {
        when(orderService.getOrderConfirmation()).thenReturn(orderModelForConfirm(false));

        mockMvc.perform(get("/orders/confirm"))
                .andExpect(status().isOk())
                .andExpect(content().string(containsString("合計金額")));
    }

    /**
     * 注文確認画面で注文確定ボタンが表示されることを検証する。
     */
    @Test
    @DisplayName("GET /orders/confirm で注文を確定するボタンが表示される")
    void getOrderConfirm_displaysSubmitButton() throws Exception {
        when(orderService.getOrderConfirmation()).thenReturn(orderModelForConfirm(false));

        mockMvc.perform(get("/orders/confirm"))
                .andExpect(status().isOk())
                .andExpect(content().string(containsString("注文を確定する")));
    }

    /**
     * 注文確認画面で注文者情報セクションが表示されることを検証する。
     */
    @Test
    @DisplayName("GET /orders/confirm で注文者情報セクションが表示される")
    void getOrderConfirm_displaysCustomerSection() throws Exception {
        when(orderService.getOrderConfirmation()).thenReturn(orderModelForConfirm(false));

        mockMvc.perform(get("/orders/confirm"))
                .andExpect(status().isOk())
                .andExpect(content().string(containsString("注文者情報")));
    }

    /**
     * 注文確認画面でカートに戻る導線が表示されることを検証する。
     */
    @Test
    @DisplayName("GET /orders/confirm でカートに戻るリンクが表示される")
    void getOrderConfirm_displaysBackToCartLink() throws Exception {
        when(orderService.getOrderConfirmation()).thenReturn(orderModelForConfirm(false));

        mockMvc.perform(get("/orders/confirm"))
                .andExpect(status().isOk())
                .andExpect(content().string(containsString("href=\"/cart\"")))
                .andExpect(content().string(containsString("カートに戻る")));
    }

    /**
     * 注文確認画面で合計数量が表示されることを検証する。
     */
    @Test
    @DisplayName("GET /orders/confirm で合計数量が表示される")
    void getOrderConfirm_displaysTotalQuantity() throws Exception {
        when(orderService.getOrderConfirmation()).thenReturn(orderModelForConfirm(false));

        mockMvc.perform(get("/orders/confirm"))
                .andExpect(status().isOk())
                .andExpect(content().string(containsString("合計数量")))
                .andExpect(content().string(containsString("1点")));
    }

    /**
     * 商品IDの表示要件を検証する。
     */
    @Test
    @DisplayName("GET /orders/confirm で商品IDのラベルと値が表示される")
    void getOrderConfirm_displaysProductId() throws Exception {
        when(orderService.getOrderConfirmation()).thenReturn(orderModelForConfirm(false));

        mockMvc.perform(get("/orders/confirm"))
                .andExpect(status().isOk())
                .andExpect(content().string(containsString("商品ID")))
                .andExpect(content().string(containsString("1")));
    }

    /**
     * 注文確認画面で商品名が表示されることを検証する。（OC-C-012）
     */
    @Test
    @DisplayName("GET /orders/confirm で商品名が表示される")
    void getOrderConfirm_displaysProductName() throws Exception {
        when(orderService.getOrderConfirmation()).thenReturn(orderModelForConfirm(false));

        mockMvc.perform(get("/orders/confirm"))
                .andExpect(status().isOk())
                .andExpect(content().string(containsString("ワイヤレスイヤホン")));
    }

    /**
     * 注文確認画面で単価が表示されることを検証する。（OC-C-013）
     */
    @Test
    @DisplayName("GET /orders/confirm で単価ラベルと値が表示される")
    void getOrderConfirm_displaysUnitPrice() throws Exception {
        when(orderService.getOrderConfirmation()).thenReturn(orderModelForConfirm(false));

        mockMvc.perform(get("/orders/confirm"))
                .andExpect(status().isOk())
                .andExpect(content().string(containsString("単価")))
                .andExpect(content().string(containsString("¥5,980")));
    }

    /**
     * 注文確認画面で個別商品の数量が表示されることを検証する。（OC-C-014）
     */
    @Test
    @DisplayName("GET /orders/confirm で個別商品の数量が表示される")
    void getOrderConfirm_displaysItemQuantity() throws Exception {
        when(orderService.getOrderConfirmation()).thenReturn(orderModelForConfirm(false));

        mockMvc.perform(get("/orders/confirm"))
                .andExpect(status().isOk())
                .andExpect(content().string(containsString("数量")))
                .andExpect(content().string(containsString("1点")));
    }

    /**
     * 注文確認画面で小計が表示されることを検証する。（OC-C-015）
     */
    @Test
    @DisplayName("GET /orders/confirm で小計ラベルと値が表示される")
    void getOrderConfirm_displaysSubtotal() throws Exception {
        when(orderService.getOrderConfirmation()).thenReturn(orderModelForConfirm(false));

        mockMvc.perform(get("/orders/confirm"))
                .andExpect(status().isOk())
                .andExpect(content().string(containsString("小計")))
                .andExpect(content().string(containsString("¥5,980")));
    }

    /**
     * OC-C-008: カートが空の場合の遷移を検証する。
     */
    @Test
    @DisplayName("OC-C-008: GET /orders/confirm でカートが空の場合は /cart にリダイレクトされる")
    void occ008_getOrderConfirm_redirectsWhenCartEmpty() throws Exception {
        when(orderService.getOrderConfirmation()).thenReturn(orderModelForConfirm(true));

        mockMvc.perform(get("/orders/confirm"))
                .andExpect(status().is3xxRedirection())
                .andExpect(redirectedUrl("/cart"))
                .andExpect(flash().attributeExists("errorMessage"));

        verify(orderService, times(1)).getOrderConfirmation();
    }

    /**
     * GET /orders/confirm でService例外が発生した場合の異常系を検証する。
     */
    @Test
    @DisplayName("GET /orders/confirm でService例外が発生した場合は例外が伝播する")
    void getOrderConfirm_propagatesServiceException() {
        when(orderService.getOrderConfirmation()).thenThrow(new RuntimeException("service failure"));

        assertThatThrownBy(() -> mockMvc.perform(get("/orders/confirm")))
                .hasRootCauseInstanceOf(RuntimeException.class)
                .hasRootCauseMessage("service failure");
    }

    /**
     * OC-C-011: 正常POST時のリダイレクトとService呼び出しを検証する。
     */
    @Test
    @DisplayName("OC-C-011: POST /orders 正常時は /orders/complete/{orderId} へリダイレクトする")
    void occ011_postOrders_successRedirectsToComplete() throws Exception {
        when(orderService.getOrderConfirmation()).thenReturn(orderModelForConfirm(false));
        when(orderService.placeOrder(any(OrderModel.class))).thenReturn(1);

        mockMvc.perform(post("/orders")
                        .param("customerName", "山田太郎")
                        .param("postalCode", "1234567")
                        .param("address", "東京都千代田区1-1")
                        .param("phoneNumber", "09012345678"))
                .andExpect(status().is3xxRedirection())
                .andExpect(redirectedUrl("/orders/complete/1"));

        ArgumentCaptor<OrderModel> captor = ArgumentCaptor.forClass(OrderModel.class);
        verify(orderService, times(1)).placeOrder(captor.capture());
        OrderModel captured = captor.getValue();
        assert captured != null;
        org.assertj.core.api.Assertions.assertThat(captured.getCustomerName()).isEqualTo("山田太郎");
        org.assertj.core.api.Assertions.assertThat(captured.getPostalCode()).isEqualTo("1234567");
        org.assertj.core.api.Assertions.assertThat(captured.getAddress()).isEqualTo("東京都千代田区1-1");
        org.assertj.core.api.Assertions.assertThat(captured.getPhoneNumber()).isEqualTo("09012345678");
    }

    /**
     * 配送先情報の妥当値を検証する。
     */
    @ParameterizedTest
    @MethodSource("validFormProvider")
    @DisplayName("配送先情報の妥当値（境界値）では注文確定処理が呼び出される")
    void validInput_postOrders_callsPlaceOrder(String customerName, String postalCode, String address,
            String phoneNumber) throws Exception {
        when(orderService.getOrderConfirmation()).thenReturn(orderModelForConfirm(false));
        when(orderService.placeOrder(any(OrderModel.class))).thenReturn(10);

        mockMvc.perform(post("/orders")
                        .param("customerName", customerName)
                        .param("postalCode", postalCode)
                        .param("address", address)
                        .param("phoneNumber", phoneNumber))
                .andExpect(status().is3xxRedirection())
                .andExpect(redirectedUrl("/orders/complete/10"));

        verify(orderService, times(1)).placeOrder(any(OrderModel.class));
    }

    /**
     * 配送先情報の不正値を検証する。
     */
    @ParameterizedTest
    @MethodSource("invalidFormProvider")
    @DisplayName("配送先情報の不正値では入力エラーとなり order-confirm が再表示される")
    void invalidInput_postOrders_showsValidationErrors(String customerName, String postalCode, String address,
            String phoneNumber) throws Exception {
        when(orderService.getOrderConfirmation()).thenReturn(orderModelForConfirm(false));

        mockMvc.perform(post("/orders")
                        .param("customerName", customerName)
                        .param("postalCode", postalCode)
                        .param("address", address)
                        .param("phoneNumber", phoneNumber))
                .andExpect(status().isOk())
                .andExpect(view().name("order-confirm"))
                .andExpect(model().attributeHasErrors("orderForm"))
                .andExpect(model().attributeExists("order"))
                .andExpect(content().string(containsString("注文内容")))
                .andExpect(content().string(containsString("合計金額")))
                .andExpect(content().string(containsString("field-error")));

        verify(orderService, never()).placeOrder(any(OrderModel.class));
    }

    /**
     * 郵便番号×電話番号の組合せを体系的に検証する。
     */
    @ParameterizedTest
    @MethodSource("postalPhoneCombinationProvider")
    @DisplayName("郵便番号×電話番号の組合せで入力検証結果が期待どおりになる")
    void combination_postOrders_postalAndPhone(String postalCode, String phoneNumber, boolean valid) throws Exception {
        when(orderService.getOrderConfirmation()).thenReturn(orderModelForConfirm(false));

        if (valid) {
            when(orderService.placeOrder(any(OrderModel.class))).thenReturn(10);

            mockMvc.perform(post("/orders")
                            .param("customerName", "山田太郎")
                            .param("postalCode", postalCode)
                            .param("address", "東京都千代田区1-1")
                            .param("phoneNumber", phoneNumber))
                    .andExpect(status().is3xxRedirection())
                    .andExpect(redirectedUrl("/orders/complete/10"));

            verify(orderService, times(1)).placeOrder(any(OrderModel.class));
            return;
        }

        mockMvc.perform(post("/orders")
                        .param("customerName", "山田太郎")
                        .param("postalCode", postalCode)
                        .param("address", "東京都千代田区1-1")
                        .param("phoneNumber", phoneNumber))
                .andExpect(status().isOk())
                .andExpect(view().name("order-confirm"))
                .andExpect(model().attributeHasErrors("orderForm"));

        verify(orderService, never()).placeOrder(any(OrderModel.class));
    }

    /**
     * 入力エラー時の値保持とメッセージ描画を検証する。
     */
    @Test
    @DisplayName("入力エラー時は入力値が保持され、エラーメッセージが表示される")
    void invalidInput_postOrders_keepsInputValuesAndRendersMessages() throws Exception {
        when(orderService.getOrderConfirmation()).thenReturn(orderModelForConfirm(false));

        mockMvc.perform(post("/orders")
                        .param("customerName", "")
                        .param("postalCode", "12A4567")
                        .param("address", "")
                        .param("phoneNumber", "09012AB567"))
                .andExpect(status().isOk())
                .andExpect(view().name("order-confirm"))
                .andExpect(model().attributeExists("orderForm"))
                .andExpect(model().attribute("orderForm", hasProperty("postalCode", is("12A4567"))))
                .andExpect(model().attribute("orderForm", hasProperty("phoneNumber", is("09012AB567"))))
                .andExpect(content().string(containsString("氏名を入力してください。")))
                .andExpect(content().string(containsString("郵便番号は7桁の数字で入力してください。")))
                .andExpect(content().string(containsString("住所を入力してください。")))
                .andExpect(content().string(containsString("電話番号は10〜11桁の数字で入力してください。")));

        verify(orderService, never()).placeOrder(any(OrderModel.class));
    }

    /**
     * POST /orders でカートが空の場合の遷移を検証する。
     */
    @Test
    @DisplayName("POST /orders でカートが空の場合は /cart にリダイレクトし注文確定しない")
    void postOrders_redirectsWhenCartEmpty() throws Exception {
        when(orderService.getOrderConfirmation()).thenReturn(orderModelForConfirm(true));

        mockMvc.perform(post("/orders")
                        .param("customerName", "山田太郎")
                        .param("postalCode", "1234567")
                        .param("address", "東京都千代田区1-1")
                        .param("phoneNumber", "09012345678"))
                .andExpect(status().is3xxRedirection())
                .andExpect(redirectedUrl("/cart"))
                .andExpect(flash().attributeExists("errorMessage"));

        verify(orderService, never()).placeOrder(any(OrderModel.class));
    }

    /**
     * POST /orders で業務例外が発生した場合の再表示を検証する。
     */
    @Test
    @DisplayName("POST /orders で業務例外発生時は order-confirm を再表示しエラーメッセージを表示する")
    void postOrders_handlesBusinessException() throws Exception {
        when(orderService.getOrderConfirmation()).thenReturn(orderModelForConfirm(false));
        when(orderService.placeOrder(any(OrderModel.class))).thenThrow(new BusinessException("error.order.stock.insufficient", "テスト商品"));

        mockMvc.perform(post("/orders")
                        .param("customerName", "山田太郎")
                        .param("postalCode", "1234567")
                        .param("address", "東京都千代田区1-1")
                        .param("phoneNumber", "09012345678"))
                .andExpect(status().isOk())
                .andExpect(view().name("order-confirm"))
                .andExpect(model().attributeExists("errorMessage"))
                .andExpect(content().string(containsString("在庫が不足しています。")));
    }

    /**
     * POST /orders でシステム例外が発生した場合の異常系を検証する。
     */
    @Test
    @DisplayName("POST /orders でシステム例外発生時は例外が伝播する")
    void postOrders_propagatesSystemException() {
        when(orderService.getOrderConfirmation()).thenReturn(orderModelForConfirm(false));
        when(orderService.placeOrder(any(OrderModel.class))).thenThrow(new RuntimeException("system failure"));

        assertThatThrownBy(() -> mockMvc.perform(post("/orders")
                .param("customerName", "山田太郎")
                .param("postalCode", "1234567")
                .param("address", "東京都千代田区1-1")
                .param("phoneNumber", "09012345678")))
                .hasRootCauseInstanceOf(RuntimeException.class)
                .hasRootCauseMessage("system failure");
    }

    /**
     * 注文完了画面遷移を検証する。
     */
    @Test
    @DisplayName("注文完了画面へ遷移できる（GET /orders/complete/{orderId}）")
    void getOrderComplete_displaysCompletePage() throws Exception {
        when(orderService.getCompletedOrder(1)).thenReturn(completedOrderModel(1));

        mockMvc.perform(get("/orders/complete/1"))
                .andExpect(status().isOk())
                .andExpect(view().name("order-complete"))
                .andExpect(model().attributeExists("completedOrder"));
    }

    /**
     * 注文完了画面で注文情報がない場合の遷移を検証する。
     */
    @Test
    @DisplayName("注文完了情報が存在しない場合は /products にリダイレクトされる")
    void getOrderComplete_redirectsWhenNotFound() throws Exception {
        when(orderService.getCompletedOrder(999)).thenReturn(null);

        mockMvc.perform(get("/orders/complete/999"))
                .andExpect(status().is3xxRedirection())
                .andExpect(redirectedUrl("/products"))
                .andExpect(flash().attributeExists("errorMessage"));
    }

    /**
     * 注文完了画面で注文番号が表示されることを検証する。
     */
    @Test
    @DisplayName("GET /orders/complete/{orderId} で注文番号が表示される")
    void getOrderComplete_displaysOrderId() throws Exception {
        when(orderService.getCompletedOrder(1)).thenReturn(completedOrderModel(1));

        mockMvc.perform(get("/orders/complete/1"))
                .andExpect(status().isOk())
                .andExpect(content().string(containsString("注文番号")))
                .andExpect(content().string(containsString(">1<")));
    }

    /**
     * 注文完了画面で完了メッセージが表示されることを検証する。
     */
    @Test
    @DisplayName("GET /orders/complete/{orderId} で完了メッセージが表示される")
    void getOrderComplete_displaysCompletionMessage() throws Exception {
        when(orderService.getCompletedOrder(1)).thenReturn(completedOrderModel(1));

        mockMvc.perform(get("/orders/complete/1"))
                .andExpect(status().isOk())
                .andExpect(content().string(containsString("ご注文ありがとうございました。")));
    }

    /**
     * 注文完了画面で商品一覧への導線が表示されることを検証する。
     */
    @Test
    @DisplayName("GET /orders/complete/{orderId} で商品一覧へのリンクが表示される")
    void getOrderComplete_displaysProductsLink() throws Exception {
        when(orderService.getCompletedOrder(1)).thenReturn(completedOrderModel(1));

        mockMvc.perform(get("/orders/complete/1"))
                .andExpect(status().isOk())
                .andExpect(content().string(containsString("商品一覧に戻る")));
    }

    /**
     * 注文完了画面で商品一覧リンクのhref属性が/productsであることを検証する。（OCF-C-010）
     */
    @Test
    @DisplayName("GET /orders/complete/{orderId} で商品一覧リンクのhrefが /products である")
    void getOrderComplete_displaysProductsLinkHref() throws Exception {
        when(orderService.getCompletedOrder(1)).thenReturn(completedOrderModel(1));

        mockMvc.perform(get("/orders/complete/1"))
                .andExpect(status().isOk())
                .andExpect(content().string(containsString("href=\"/products\"")));
    }

    /**
     * 注文完了画面で受付ステータスが表示されることを検証する。
     */
    @Test
    @DisplayName("GET /orders/complete/{orderId} で注文受付ステータスが表示される")
    void getOrderComplete_displaysAcceptedStatus() throws Exception {
        when(orderService.getCompletedOrder(1)).thenReturn(completedOrderModel(1));

        mockMvc.perform(get("/orders/complete/1"))
                .andExpect(status().isOk())
                .andExpect(content().string(containsString("注文を受け付けました")));
    }

    /**
     * 注文IDなしのURLが商品一覧へリダイレクトされることを検証する。
     */
    @Test
    @DisplayName("GET /orders/complete では /products にリダイレクトされる")
    void getOrderCompleteWithoutId_redirectsToProducts() throws Exception {
        mockMvc.perform(get("/orders/complete"))
                .andExpect(status().is3xxRedirection())
                .andExpect(redirectedUrl("/products"))
                .andExpect(flash().attributeExists("errorMessage"));
    }

    /**
     * 注文完了URLのPathVariable異常入力を検証する。
     */
    @ParameterizedTest
    @MethodSource("invalidOrderIdPathProvider")
    @DisplayName("GET /orders/complete/{orderId} のPathVariableが非数値の場合はHTTP 400")
    void getOrderComplete_invalidPathVariable_returnsBadRequest(String orderIdPath) throws Exception {
        mockMvc.perform(get("/orders/complete/{orderId}", orderIdPath))
                .andExpect(status().isBadRequest());
    }

    /**
     * 業務例外時に入力値が保持されることを検証する。
     */
    @Test
    @DisplayName("POST /orders の業務例外時は入力値を保持して order-confirm を再表示する")
    void postOrders_businessException_keepsInputValues() throws Exception {
        when(orderService.getOrderConfirmation()).thenReturn(orderModelForConfirm(false));
        when(orderService.placeOrder(any(OrderModel.class))).thenThrow(new BusinessException("error.order.stock.insufficient", "テスト商品"));

        mockMvc.perform(post("/orders")
                        .param("customerName", "山田太郎")
                        .param("postalCode", "1234567")
                        .param("address", "東京都千代田区1-1")
                        .param("phoneNumber", "09012345678"))
                .andExpect(status().isOk())
                .andExpect(view().name("order-confirm"))
                .andExpect(model().attribute("orderForm", hasProperty("customerName", is("山田太郎"))))
                .andExpect(model().attribute("orderForm", hasProperty("postalCode", is("1234567"))))
                .andExpect(model().attribute("orderForm", hasProperty("address", is("東京都千代田区1-1"))))
                .andExpect(model().attribute("orderForm", hasProperty("phoneNumber", is("09012345678"))))
                .andExpect(content().string(containsString("在庫が不足しています。")));
    }

    /**
     * 正常系配送先入力パターンを返す。
     *
     * @return 正常系パラメータ
     */
    private static Stream<Arguments> validFormProvider() {
        return Stream.of(
                Arguments.of("山", "1234567", "東", "0312345678"),
                Arguments.of("a".repeat(100), "7654321", "b".repeat(255), "09012345678"),
                Arguments.of("田中一郎", "0000001", "東京都千代田区", "0901234567"));
    }

    /**
     * 異常系配送先入力パターンを返す。
     *
     * @return 異常系パラメータ
     */
    private static Stream<Arguments> invalidFormProvider() {
        return Stream.of(
                Arguments.of("", "1234567", "住所", "09012345678"),
                Arguments.of("x".repeat(101), "1234567", "住所", "09012345678"),
                Arguments.of("山田太郎", "", "住所", "09012345678"),
                Arguments.of("山田太郎", "123456", "住所", "09012345678"),
                Arguments.of("山田太郎", "12345678", "住所", "09012345678"),
                Arguments.of("山田太郎", "12A4567", "住所", "09012345678"),
                Arguments.of("山田太郎", "1234567", "", "09012345678"),
                Arguments.of("山田太郎", "1234567", "y".repeat(256), "09012345678"),
                Arguments.of("山田太郎", "1234567", "住所", ""),
                Arguments.of("山田太郎", "1234567", "住所", "090123456"),
                Arguments.of("山田太郎", "1234567", "住所", "090123456789"),
                Arguments.of("山田太郎", "1234567", "住所", "09012AB567"));
    }

    private static Stream<Arguments> postalPhoneCombinationProvider() {
        return Stream.of(
                Arguments.of("1234567", "09012345678", true),
                Arguments.of("7654321", "0312345678", true),
                Arguments.of("123456", "09012345678", false),
                Arguments.of("12345678", "09012345678", false),
                Arguments.of("12A4567", "09012345678", false),
                Arguments.of("1234567", "090123456", false),
                Arguments.of("1234567", "090123456789", false),
                Arguments.of("1234567", "09012AB567", false),
                Arguments.of("12A4567", "09012AB567", false));
    }

    private static Stream<String> invalidOrderIdPathProvider() {
        return Stream.of("abc", "1.5", "x-1");
    }

    /**
     * 注文確認画面用のモデルを生成する。
     *
     * @param empty 空フラグ
     * @return 注文モデル
     */
    private static OrderModel orderModelForConfirm(boolean empty) {
        OrderModel order = new OrderModel();
        order.setEmpty(empty);
        if (empty) {
            order.setItems(List.of());
            order.setTotalAmount(0);
            order.setTotalQuantity(0);
            return order;
        }

        OrderItemModel item = new OrderItemModel();
        item.setProductId(1);
        item.setName("ワイヤレスイヤホン");
        item.setImageUrl("/images/products/1.png");
        item.setUnitPrice(5980);
        item.setQuantity(1);
        item.setSubtotal(5980);

        order.setItems(List.of(item));
        order.setTotalQuantity(1);
        order.setTotalAmount(5980);
        return order;
    }

    /**
     * 注文完了画面用のモデルを生成する。
     *
     * @param orderId 注文ID
     * @return 注文完了モデル
     */
    private static OrderModel completedOrderModel(Integer orderId) {
        OrderModel order = new OrderModel();
        order.setOrderId(orderId);
        order.setCustomerName("山田太郎");
        order.setPostalCode("1234567");
        order.setAddress("東京都千代田区1-1");
        order.setPhoneNumber("09012345678");
        order.setOrderedAt(LocalDateTime.now());
        order.setItems(List.of());
        order.setTotalQuantity(1);
        order.setTotalAmount(5980);
        order.setEmpty(false);
        return order;
    }
}
