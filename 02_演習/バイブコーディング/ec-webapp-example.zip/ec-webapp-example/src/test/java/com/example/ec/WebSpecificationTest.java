package com.example.ec;

import java.util.UUID;

import static org.hamcrest.Matchers.containsString;
import static org.hamcrest.Matchers.matchesPattern;
import static org.hamcrest.Matchers.not;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.header;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.webmvc.test.autoconfigure.AutoConfigureMockMvc;
import org.springframework.test.context.DynamicPropertyRegistry;
import org.springframework.test.context.DynamicPropertySource;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.ResultActions;
import org.springframework.transaction.annotation.Transactional;

/**
 * ECサイトの外部仕様を1テスト1検証内容で確認するテスト。
 */
@SpringBootTest
@AutoConfigureMockMvc
@Transactional
class WebSpecificationTest {

    @DynamicPropertySource
    static void overrideDatasourceUrl(DynamicPropertyRegistry registry) {
        registry.add(
                "spring.datasource.url",
                () -> "jdbc:h2:mem:ecdbtest-" + UUID.randomUUID() + ";DB_CLOSE_ON_EXIT=FALSE");
    }

    /** MockMvc。 */
    @Autowired
    private MockMvc mockMvc;

    @Test
    @DisplayName("T01 商品一覧: ステータス200")
    void t01_products_statusOk() throws Exception {
        getProducts().andExpect(status().isOk());
    }

    @Test
    @DisplayName("T02 商品一覧: 詳細を見るを表示")
    void t02_products_showsDetailButtonText() throws Exception {
        getProducts().andExpect(content().string(containsString("詳細を見る")));
    }

    @Test
    @DisplayName("T03 商品一覧: カートに追加を表示")
    void t03_products_showsAddToCartText() throws Exception {
        getProducts().andExpect(content().string(containsString("カートに追加")));
    }

    @Test
    @DisplayName("T04 商品一覧: カートを見るを表示")
    void t04_products_showsViewCartText() throws Exception {
        getProducts().andExpect(content().string(containsString("カートを見る")));
    }

    @Test
    @DisplayName("T05 商品一覧: 詳細を見るの遷移先URLが /products/{productId}")
    void t05_products_detailButtonHasProductDetailPath() throws Exception {
        getProducts().andExpect(content().string(matchesPattern("(?s).*\"/products/[0-9]+\".*")));
    }

    @Test
    @DisplayName("T06 商品一覧: カートに追加フォームの送信先URLが /cart/items")
    void t06_products_addToCartFormHasCartItemsPath() throws Exception {
        getProducts().andExpect(content().string(matchesPattern("(?s).*\"/cart/items\".*")));
    }

    @Test
    @DisplayName("T07 商品一覧: カートを見るの遷移先URLが /cart")
    void t07_products_viewCartHasCartPath() throws Exception {
        getProducts().andExpect(content().string(matchesPattern("(?s).*\"/cart\".*")));
    }

    @Test
    @DisplayName("T08 商品一覧: 初期データ ワイヤレスイヤホンを表示")
    void t08_products_showsWirelessEarphones() throws Exception {
        getProducts().andExpect(content().string(containsString("ワイヤレスイヤホン")));
    }

    @Test
    @DisplayName("T09 商品一覧: 初期データ ゲーミングマウスを表示")
    void t09_products_showsGamingMouse() throws Exception {
        getProducts().andExpect(content().string(containsString("ゲーミングマウス")));
    }

    @Test
    @DisplayName("T10 商品一覧: 初期データ USB-Cハブを表示")
    void t10_products_showsUsbCHub() throws Exception {
        getProducts().andExpect(content().string(containsString("USB-Cハブ")));
    }

    @Test
    @DisplayName("T11 商品一覧: Webカメラを表示しない")
    void t11_products_doesNotShowStoppedProduct() throws Exception {
        getProducts().andExpect(content().string(not(containsString("Webカメラ"))));
    }

    @Test
    @DisplayName("T12 カート追加: 商品一覧から追加時 /products にリダイレクト")
    void t12_addToCartFromProducts_redirectsToProducts() throws Exception {
        addItemFromProducts()
                .andExpect(status().is3xxRedirection())
                .andExpect(header().string("Location", matchesPattern("^/products$")));
    }

    @Test
    @DisplayName("T13 カート追加: 商品詳細から追加時 /products/{productId} にリダイレクト")
    void t13_addToCartFromDetail_redirectsToProductDetail() throws Exception {
        addItemFromProductDetail()
                .andExpect(status().is3xxRedirection())
                .andExpect(header().string("Location", matchesPattern("^/products/[0-9]+$")));
    }

    @Test
    @DisplayName("T14 商品詳細: ステータス200")
    void t14_productDetail_statusOk() throws Exception {
        getProductDetail().andExpect(status().isOk());
    }

    @Test
    @DisplayName("T15 商品詳細: カートに追加を表示")
    void t15_productDetail_showsAddToCartText() throws Exception {
        getProductDetail().andExpect(content().string(containsString("カートに追加")));
    }

    @Test
    @DisplayName("T16 商品詳細: 商品一覧に戻るを表示")
    void t16_productDetail_showsBackToProductsText() throws Exception {
        getProductDetail().andExpect(content().string(containsString("商品一覧に戻る")));
    }

    @Test
    @DisplayName("T17 商品詳細: カートを見るを表示")
    void t17_productDetail_showsViewCartText() throws Exception {
        getProductDetail().andExpect(content().string(containsString("カートを見る")));
    }

    @Test
    @DisplayName("T18 商品詳細: カートに追加フォームの送信先URLが /cart/items")
    void t18_productDetail_addToCartFormHasCartItemsPath() throws Exception {
        getProductDetail().andExpect(content().string(matchesPattern("(?s).*\"/cart/items\".*")));
    }

    @Test
    @DisplayName("T19 商品詳細: 商品一覧に戻るの遷移先URLが /products")
    void t19_productDetail_backToProductsHasProductsPath() throws Exception {
        getProductDetail().andExpect(content().string(matchesPattern("(?s).*\"/products\".*")));
    }

    @Test
    @DisplayName("T20 商品詳細: カートを見るの遷移先URLが /cart")
    void t20_productDetail_viewCartHasCartPath() throws Exception {
        getProductDetail().andExpect(content().string(matchesPattern("(?s).*\"/cart\".*")));
    }

    @Test
    @DisplayName("T21 商品詳細: 初期データ ワイヤレスイヤホンを表示")
    void t21_productDetail_showsWirelessEarphones() throws Exception {
        getProductDetail().andExpect(content().string(containsString("ワイヤレスイヤホン")));
    }

    @Test
    @DisplayName("T22 カート初期表示: ステータス200")
    void t22_cartInitial_statusOk() throws Exception {
        getCartInitial().andExpect(status().isOk());
    }

    @Test
    @DisplayName("T23 カート初期表示: 買い物を続けるを表示")
    void t23_cartInitial_showsContinueShoppingText() throws Exception {
        getCartInitial().andExpect(content().string(containsString("買い物を続ける")));
    }

    @Test
    @DisplayName("T24 カート初期表示: 買い物を続けるの遷移先URLが /products")
    void t24_cartInitial_continueShoppingHasProductsPath() throws Exception {
        getCartInitial().andExpect(content().string(matchesPattern("(?s).*\"/products\".*")));
    }

    @Test
    @DisplayName("T25 カート商品あり表示: ステータス200")
    void t25_cartWithItem_statusOk() throws Exception {
        addCartItem();
        getCartInitial().andExpect(status().isOk());
    }

    @Test
    @DisplayName("T26 カート商品あり表示: ワイヤレスイヤホンを表示")
    void t26_cartWithItem_showsWirelessEarphones() throws Exception {
        addCartItem();
        getCartInitial().andExpect(content().string(containsString("ワイヤレスイヤホン")));
    }

    @Test
    @DisplayName("T27 カート商品あり表示: 数量更新を表示")
    void t27_cartWithItem_showsUpdateQuantityText() throws Exception {
        addCartItem();
        getCartInitial().andExpect(content().string(containsString("数量更新")));
    }

    @Test
    @DisplayName("T28 カート商品あり表示: 削除を表示")
    void t28_cartWithItem_showsDeleteText() throws Exception {
        addCartItem();
        getCartInitial().andExpect(content().string(containsString("削除")));
    }

    @Test
    @DisplayName("T29 カート商品あり表示: 注文手続きへを表示")
    void t29_cartWithItem_showsProceedToOrderText() throws Exception {
        addCartItem();
        getCartInitial().andExpect(content().string(containsString("注文手続きへ")));
    }

    @Test
    @DisplayName("T30 カート商品あり表示: 数量更新フォームの送信先URLが /cart/items/{productId}/update")
    void t30_cartWithItem_updateFormHasUpdatePath() throws Exception {
        addCartItem();
        getCartInitial().andExpect(content().string(matchesPattern("(?s).*\"/cart/items/[0-9]+/update\".*")));
    }

    @Test
    @DisplayName("T31 カート商品あり表示: 削除フォームの送信先URLが /cart/items/{productId}/delete")
    void t31_cartWithItem_deleteFormHasDeletePath() throws Exception {
        addCartItem();
        getCartInitial().andExpect(content().string(matchesPattern("(?s).*\"/cart/items/[0-9]+/delete\".*")));
    }

    @Test
    @DisplayName("T32 カート商品あり表示: 注文手続きへの遷移先URLが /orders/confirm")
    void t32_cartWithItem_proceedToOrderHasConfirmPath() throws Exception {
        addCartItem();
        getCartInitial().andExpect(content().string(matchesPattern("(?s).*\"/orders/confirm\".*")));
    }

    @Test
    @DisplayName("T33 カート数量更新: /cart にリダイレクト")
    void t33_updateQuantity_redirectsToCart() throws Exception {
        addCartItem();
        updateQuantity()
                .andExpect(status().is3xxRedirection())
                .andExpect(header().string("Location", matchesPattern("^/cart$")));
    }

    @Test
    @DisplayName("T34 カート削除: /cart にリダイレクト")
    void t34_deleteItem_redirectsToCart() throws Exception {
        addCartItem();
        deleteItem()
                .andExpect(status().is3xxRedirection())
                .andExpect(header().string("Location", matchesPattern("^/cart$")));
    }

    @Test
    @DisplayName("T35 注文確認: ステータス200")
    void t35_orderConfirm_statusOk() throws Exception {
        addCartItem();
        getOrderConfirm().andExpect(status().isOk());
    }

    @Test
    @DisplayName("T36 注文確認: 注文を確定するを表示")
    void t36_orderConfirm_showsPlaceOrderText() throws Exception {
        addCartItem();
        getOrderConfirm().andExpect(content().string(containsString("注文を確定する")));
    }

    @Test
    @DisplayName("T37 注文確認: カートに戻るを表示")
    void t37_orderConfirm_showsBackToCartText() throws Exception {
        addCartItem();
        getOrderConfirm().andExpect(content().string(containsString("カートに戻る")));
    }

    @Test
    @DisplayName("T38 注文確認: カートに戻るの遷移先URLが /cart")
    void t38_orderConfirm_backToCartHasCartPath() throws Exception {
        addCartItem();
        getOrderConfirm().andExpect(content().string(matchesPattern("(?s).*\"/cart\".*")));
    }

    @Test
    @DisplayName("T39 注文確認: 注文確定フォームの送信先URLが /orders")
    void t39_orderConfirm_formActionIsOrdersPath() throws Exception {
        addCartItem();
        getOrderConfirm().andExpect(content().string(matchesPattern("(?s).*\"/orders\".*")));
    }

    @Test
    @DisplayName("T40 注文確定: /orders/complete/{orderId} 形式にリダイレクト")
    void t40_placeOrder_redirectsToOrderCompletePattern() throws Exception {
        addCartItem();
        placeOrder()
                .andExpect(status().is3xxRedirection())
                .andExpect(header().string("Location", matchesPattern("^/orders/complete/[0-9]+$")));
    }

    @Test
    @DisplayName("T41 注文完了: ステータス200")
    void t41_orderComplete_statusOk() throws Exception {
        addCartItem();
        String redirectedUrl = placeOrderAndGetRedirectedUrl();
        getOrderComplete(redirectedUrl).andExpect(status().isOk());
    }

    @Test
    @DisplayName("T42 注文完了: 商品一覧に戻るを表示")
    void t42_orderComplete_showsBackToProductsText() throws Exception {
        addCartItem();
        String redirectedUrl = placeOrderAndGetRedirectedUrl();
        getOrderComplete(redirectedUrl)
                .andExpect(content().string(containsString("商品一覧に戻る")));
    }

    @Test
    @DisplayName("T43 注文完了: 商品一覧に戻るの遷移先URLが /products")
    void t43_orderComplete_backToProductsHasProductsPath() throws Exception {
        addCartItem();
        String redirectedUrl = placeOrderAndGetRedirectedUrl();
        getOrderComplete(redirectedUrl)
                .andExpect(content().string(matchesPattern("(?s).*\"/products\".*")));
    }

    @Test
    @DisplayName("T44 カート追加（在庫超過・商品一覧）: 3xxリダイレクトにならない")
    void t44_addToCartOverStockFromProducts_notRedirected() throws Exception {
        addItemFromProductsOverStock()
                .andExpect(status().isOk())
                .andExpect(header().doesNotExist("Location"))
                .andExpect(content().string(containsString("詳細を見る")));
    }

    @Test
    @DisplayName("T45 カート追加（在庫超過・商品詳細）: 3xxリダイレクトにならない")
    void t45_addToCartOverStockFromDetail_notRedirected() throws Exception {
        addItemFromProductDetailOverStock()
                .andExpect(status().isOk())
                .andExpect(header().doesNotExist("Location"))
                .andExpect(content().string(containsString("商品一覧に戻る")))
                .andExpect(content().string(containsString("カートを見る")));
    }

    @Test
    @DisplayName("T46 カート数量更新（在庫超過）: 3xxリダイレクトにならない")
    void t46_updateQuantityOverStock_notRedirected() throws Exception {
        addCartItem();
        updateQuantityOverStock()
                .andExpect(status().isOk())
                .andExpect(header().doesNotExist("Location"))
                .andExpect(content().string(containsString("数量更新")));
    }

    @Test
    @DisplayName("T47 注文確定（氏名: 空文字）: 3xxリダイレクトにならない")
    void t47_placeOrderCustomerNameEmpty_notRedirected() throws Exception {
        addCartItem();
        placeOrderWith("", "1234567", "東京都千代田区1-1", "09012345678")
                .andExpect(status().isOk())
                .andExpect(header().doesNotExist("Location"))
                .andExpect(content().string(containsString("注文を確定する")));
    }

    @Test
    @DisplayName("T48 注文確定（氏名: 101文字）: 3xxリダイレクトにならない")
    void t48_placeOrderCustomerNameOverMax_notRedirected() throws Exception {
        addCartItem();
        placeOrderWith(repeat('あ', 101), "1234567", "東京都千代田区1-1", "09012345678")
                .andExpect(status().isOk())
                .andExpect(header().doesNotExist("Location"))
                .andExpect(content().string(containsString("注文を確定する")));
    }

    @Test
    @DisplayName("T49 注文確定（郵便番号: 6桁）: 3xxリダイレクトにならない")
    void t49_placeOrderPostalCode6Digits_notRedirected() throws Exception {
        addCartItem();
        placeOrderWith("山田太郎", "123456", "東京都千代田区1-1", "09012345678")
                .andExpect(status().isOk())
                .andExpect(header().doesNotExist("Location"))
                .andExpect(content().string(containsString("注文を確定する")));
    }

    @Test
    @DisplayName("T50 注文確定（郵便番号: 8桁）: 3xxリダイレクトにならない")
    void t50_placeOrderPostalCode8Digits_notRedirected() throws Exception {
        addCartItem();
        placeOrderWith("山田太郎", "12345678", "東京都千代田区1-1", "09012345678")
                .andExpect(status().isOk())
                .andExpect(header().doesNotExist("Location"))
                .andExpect(content().string(containsString("注文を確定する")));
    }

    @Test
    @DisplayName("T51 注文確定（郵便番号: 7桁）: /orders/complete/{orderId} 形式にリダイレクト")
    void t51_placeOrderPostalCode7Digits_redirectsToOrderComplete() throws Exception {
        addCartItem();
        placeOrderWith("山田太郎", "1234567", "東京都千代田区1-1", "09012345678")
                .andExpect(status().is3xxRedirection())
                .andExpect(header().string("Location", matchesPattern("^/orders/complete/[0-9]+$")));
    }

    @Test
    @DisplayName("T52 注文確定（住所: 空文字）: 3xxリダイレクトにならない")
    void t52_placeOrderAddressEmpty_notRedirected() throws Exception {
        addCartItem();
        placeOrderWith("山田太郎", "1234567", "", "09012345678")
                .andExpect(status().isOk())
                .andExpect(header().doesNotExist("Location"))
                .andExpect(content().string(containsString("注文を確定する")));
    }

    @Test
    @DisplayName("T53 注文確定（住所: 256文字）: 3xxリダイレクトにならない")
    void t53_placeOrderAddressOverMax_notRedirected() throws Exception {
        addCartItem();
        placeOrderWith("山田太郎", "1234567", repeat('あ', 256), "09012345678")
                .andExpect(status().isOk())
                .andExpect(header().doesNotExist("Location"))
                .andExpect(content().string(containsString("注文を確定する")));
    }

    @Test
    @DisplayName("T54 注文確定（電話番号: 9桁）: 3xxリダイレクトにならない")
    void t54_placeOrderPhoneNumber9Digits_notRedirected() throws Exception {
        addCartItem();
        placeOrderWith("山田太郎", "1234567", "東京都千代田区1-1", "090123456")
                .andExpect(status().isOk())
                .andExpect(header().doesNotExist("Location"))
                .andExpect(content().string(containsString("注文を確定する")));
    }

    @Test
    @DisplayName("T55 注文確定（電話番号: 12桁）: 3xxリダイレクトにならない")
    void t55_placeOrderPhoneNumber12Digits_notRedirected() throws Exception {
        addCartItem();
        placeOrderWith("山田太郎", "1234567", "東京都千代田区1-1", "090123456789")
                .andExpect(status().isOk())
                .andExpect(header().doesNotExist("Location"))
                .andExpect(content().string(containsString("注文を確定する")));
    }

    @Test
    @DisplayName("T56 注文確定（電話番号: 10桁）: /orders/complete/{orderId} 形式にリダイレクト")
    void t56_placeOrderPhoneNumber10Digits_redirectsToOrderComplete() throws Exception {
        addCartItem();
        placeOrderWith("山田太郎", "1234567", "東京都千代田区1-1", "0901234567")
                .andExpect(status().is3xxRedirection())
                .andExpect(header().string("Location", matchesPattern("^/orders/complete/[0-9]+$")));
    }

    @Test
    @DisplayName("T57 注文確定（電話番号: 11桁）: /orders/complete/{orderId} 形式にリダイレクト")
    void t57_placeOrderPhoneNumber11Digits_redirectsToOrderComplete() throws Exception {
        addCartItem();
        placeOrderWith("山田太郎", "1234567", "東京都千代田区1-1", "09012345678")
                .andExpect(status().is3xxRedirection())
                .andExpect(header().string("Location", matchesPattern("^/orders/complete/[0-9]+$")));
    }

    @Test
    @DisplayName("T58 注文確定（氏名: 100文字）: /orders/complete/{orderId} 形式にリダイレクト")
    void t58_placeOrderCustomerName100Chars_redirectsToOrderComplete() throws Exception {
        addCartItem();
        placeOrderWith(repeat('あ', 100), "1234567", "東京都千代田区1-1", "09012345678")
                .andExpect(status().is3xxRedirection())
                .andExpect(header().string("Location", matchesPattern("^/orders/complete/[0-9]+$")));
    }

    @Test
    @DisplayName("T59 注文確定（住所: 255文字）: /orders/complete/{orderId} 形式にリダイレクト")
    void t59_placeOrderAddress255Chars_redirectsToOrderComplete() throws Exception {
        addCartItem();
        placeOrderWith("山田太郎", "1234567", repeat('あ', 255), "09012345678")
                .andExpect(status().is3xxRedirection())
                .andExpect(header().string("Location", matchesPattern("^/orders/complete/[0-9]+$")));
    }

    @Test
    @DisplayName("T60 カート追加（在庫0・商品一覧）: 3xxリダイレクトにならない")
    void t60_addToCartZeroStockFromProducts_notRedirected() throws Exception {
        addItemFromProductsZeroStock()
                .andExpect(status().isOk())
                .andExpect(header().doesNotExist("Location"))
                .andExpect(content().string(containsString("詳細を見る")));
    }

    @Test
    @DisplayName("T61 カート追加（在庫0・商品詳細）: 3xxリダイレクトにならない")
    void t61_addToCartZeroStockFromDetail_notRedirected() throws Exception {
        addItemFromProductDetailZeroStock()
                .andExpect(status().isOk())
                .andExpect(header().doesNotExist("Location"))
                .andExpect(content().string(containsString("商品一覧に戻る")))
                .andExpect(content().string(containsString("カートを見る")));
    }

    @Test
    @DisplayName("T62 注文確認画面: カートに追加した商品「ワイヤレスイヤホン」を表示")
    void t62_orderConfirm_showsCartItemName() throws Exception {
        addCartItem();
        getOrderConfirm().andExpect(content().string(containsString("ワイヤレスイヤホン")));
    }

    /** 商品一覧を取得する。 */
    private ResultActions getProducts() throws Exception {
        return mockMvc.perform(get("/products"));
    }

    /** 商品詳細を取得する。 */
    private ResultActions getProductDetail() throws Exception {
        return mockMvc.perform(get("/products/1"));
    }

    /** 初期状態のカート画面を取得する。 */
    private ResultActions getCartInitial() throws Exception {
        return mockMvc.perform(get("/cart"));
    }

    /** 注文確認画面を取得する。 */
    private ResultActions getOrderConfirm() throws Exception {
        return mockMvc.perform(get("/orders/confirm"));
    }

    /** 注文完了画面を取得する。 */
    private ResultActions getOrderComplete(String redirectedUrl) throws Exception {
        return mockMvc.perform(get(redirectedUrl));
    }

    /** 商品一覧からカート追加を実行する。 */
    private ResultActions addItemFromProducts() throws Exception {
        return mockMvc.perform(post("/cart/items")
                .header("Referer", "http://localhost/products")
                .param("productId", "1")
                .param("quantity", "1"));
    }

    /** 商品詳細からカート追加を実行する。 */
    private ResultActions addItemFromProductDetail() throws Exception {
        return mockMvc.perform(post("/cart/items")
                .header("Referer", "http://localhost/products/1")
                .param("productId", "1")
                .param("quantity", "1"));
    }

    /** 商品一覧から在庫超過でカート追加を実行する。 */
    private ResultActions addItemFromProductsOverStock() throws Exception {
        return mockMvc.perform(post("/cart/items")
                .header("Referer", "http://localhost/products")
                .param("productId", "1")
                .param("quantity", "11"));
    }

    /** 商品詳細から在庫超過でカート追加を実行する。 */
    private ResultActions addItemFromProductDetailOverStock() throws Exception {
        return mockMvc.perform(post("/cart/items")
                .header("Referer", "http://localhost/products/1")
                .param("productId", "1")
                .param("quantity", "11"));
    }

    /** 商品一覧から在庫0の商品をカート追加する。 */
    private ResultActions addItemFromProductsZeroStock() throws Exception {
        return mockMvc.perform(post("/cart/items")
                .header("Referer", "http://localhost/products")
                .param("productId", "3")
                .param("quantity", "1"));
    }

    /** 商品詳細から在庫0の商品をカート追加する。 */
    private ResultActions addItemFromProductDetailZeroStock() throws Exception {
        return mockMvc.perform(post("/cart/items")
                .header("Referer", "http://localhost/products/3")
                .param("productId", "3")
                .param("quantity", "1"));
    }

    /** カート数量更新を実行する。 */
    private ResultActions updateQuantity() throws Exception {
        return mockMvc.perform(post("/cart/items/1/update")
                .param("quantity", "2"));
    }

    /** カート数量更新を在庫超過で実行する。 */
    private ResultActions updateQuantityOverStock() throws Exception {
        return mockMvc.perform(post("/cart/items/1/update")
                .param("quantity", "11"));
    }

    /** カート削除を実行する。 */
    private ResultActions deleteItem() throws Exception {
        return mockMvc.perform(post("/cart/items/1/delete"));
    }

    /** 注文確定を実行する。 */
    private ResultActions placeOrder() throws Exception {
        return mockMvc.perform(post("/orders")
                .param("customerName", "山田太郎")
                .param("postalCode", "1234567")
                .param("address", "東京都千代田区1-1")
                .param("phoneNumber", "09012345678"));
    }

    /** 注文確定を任意の配送先情報で実行する。 */
    private ResultActions placeOrderWith(String customerName, String postalCode, String address, String phoneNumber)
            throws Exception {
        return mockMvc.perform(post("/orders")
                .param("customerName", customerName)
                .param("postalCode", postalCode)
                .param("address", address)
                .param("phoneNumber", phoneNumber));
    }

    private String repeat(char ch, int count) {
        return String.valueOf(ch).repeat(Math.max(0, count));
    }

    /** 注文確定して注文完了URLを取得する。 */
    private String placeOrderAndGetRedirectedUrl() throws Exception {
        MvcResult placeOrderResult = placeOrder()
                .andExpect(status().is3xxRedirection())
                .andReturn();
        return placeOrderResult.getResponse().getRedirectedUrl();
    }

    /** 商品を1件カートに追加する。 */
    private void addCartItem() throws Exception {
        mockMvc.perform(post("/cart/items")
                        .header("Referer", "http://localhost/products")
                        .param("productId", "1")
                        .param("quantity", "1"))
                .andExpect(status().is3xxRedirection());
    }
}
