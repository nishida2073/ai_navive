package com.example.ec.repository;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;

import java.time.LocalDateTime;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.jdbc.core.JdbcTemplate;

import com.example.ec.repository.entity.OrderEntity;

/**
 * {@link OrderRepository} のテストクラス。
 */
@SpringBootTest
@DisplayName("OrderRepositoryテスト")
class OrderRepositoryTest {

    /** テストデータ操作用。 */
    @Autowired
    private JdbcTemplate jdbcTemplate;

    /** テスト対象。 */
    @Autowired
    private OrderRepository orderRepository;

    /**
     * テスト前にテーブルを初期化する。
     */
    @BeforeEach
    void setUp() {
        jdbcTemplate.execute("DELETE FROM order_items");
        jdbcTemplate.execute("DELETE FROM orders");
    }

    /**
     * 注文情報を登録し、注文IDで取得できることを検証する。
     */
    @Test
    @DisplayName("insert/findByOrderId: 登録した注文を取得できる")
    void insert_and_findByOrderId() {
        OrderEntity order = new OrderEntity();
        order.setCustomerName("山田太郎");
        order.setPostalCode("1234567");
        order.setAddress("東京都千代田区1-1");
        order.setPhoneNumber("09012345678");
        order.setTotalAmount(5980);
        order.setOrderedAt(LocalDateTime.now());

        int inserted = orderRepository.insert(order);
        OrderEntity result = orderRepository.findByOrderId(order.getOrderId());

        assertEquals(1, inserted);
        assertNotNull(order.getOrderId());
        assertNotNull(result);
        assertEquals("山田太郎", result.getCustomerName());
        assertEquals("1234567", result.getPostalCode());
        assertEquals(5980, result.getTotalAmount());
    }

    /**
     * 存在しない注文ID指定時に null が返ることを検証する。
     */
    @Test
    @DisplayName("findByOrderId: 存在しない注文IDではnullを返す")
    void findByOrderId_returnsNullWhenNotFound() {
        OrderEntity result = orderRepository.findByOrderId(9999);
        assertNull(result);
    }

    /**
     * totalAmount=0 の境界値を検証する。
     */
    @Test
    @DisplayName("insert/findByOrderId: totalAmount=0（下限）を保持できる")
    void insert_and_findByOrderId_totalAmountZeroBoundary() {
        OrderEntity order = new OrderEntity();
        order.setCustomerName("山田太郎");
        order.setPostalCode("1234567");
        order.setAddress("東京都千代田区1-1");
        order.setPhoneNumber("09012345678");
        order.setTotalAmount(0);
        order.setOrderedAt(LocalDateTime.now());

        orderRepository.insert(order);
        OrderEntity result = orderRepository.findByOrderId(order.getOrderId());

        assertNotNull(result);
        assertEquals(0, result.getTotalAmount());
    }

    /**
     * customerName 100文字境界を検証する。
     */
    @Test
    @DisplayName("insert/findByOrderId: customerName=100文字（上限）を保持できる")
    void insert_and_findByOrderId_customerNameMaxBoundary() {
        String name100 = "a".repeat(100);
        OrderEntity order = new OrderEntity();
        order.setCustomerName(name100);
        order.setPostalCode("1234567");
        order.setAddress("東京都千代田区1-1");
        order.setPhoneNumber("09012345678");
        order.setTotalAmount(5980);
        order.setOrderedAt(LocalDateTime.now());

        orderRepository.insert(order);
        OrderEntity result = orderRepository.findByOrderId(order.getOrderId());

        assertNotNull(result);
        assertEquals(name100, result.getCustomerName());
    }

    /**
     * address 255文字境界を検証する。
     */
    @Test
    @DisplayName("insert/findByOrderId: address=255文字（上限）を保持できる")
    void insert_and_findByOrderId_addressMaxBoundary() {
        String address255 = "x".repeat(255);
        OrderEntity order = new OrderEntity();
        order.setCustomerName("山田太郎");
        order.setPostalCode("1234567");
        order.setAddress(address255);
        order.setPhoneNumber("09012345678");
        order.setTotalAmount(5980);
        order.setOrderedAt(LocalDateTime.now());

        orderRepository.insert(order);
        OrderEntity result = orderRepository.findByOrderId(order.getOrderId());

        assertNotNull(result);
        assertEquals(address255, result.getAddress());
    }

    /**
     * orderedAt がDB時刻で格納されることを検証する。
     */
    @Test
    @DisplayName("insert/findByOrderId: orderedAt はnullでなく、現在時刻に近い値が格納される")
    void insert_and_findByOrderId_setsOrderedAtByDatabaseTimestamp() {
        LocalDateTime before = LocalDateTime.now().minusSeconds(2);

        OrderEntity order = new OrderEntity();
        order.setCustomerName("山田太郎");
        order.setPostalCode("1234567");
        order.setAddress("東京都千代田区1-1");
        order.setPhoneNumber("09012345678");
        order.setTotalAmount(5980);
        order.setOrderedAt(LocalDateTime.of(2000, 1, 1, 0, 0, 0));

        orderRepository.insert(order);

        LocalDateTime after = LocalDateTime.now().plusSeconds(2);
        OrderEntity result = orderRepository.findByOrderId(order.getOrderId());

        assertNotNull(result);
        assertNotNull(result.getOrderedAt());
        assertFalse(result.getOrderedAt().isBefore(before));
        assertFalse(result.getOrderedAt().isAfter(after));
    }

    /**
     * 複数注文登録時に指定IDの注文のみ取得できることを検証する。
     */
    @Test
    @DisplayName("findByOrderId: 複数注文登録時に指定orderIdの注文のみ取得できる")
    void findByOrderId_returnsOnlySpecifiedOrderWhenMultipleOrdersExist() {
        OrderEntity order1 = new OrderEntity();
        order1.setCustomerName("山田太郎");
        order1.setPostalCode("1234567");
        order1.setAddress("東京都千代田区1-1");
        order1.setPhoneNumber("09012345678");
        order1.setTotalAmount(5980);
        order1.setOrderedAt(LocalDateTime.now());
        orderRepository.insert(order1);

        OrderEntity order2 = new OrderEntity();
        order2.setCustomerName("佐藤花子");
        order2.setPostalCode("7654321");
        order2.setAddress("大阪府大阪市1-1");
        order2.setPhoneNumber("08012345678");
        order2.setTotalAmount(3980);
        order2.setOrderedAt(LocalDateTime.now());
        orderRepository.insert(order2);

        OrderEntity result1 = orderRepository.findByOrderId(order1.getOrderId());
        OrderEntity result2 = orderRepository.findByOrderId(order2.getOrderId());

        assertNotNull(result1);
        assertNotNull(result2);
        assertEquals("山田太郎", result1.getCustomerName());
        assertEquals("佐藤花子", result2.getCustomerName());
    }

    /**
     * NOT NULL制約（customer_name）を検証する。
     */
    @Test
    @DisplayName("insert: customerName=nullはNOT NULL制約違反になる")
    void insert_throwsWhenCustomerNameIsNull() {
        OrderEntity order = new OrderEntity();
        order.setCustomerName(null);
        order.setPostalCode("1234567");
        order.setAddress("東京都千代田区1-1");
        order.setPhoneNumber("09012345678");
        order.setTotalAmount(1000);
        order.setOrderedAt(LocalDateTime.now());

        assertThrows(DataIntegrityViolationException.class,
                () -> orderRepository.insert(order));
    }

    /**
     * NOT NULL制約（postal_code）を検証する。
     */
    @Test
    @DisplayName("insert: postalCode=nullはNOT NULL制約違反になる")
    void insert_throwsWhenPostalCodeIsNull() {
        OrderEntity order = new OrderEntity();
        order.setCustomerName("山田太郎");
        order.setPostalCode(null);
        order.setAddress("東京都千代田区1-1");
        order.setPhoneNumber("09012345678");
        order.setTotalAmount(1000);
        order.setOrderedAt(LocalDateTime.now());

        assertThrows(DataIntegrityViolationException.class,
                () -> orderRepository.insert(order));
    }

    /**
     * NOT NULL制約（total_amount）を検証する。
     */
    @Test
    @DisplayName("insert: totalAmount=nullはNOT NULL制約違反になる")
    void insert_throwsWhenTotalAmountIsNull() {
        OrderEntity order = new OrderEntity();
        order.setCustomerName("山田太郎");
        order.setPostalCode("1234567");
        order.setAddress("東京都千代田区1-1");
        order.setPhoneNumber("09012345678");
        order.setTotalAmount(null);
        order.setOrderedAt(LocalDateTime.now());

        assertThrows(DataIntegrityViolationException.class,
                () -> orderRepository.insert(order));
    }
}
