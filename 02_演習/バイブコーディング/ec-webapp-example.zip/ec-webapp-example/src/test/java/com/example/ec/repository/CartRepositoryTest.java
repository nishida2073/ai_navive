package com.example.ec.repository;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.jdbc.core.JdbcTemplate;

import com.example.ec.repository.entity.CartItemEntity;

/**
 * {@link CartRepository} のテストクラス。
 */
@SpringBootTest
@DisplayName("CartRepositoryテスト")
class CartRepositoryTest {

    /** テストデータ操作用。 */
    @Autowired
    private JdbcTemplate jdbcTemplate;

    /** テスト対象。 */
    @Autowired
    private CartRepository cartRepository;

    /**
     * テスト前にテーブルを初期化する。
     */
    @BeforeEach
    void setUp() {
        jdbcTemplate.execute("DELETE FROM cart_items");
        jdbcTemplate.execute("DELETE FROM order_items");
        jdbcTemplate.execute("DELETE FROM orders");
        jdbcTemplate.execute("DELETE FROM products");

        jdbcTemplate.update(
                "INSERT INTO products (product_id, name, description, price, stock, status, image_url) VALUES (?, ?, ?, ?, ?, ?, ?)",
                1, "ワイヤレスイヤホン", "ノイズキャンセリング対応", 5980, 10, "ON_SALE", "/images/products/1.png");
    }

    /**
     * カートが空の場合は空リストが返ることを検証する。
     */
    @Test
    @DisplayName("findAll: カートが空の場合は空リストを返す")
    void findAll_returnsEmptyList() {
        List<CartItemEntity> result = cartRepository.findAll();
        assertNotNull(result);
        assertTrue(result.isEmpty());
    }

    /**
     * 追加した商品を商品IDで取得できることを検証する。
     */
    @Test
    @DisplayName("insert/findByProductId: 登録した商品を取得できる")
    void insert_and_findByProductId() {
        CartItemEntity item = new CartItemEntity(1, 3);
        int inserted = cartRepository.insert(item);

        CartItemEntity result = cartRepository.findByProductId(1);

        assertEquals(1, inserted);
        assertNotNull(result);
        assertEquals(1, result.getProductId());
        assertEquals(3, result.getQuantity());
    }

    /**
     * 数量更新と削除が行えることを検証する。
     */
    @Test
    @DisplayName("update/delete: 数量更新後に削除できる")
    void update_and_delete() {
        cartRepository.insert(new CartItemEntity(1, 2));

        int updated = cartRepository.updateQuantity(1, 5);
        CartItemEntity updatedItem = cartRepository.findByProductId(1);
        int deleted = cartRepository.deleteByProductId(1);

        assertEquals(1, updated);
        assertNotNull(updatedItem);
        assertEquals(5, updatedItem.getQuantity());
        assertEquals(1, deleted);
        assertTrue(cartRepository.findAll().isEmpty());
    }

    /**
     * カート1件登録時に1件取得されることを検証する。
     */
    @Test
    @DisplayName("findAll: カート1件登録時は1件取得される")
    void findAll_returnsSingleItem() {
        cartRepository.insert(new CartItemEntity(1, 1));

        List<CartItemEntity> result = cartRepository.findAll();

        assertNotNull(result);
        assertEquals(1, result.size());
        assertEquals(1, result.get(0).getProductId());
        assertEquals(1, result.get(0).getQuantity());
    }

    /**
     * カート複数件登録時に複数取得されることを検証する。
     */
    @Test
    @DisplayName("findAll: カート複数件登録時は複数件取得される")
    void findAll_returnsMultipleItems() {
        jdbcTemplate.update(
                "INSERT INTO products (product_id, name, description, price, stock, status, image_url) VALUES (?, ?, ?, ?, ?, ?, ?)",
                2, "ゲーミングマウス", "6ボタン搭載", 3980, 5, "ON_SALE", "/images/products/2.png");
        jdbcTemplate.update(
                "INSERT INTO products (product_id, name, description, price, stock, status, image_url) VALUES (?, ?, ?, ?, ?, ?, ?)",
                3, "USB-Cハブ", "5in1モデル", 2980, 0, "ON_SALE", "/images/products/3.png");

        cartRepository.insert(new CartItemEntity(1, 2));
        cartRepository.insert(new CartItemEntity(2, 1));
        cartRepository.insert(new CartItemEntity(3, 99));

        List<CartItemEntity> result = cartRepository.findAll();

        assertNotNull(result);
        assertEquals(3, result.size());
    }

    /**
     * findByProductId の未存在系を検証する。
     */
    @Test
    @DisplayName("findByProductId: 未存在商品IDではnullを返す")
    void findByProductId_returnsNullWhenNotFound() {
        CartItemEntity result = cartRepository.findByProductId(9999);
        assertNull(result);
    }

    /**
     * 数量境界値1の登録・取得を検証する。
     */
    @Test
    @DisplayName("insert/findByProductId: quantity=1（下限）を保持できる")
    void insert_and_findByProductId_quantityMinBoundary() {
        cartRepository.insert(new CartItemEntity(1, 1));

        CartItemEntity result = cartRepository.findByProductId(1);

        assertNotNull(result);
        assertEquals(1, result.getQuantity());
    }

    /**
     * 数量境界値99の登録・取得を検証する。
     */
    @Test
    @DisplayName("insert/findByProductId: quantity=99（上限）を保持できる")
    void insert_and_findByProductId_quantityMaxBoundary() {
        cartRepository.insert(new CartItemEntity(1, 99));

        CartItemEntity result = cartRepository.findByProductId(1);

        assertNotNull(result);
        assertEquals(99, result.getQuantity());
    }

    /**
     * 未存在商品更新時の更新件数を検証する。
     */
    @Test
    @DisplayName("updateQuantity: 未存在商品ID更新時は0件更新")
    void updateQuantity_returnsZeroWhenNotFound() {
        int updated = cartRepository.updateQuantity(9999, 5);
        assertEquals(0, updated);
    }

    /**
     * 未存在商品削除時の削除件数を検証する。
     */
    @Test
    @DisplayName("deleteByProductId: 未存在商品ID削除時は0件削除")
    void deleteByProductId_returnsZeroWhenNotFound() {
        int deleted = cartRepository.deleteByProductId(9999);
        assertEquals(0, deleted);
    }

    /**
     * deleteAll の0件削除を検証する。
     */
    @Test
    @DisplayName("deleteAll: カート空の場合は0件削除")
    void deleteAll_returnsZeroWhenEmpty() {
        int deleted = cartRepository.deleteAll();
        assertEquals(0, deleted);
    }

    /**
     * deleteAll の複数件削除を検証する。
     */
    @Test
    @DisplayName("deleteAll: カート複数件の場合は全件削除される")
    void deleteAll_deletesAllRowsWhenMultipleItemsExist() {
        jdbcTemplate.update(
                "INSERT INTO products (product_id, name, description, price, stock, status, image_url) VALUES (?, ?, ?, ?, ?, ?, ?)",
                2, "ゲーミングマウス", "6ボタン搭載", 3980, 5, "ON_SALE", "/images/products/2.png");

        cartRepository.insert(new CartItemEntity(1, 2));
        cartRepository.insert(new CartItemEntity(2, 3));

        int deleted = cartRepository.deleteAll();
        List<CartItemEntity> result = cartRepository.findAll();

        assertEquals(2, deleted);
        assertNotNull(result);
        assertTrue(result.isEmpty());
    }

    /**
     * PK重複制約を検証する。
     */
    @Test
    @DisplayName("insert: 同一productIdを重複登録するとDB制約違反になる")
    void insert_throwsWhenDuplicateProductId() {
        cartRepository.insert(new CartItemEntity(1, 1));

        assertThrows(DataIntegrityViolationException.class,
                () -> cartRepository.insert(new CartItemEntity(1, 2)));
    }

    /**
     * FK制約を検証する。
     */
    @Test
    @DisplayName("insert: productsに存在しないproductIdを登録するとFK制約違反になる")
    void insert_throwsWhenProductDoesNotExist() {
        assertThrows(DataIntegrityViolationException.class,
                () -> cartRepository.insert(new CartItemEntity(9999, 1)));
    }

    /**
     * CHECK制約（quantity下限）を検証する。
     */
    @Test
    @DisplayName("insert: quantity=0はCHECK制約違反になる")
    void insert_throwsWhenQuantityIsZero() {
        assertThrows(DataIntegrityViolationException.class,
                () -> cartRepository.insert(new CartItemEntity(1, 0)));
    }

    /**
     * CHECK制約（quantity上限超過）を検証する。
     */
    @Test
    @DisplayName("insert: quantity=100はCHECK制約違反になる")
    void insert_throwsWhenQuantityExceedsMax() {
        assertThrows(DataIntegrityViolationException.class,
                () -> cartRepository.insert(new CartItemEntity(1, 100)));
    }
}
