﻿# テスト結果レポート - ProductRepositoryTest

## 基本情報

| 項目 | 内容 |
|---|---|
| テスト実施日 | 2026年6月1日 |
| テスト種別 | JUnit単体テスト |
| 対象テストクラス | com.example.ec.repository.ProductRepositoryTest |
| 対象ファイル | src/test/java/com/example/ec/repository/ProductRepositoryTest.java |

## 実行結果

| 項目 | 結果 |
|---|---|
| 実行件数 | 19 |
| 成功 | 19 |
| 失敗 | 0 |

## 判定

PASS（全件成功）

## テストケース別結果

| No. | テストケース | テストメソッド名 | 結果 |
|---|---|---|---|
| 1 | R-13: findOnSaleProductById はSTOPPED商品IDでnullを返す | r13_findOnSaleProductById_returnsNullForStoppedProduct | PASS |
| 2 | R-08: 取得したProductEntityの全フィールドが期待値と一致する | r08_findOnSaleProducts_allFieldsMappedCorrectly | PASS |
| 3 | R-09: price=0のON_SALE商品でも price フィールドが 0 として取得される（境界値：price最小値） | r09_findOnSaleProducts_priceZeroMappedCorrectly | PASS |
| 4 | R-16: findOnSaleProductById はstock=1のON_SALE商品を取得できる | r16_findOnSaleProductById_includesStockOneBoundary | PASS |
| 5 | R-04: ON_SALEの商品が1件のみの場合、1件のリストが返る | r04_findOnSaleProducts_returnsOneItemList | PASS |
| 6 | R-06: stock=0のON_SALE商品も取得対象に含まれる（境界値：在庫ゼロ） | r06_findOnSaleProducts_includesStockZeroProduct | PASS |
| 7 | R-10: ON_SALEとSTOPPEDが混在する場合、ON_SALEの2件のみ返り全要素のstatusがON_SALEである | r10_findOnSaleProducts_mixedStatusReturnsOnlyOnSale | PASS |
| 8 | R-11: findOnSaleProductById はON_SALE商品ID指定で1件返す | r11_findOnSaleProductById_returnsSingleOnSaleProduct | PASS |
| 9 | R-03: productsテーブルが空の場合、nullではなく空リストが返る | r03_findOnSaleProducts_returnsEmptyListWhenNoData | PASS |
| 10 | R-01: ON_SALEの商品3件とSTOPPEDの商品1件がある場合、ON_SALEの3件のみ返る | r01_findOnSaleProducts_returnsOnlyOnSaleProducts | PASS |
| 11 | R-18: findOnSaleProductById の取得結果は全フィールドが正しくマッピングされる | r18_findOnSaleProductById_allFieldsMappedCorrectly | PASS |
| 12 | R-14: findOnSaleProductById は混在時にON_SALE商品のみ返す | r14_findOnSaleProductById_mixedStatusReturnsOnlyOnSale | PASS |
| 13 | R-17: findOnSaleProductById はprice=0のON_SALE商品を取得できる | r17_findOnSaleProductById_includesPriceZeroBoundary | PASS |
| 14 | R-05: INSERT順に関わらず、結果がproduct_id昇順（1,2,3）で返る | r05_findOnSaleProducts_orderedByProductIdAsc | PASS |
| 15 | R-07: stock=1のON_SALE商品が取得対象に含まれる（境界値：在庫最小値） | r07_findOnSaleProducts_includesStockOneProduct | PASS |
| 16 | R-12: findOnSaleProductById は未存在商品IDでnullを返す | r12_findOnSaleProductById_returnsNullWhenNotFound | PASS |
| 17 | R-15: findOnSaleProductById はstock=0のON_SALE商品を取得できる | r15_findOnSaleProductById_includesStockZeroBoundary | PASS |
| 18 | R-19: products に同一product_idを重複登録するとDB制約違反になる | r19_insertProduct_duplicatePrimaryKey_throwsConstraintViolation | PASS |
| 19 | R-02: STOPPEDの商品のみ存在する場合、空リストが返る | r02_findOnSaleProducts_excludesStoppedProducts | PASS |
