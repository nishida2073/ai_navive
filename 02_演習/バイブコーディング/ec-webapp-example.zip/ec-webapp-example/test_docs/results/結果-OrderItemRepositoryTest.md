﻿# テスト結果レポート - OrderItemRepositoryTest

## 基本情報

| 項目 | 内容 |
|---|---|
| テスト実施日 | 2026年6月1日 |
| テスト種別 | JUnit単体テスト |
| 対象テストクラス | com.example.ec.repository.OrderItemRepositoryTest |
| 対象ファイル | src/test/java/com/example/ec/repository/OrderItemRepositoryTest.java |

## 実行結果

| 項目 | 結果 |
|---|---|
| 実行件数 | 11 |
| 成功 | 11 |
| 失敗 | 0 |

## 判定

PASS（全件成功）

## テストケース別結果

| No. | テストケース | テストメソッド名 | 結果 |
|---|---|---|---|
| 1 | insert/findByOrderId: quantity=99（上限想定）を保持できる | insert_and_findByOrderId_quantityMaxBoundary | PASS |
| 2 | findByOrderId: 同一注文の複数明細を取得できる | findByOrderId_returnsMultipleItemsForSameOrder | PASS |
| 3 | insert: 存在しないproductIdで注文明細登録するとFK制約違反になる | insert_throwsWhenProductIdDoesNotExist | PASS |
| 4 | findByOrderId: 注文明細がない注文IDでは空リストを返す | findByOrderId_returnsEmptyListWhenNoItems | PASS |
| 5 | findByOrderId: order_item_id 昇順で取得される | findByOrderId_returnsItemsOrderedByOrderItemIdAsc | PASS |
| 6 | insert/findByOrderId: unitPrice=0（下限）とsubtotal=0を保持できる | insert_and_findByOrderId_unitPriceZeroBoundary | PASS |
| 7 | insert: productName=nullで注文明細登録するとNOT NULL制約違反になる | insert_throwsWhenProductNameIsNull | PASS |
| 8 | insert: 存在しないorderIdで注文明細登録するとFK制約違反になる | insert_throwsWhenOrderIdDoesNotExist | PASS |
| 9 | findByOrderId: 異なる注文の明細が混在していても指定注文IDのみ返る | findByOrderId_filtersItemsByOrderId | PASS |
| 10 | insert/findByOrderId: 登録した注文明細を取得できる | insert_and_findByOrderId | PASS |
| 11 | insert/findByOrderId: quantity=1（下限）の注文明細を保持できる | insert_and_findByOrderId_quantityMinBoundary | PASS |
