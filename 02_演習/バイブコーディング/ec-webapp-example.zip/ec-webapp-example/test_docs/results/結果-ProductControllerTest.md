﻿# テスト結果レポート - ProductControllerTest

## 基本情報

| 項目 | 内容 |
|---|---|
| テスト実施日 | 2026年6月1日 |
| テスト種別 | JUnit単体テスト |
| 対象テストクラス | com.example.ec.controller.ProductControllerTest |
| 対象ファイル | src/test/java/com/example/ec/controller/ProductControllerTest.java |

## 実行結果

| 項目 | 結果 |
|---|---|
| 実行件数 | 55 |
| 成功 | 55 |
| 失敗 | 0 |

## 判定

PASS（全件成功）

## テストケース別結果

| No. | テストケース | テストメソッド名 | 結果 |
|---|---|---|---|
| 1 | C-08-8: 商品詳細画面でstock=0の場合「在庫なし」が表示される | c08_8_showProductDetail_displaysOutOfStockWhenZero | PASS |
| 2 | C-10: POST /cart/items の成功時はReferer先にリダイレクトされる | c10_addItem_redirectsBackToRefererOnSuccess | PASS |
| 3 | C-01: 販売中商品が複数件ある場合、HTTP 200でproducts画面が表示されThymeleafで商品情報が描画される | c01_showProducts_rendersProductListAndThymeleafContents | PASS |
| 4 | C-01-3: 商品一覧で販売ステータスが表示される | c01_3_showProducts_displaysStatus | PASS |
| 5 | C-01-5: 商品一覧で在庫なし表示が描画される | c01_5_showProducts_displaysOutOfStockStatus | PASS |
| 6 | C-14: 一覧画面からのカート追加で業務例外時は products を再表示する | c14_addItem_rendersProductsViewWhenBusinessErrorOccursFromList | PASS |
| 7 | C-01-6: 商品一覧で詳細画面へのリンクが表示される | c01_6_showProducts_displaysDetailLink | PASS |
| 8 | C-11: RefererなしのPOST /cart/items 成功時は /products にリダイレクトされる | c11_addItem_redirectsToProductsWhenRefererMissing | PASS |
| 9 | C-04: GET /products 実行時に productService.getOnSaleProducts() が1回だけ呼ばれる | c04_showProducts_callsServiceExactlyOnce | PASS |
| 10 | C-08-9: 商品詳細画面で商品画像のsrc属性が表示される | c08_9_showProductDetail_displaysProductImage | PASS |
| 11 | C-02: 販売中商品が1件のみの場合、Modelに1件のリストが設定される | c02_showProducts_setsSingleItemListToModel | PASS |
| 12 | C-07: Serviceが例外をスローした場合、例外が伝播する | c07_showProducts_propagatesExceptionWhenServiceThrows | PASS |
| 13 | C-12: 不正なRefererのPOST /cart/items 成功時は /products にリダイレクトされる | c12_addItem_redirectsToProductsWhenRefererIsUnsupported | PASS |
| 14 | C-09: 存在しない商品ID指定時は /products にリダイレクトする | c09_showProductDetail_redirectsWhenProductNotFound | PASS |
| 15 | C-08-1: 商品詳細画面で商品説明が表示される | c08_1_showProductDetail_displaysDescription | PASS |
| 16 | C-13: 商品詳細画面から数量不正でPOSTした場合は products-detail を再表示する | c13_addItem_rendersDetailViewWhenValidationFailsFromDetail | PASS |
| 17 | C-08-2: 商品詳細画面で商品IDが表示される | c08_2_showProductDetail_displaysProductId | PASS |
| 18 | C-08-4: 商品詳細画面で在庫状況と販売ステータスが表示される | c08_4_showProductDetail_displaysStockStatusAndSaleStatus | PASS |
| 19 | C-08-7: 商品詳細画面で在庫数の数値が表示される | c08_7_showProductDetail_displaysStockCount | PASS |
| 20 | C-15: 商品詳細画面から数量異常入力時は products-detail を再表示してエラー表示する [1] | c15_addItem_invalidQuantityFromDetail_rendersDetail(String)[1] | PASS |
| 21 | C-15: 商品詳細画面から数量異常入力時は products-detail を再表示してエラー表示する [2] | c15_addItem_invalidQuantityFromDetail_rendersDetail(String)[2] | PASS |
| 22 | C-15: 商品詳細画面から数量異常入力時は products-detail を再表示してエラー表示する [3] | c15_addItem_invalidQuantityFromDetail_rendersDetail(String)[3] | PASS |
| 23 | C-15: 商品詳細画面から数量異常入力時は products-detail を再表示してエラー表示する [4] | c15_addItem_invalidQuantityFromDetail_rendersDetail(String)[4] | PASS |
| 24 | C-15: 商品詳細画面から数量異常入力時は products-detail を再表示してエラー表示する [5] | c15_addItem_invalidQuantityFromDetail_rendersDetail(String)[5] | PASS |
| 25 | C-15: 商品詳細画面から数量異常入力時は products-detail を再表示してエラー表示する [6] | c15_addItem_invalidQuantityFromDetail_rendersDetail(String)[6] | PASS |
| 26 | C-08-5: 商品詳細画面でカート画面へのリンクが表示される | c08_5_showProductDetail_displaysCartLink | PASS |
| 27 | C-01-4: 在庫切れ商品ではカート追加ボタンが無効になる | c01_4_showProducts_disablesCartButtonWhenOutOfStock | PASS |
| 28 | C-08-6: 商品詳細画面で商品一覧に戻るリンクが表示される | c08_6_showProductDetail_displaysBackToProductsLink | PASS |
| 29 | C-08: 有効な商品IDで商品詳細画面を表示できる | c08_showProductDetail_rendersProductsDetailView | PASS |
| 30 | C-08-3: 商品詳細画面で価格が表示される | c08_3_showProductDetail_displaysPrice | PASS |
| 31 | C-01-2: 商品一覧で在庫数が表示される | c01_2_showProducts_displaysStockCount | PASS |
| 32 | C-06: productListItemForm がModelに ProductListItemForm として設定される | c06_showProducts_setsProductListItemFormToModel | PASS |
| 33 | C-17: Referer の組合せに応じてPOST /cart/items 成功時の遷移先が決まる [1] | c17_addItem_redirectsByRefererCombination(String, String)[1] | PASS |
| 34 | C-17: Referer の組合せに応じてPOST /cart/items 成功時の遷移先が決まる [2] | c17_addItem_redirectsByRefererCombination(String, String)[2] | PASS |
| 35 | C-17: Referer の組合せに応じてPOST /cart/items 成功時の遷移先が決まる [3] | c17_addItem_redirectsByRefererCombination(String, String)[3] | PASS |
| 36 | C-17: Referer の組合せに応じてPOST /cart/items 成功時の遷移先が決まる [4] | c17_addItem_redirectsByRefererCombination(String, String)[4] | PASS |
| 37 | C-17: Referer の組合せに応じてPOST /cart/items 成功時の遷移先が決まる [5] | c17_addItem_redirectsByRefererCombination(String, String)[5] | PASS |
| 38 | C-17: Referer の組合せに応じてPOST /cart/items 成功時の遷移先が決まる [6] | c17_addItem_redirectsByRefererCombination(String, String)[6] | PASS |
| 39 | C-17: Referer の組合せに応じてPOST /cart/items 成功時の遷移先が決まる [7] | c17_addItem_redirectsByRefererCombination(String, String)[7] | PASS |
| 40 | C-01-1: 商品一覧で価格が表示される | c01_1_showProducts_displaysPrice | PASS |
| 41 | C-05: GET /products の戻りビュー名は products | c05_showProducts_returnsProductsViewName | PASS |
| 42 | C-08-10: 商品詳細画面で数量入力フォームが表示される | c08_10_showProductDetail_displaysQuantityInput | PASS |
| 43 | C-03: 販売中商品が0件の場合、Modelに空リストが設定される | c03_showProducts_setsEmptyListToModel | PASS |
| 44 | C-01-8: 商品一覧で商品画像のsrc属性が表示される | c01_8_showProducts_displaysProductImage | PASS |
| 45 | C-16: 商品一覧画面から数量異常入力時は products を再表示してエラー表示する [1] | c16_addItem_invalidQuantityFromList_rendersList(String)[1] | PASS |
| 46 | C-16: 商品一覧画面から数量異常入力時は products を再表示してエラー表示する [2] | c16_addItem_invalidQuantityFromList_rendersList(String)[2] | PASS |
| 47 | C-16: 商品一覧画面から数量異常入力時は products を再表示してエラー表示する [3] | c16_addItem_invalidQuantityFromList_rendersList(String)[3] | PASS |
| 48 | C-16: 商品一覧画面から数量異常入力時は products を再表示してエラー表示する [4] | c16_addItem_invalidQuantityFromList_rendersList(String)[4] | PASS |
| 49 | C-16: 商品一覧画面から数量異常入力時は products を再表示してエラー表示する [5] | c16_addItem_invalidQuantityFromList_rendersList(String)[5] | PASS |
| 50 | C-16: 商品一覧画面から数量異常入力時は products を再表示してエラー表示する [6] | c16_addItem_invalidQuantityFromList_rendersList(String)[6] | PASS |
| 51 | C-01-7: 商品一覧でヘッダーのカートリンクが表示される | c01_7_showProducts_displaysCartHeaderLink | PASS |
| 52 | C-18: 商品詳細URLのproductIdが非数値の場合はHTTP 400 [1] | c18_showProductDetail_invalidPathVariable_returnsBadRequest(String)[1] | PASS |
| 53 | C-18: 商品詳細URLのproductIdが非数値の場合はHTTP 400 [2] | c18_showProductDetail_invalidPathVariable_returnsBadRequest(String)[2] | PASS |
| 54 | C-18: 商品詳細URLのproductIdが非数値の場合はHTTP 400 [3] | c18_showProductDetail_invalidPathVariable_returnsBadRequest(String)[3] | PASS |
| 55 | C-08-11: 商品詳細画面でstock=0の場合カート追加ボタンがdisabledになる | c08_11_showProductDetail_disablesCartButtonWhenOutOfStock | PASS |
