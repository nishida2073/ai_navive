﻿# テスト結果レポート - CartRepositoryTest

## 基本情報

| 項目 | 内容 |
|---|---|
| テスト実施日 | 2026年6月1日 |
| テスト種別 | JUnit単体テスト |
| 対象テストクラス | com.example.ec.repository.CartRepositoryTest |
| 対象ファイル | src/test/java/com/example/ec/repository/CartRepositoryTest.java |

## 実行結果

| 項目 | 結果 |
|---|---|
| 実行件数 | 16 |
| 成功 | 16 |
| 失敗 | 0 |

## 判定

PASS（全件成功）

## テストケース別結果

| No. | テストケース | テストメソッド名 | 結果 |
|---|---|---|---|
| 1 | insert: quantity=100はCHECK制約違反になる | insert_throwsWhenQuantityExceedsMax | PASS |
| 2 | insert/findByProductId: quantity=1（下限）を保持できる | insert_and_findByProductId_quantityMinBoundary | PASS |
| 3 | findAll: カートが空の場合は空リストを返す | findAll_returnsEmptyList | PASS |
| 4 | deleteAll: カート空の場合は0件削除 | deleteAll_returnsZeroWhenEmpty | PASS |
| 5 | insert: productsに存在しないproductIdを登録するとFK制約違反になる | insert_throwsWhenProductDoesNotExist | PASS |
| 6 | insert/findByProductId: quantity=99（上限）を保持できる | insert_and_findByProductId_quantityMaxBoundary | PASS |
| 7 | update/delete: 数量更新後に削除できる | update_and_delete | PASS |
| 8 | insert: 同一productIdを重複登録するとDB制約違反になる | insert_throwsWhenDuplicateProductId | PASS |
| 9 | deleteByProductId: 未存在商品ID削除時は0件削除 | deleteByProductId_returnsZeroWhenNotFound | PASS |
| 10 | findAll: カート1件登録時は1件取得される | findAll_returnsSingleItem | PASS |
| 11 | deleteAll: カート複数件の場合は全件削除される | deleteAll_deletesAllRowsWhenMultipleItemsExist | PASS |
| 12 | updateQuantity: 未存在商品ID更新時は0件更新 | updateQuantity_returnsZeroWhenNotFound | PASS |
| 13 | insert/findByProductId: 登録した商品を取得できる | insert_and_findByProductId | PASS |
| 14 | insert: quantity=0はCHECK制約違反になる | insert_throwsWhenQuantityIsZero | PASS |
| 15 | findAll: カート複数件登録時は複数件取得される | findAll_returnsMultipleItems | PASS |
| 16 | findByProductId: 未存在商品IDではnullを返す | findByProductId_returnsNullWhenNotFound | PASS |
