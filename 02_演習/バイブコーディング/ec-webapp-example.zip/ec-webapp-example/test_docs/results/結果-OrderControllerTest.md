﻿# テスト結果レポート - OrderControllerTest

## 基本情報

| 項目 | 内容 |
|---|---|
| テスト実施日 | 2026年6月1日 |
| テスト種別 | JUnit単体テスト |
| 対象テストクラス | com.example.ec.controller.OrderControllerTest |
| 対象ファイル | src/test/java/com/example/ec/controller/OrderControllerTest.java |

## 実行結果

| 項目 | 結果 |
|---|---|
| 実行件数 | 55 |
| 成功 | 55 |
| 失敗 | 0 |

## 判定

PASS（全件成功）

## テストケース別結果

| No. | テストケース | テストメソッド名 | 結果 |
|---|---|---|---|
| 1 | 注文完了画面へ遷移できる（GET /orders/complete/{orderId}） | getOrderComplete_displaysCompletePage | PASS |
| 2 | GET /orders/confirm で小計ラベルと値が表示される | getOrderConfirm_displaysSubtotal | PASS |
| 3 | 入力エラー時は入力値が保持され、エラーメッセージが表示される | invalidInput_postOrders_keepsInputValuesAndRendersMessages | PASS |
| 4 | GET /orders/confirm でService例外が発生した場合は例外が伝播する | getOrderConfirm_propagatesServiceException | PASS |
| 5 | 配送先情報の妥当値（境界値）では注文確定処理が呼び出される [1] | validInput_postOrders_callsPlaceOrder(String, String, String, String)[1] | PASS |
| 6 | 配送先情報の妥当値（境界値）では注文確定処理が呼び出される [2] | validInput_postOrders_callsPlaceOrder(String, String, String, String)[2] | PASS |
| 7 | 配送先情報の妥当値（境界値）では注文確定処理が呼び出される [3] | validInput_postOrders_callsPlaceOrder(String, String, String, String)[3] | PASS |
| 8 | POST /orders でシステム例外発生時は例外が伝播する | postOrders_propagatesSystemException | PASS |
| 9 | GET /orders/confirm で注文を確定するボタンが表示される | getOrderConfirm_displaysSubmitButton | PASS |
| 10 | GET /orders/complete/{orderId} で商品一覧へのリンクが表示される | getOrderComplete_displaysProductsLink | PASS |
| 11 | GET /orders/confirm で合計金額ラベルが表示される | getOrderConfirm_displaysTotalAmountLabel | PASS |
| 12 | GET /orders/confirm で商品名が表示される | getOrderConfirm_displaysProductName | PASS |
| 13 | GET /orders/complete/{orderId} で完了メッセージが表示される | getOrderComplete_displaysCompletionMessage | PASS |
| 14 | OC-C-008: GET /orders/confirm でカートが空の場合は /cart にリダイレクトされる | occ008_getOrderConfirm_redirectsWhenCartEmpty | PASS |
| 15 | OC-C-011: POST /orders 正常時は /orders/complete/{orderId} へリダイレクトする | occ011_postOrders_successRedirectsToComplete | PASS |
| 16 | GET /orders/confirm で注文者情報セクションが表示される | getOrderConfirm_displaysCustomerSection | PASS |
| 17 | GET /orders/confirm でカートに戻るリンクが表示される | getOrderConfirm_displaysBackToCartLink | PASS |
| 18 | GET /orders/complete/{orderId} で注文番号が表示される | getOrderComplete_displaysOrderId | PASS |
| 19 | 郵便番号×電話番号の組合せで入力検証結果が期待どおりになる [1] | combination_postOrders_postalAndPhone(String, String, boolean)[1] | PASS |
| 20 | 郵便番号×電話番号の組合せで入力検証結果が期待どおりになる [2] | combination_postOrders_postalAndPhone(String, String, boolean)[2] | PASS |
| 21 | 郵便番号×電話番号の組合せで入力検証結果が期待どおりになる [3] | combination_postOrders_postalAndPhone(String, String, boolean)[3] | PASS |
| 22 | 郵便番号×電話番号の組合せで入力検証結果が期待どおりになる [4] | combination_postOrders_postalAndPhone(String, String, boolean)[4] | PASS |
| 23 | 郵便番号×電話番号の組合せで入力検証結果が期待どおりになる [5] | combination_postOrders_postalAndPhone(String, String, boolean)[5] | PASS |
| 24 | 郵便番号×電話番号の組合せで入力検証結果が期待どおりになる [6] | combination_postOrders_postalAndPhone(String, String, boolean)[6] | PASS |
| 25 | 郵便番号×電話番号の組合せで入力検証結果が期待どおりになる [7] | combination_postOrders_postalAndPhone(String, String, boolean)[7] | PASS |
| 26 | 郵便番号×電話番号の組合せで入力検証結果が期待どおりになる [8] | combination_postOrders_postalAndPhone(String, String, boolean)[8] | PASS |
| 27 | 郵便番号×電話番号の組合せで入力検証結果が期待どおりになる [9] | combination_postOrders_postalAndPhone(String, String, boolean)[9] | PASS |
| 28 | GET /orders/confirm で商品IDのラベルと値が表示される | getOrderConfirm_displaysProductId | PASS |
| 29 | 配送先情報の不正値では入力エラーとなり order-confirm が再表示される [1] | invalidInput_postOrders_showsValidationErrors(String, String, String, String)[1] | PASS |
| 30 | 配送先情報の不正値では入力エラーとなり order-confirm が再表示される [2] | invalidInput_postOrders_showsValidationErrors(String, String, String, String)[2] | PASS |
| 31 | 配送先情報の不正値では入力エラーとなり order-confirm が再表示される [3] | invalidInput_postOrders_showsValidationErrors(String, String, String, String)[3] | PASS |
| 32 | 配送先情報の不正値では入力エラーとなり order-confirm が再表示される [4] | invalidInput_postOrders_showsValidationErrors(String, String, String, String)[4] | PASS |
| 33 | 配送先情報の不正値では入力エラーとなり order-confirm が再表示される [5] | invalidInput_postOrders_showsValidationErrors(String, String, String, String)[5] | PASS |
| 34 | 配送先情報の不正値では入力エラーとなり order-confirm が再表示される [6] | invalidInput_postOrders_showsValidationErrors(String, String, String, String)[6] | PASS |
| 35 | 配送先情報の不正値では入力エラーとなり order-confirm が再表示される [7] | invalidInput_postOrders_showsValidationErrors(String, String, String, String)[7] | PASS |
| 36 | 配送先情報の不正値では入力エラーとなり order-confirm が再表示される [8] | invalidInput_postOrders_showsValidationErrors(String, String, String, String)[8] | PASS |
| 37 | 配送先情報の不正値では入力エラーとなり order-confirm が再表示される [9] | invalidInput_postOrders_showsValidationErrors(String, String, String, String)[9] | PASS |
| 38 | 配送先情報の不正値では入力エラーとなり order-confirm が再表示される [10] | invalidInput_postOrders_showsValidationErrors(String, String, String, String)[10] | PASS |
| 39 | 配送先情報の不正値では入力エラーとなり order-confirm が再表示される [11] | invalidInput_postOrders_showsValidationErrors(String, String, String, String)[11] | PASS |
| 40 | 配送先情報の不正値では入力エラーとなり order-confirm が再表示される [12] | invalidInput_postOrders_showsValidationErrors(String, String, String, String)[12] | PASS |
| 41 | GET /orders/confirm で合計数量が表示される | getOrderConfirm_displaysTotalQuantity | PASS |
| 42 | GET /orders/complete では /products にリダイレクトされる | getOrderCompleteWithoutId_redirectsToProducts | PASS |
| 43 | POST /orders の業務例外時は入力値を保持して order-confirm を再表示する | postOrders_businessException_keepsInputValues | PASS |
| 44 | POST /orders で業務例外発生時は order-confirm を再表示しエラーメッセージを表示する | postOrders_handlesBusinessException | PASS |
| 45 | GET /orders/complete/{orderId} で商品一覧リンクのhrefが /products である | getOrderComplete_displaysProductsLinkHref | PASS |
| 46 | GET /orders/confirm で注文内容ラベルが表示される | getOrderConfirm_displaysOrderContentLabel | PASS |
| 47 | GET /orders/complete/{orderId} で注文受付ステータスが表示される | getOrderComplete_displaysAcceptedStatus | PASS |
| 48 | GET /orders/complete/{orderId} のPathVariableが非数値の場合はHTTP 400 [1] | getOrderComplete_invalidPathVariable_returnsBadRequest(String)[1] | PASS |
| 49 | GET /orders/complete/{orderId} のPathVariableが非数値の場合はHTTP 400 [2] | getOrderComplete_invalidPathVariable_returnsBadRequest(String)[2] | PASS |
| 50 | GET /orders/complete/{orderId} のPathVariableが非数値の場合はHTTP 400 [3] | getOrderComplete_invalidPathVariable_returnsBadRequest(String)[3] | PASS |
| 51 | GET /orders/confirm で単価ラベルと値が表示される | getOrderConfirm_displaysUnitPrice | PASS |
| 52 | POST /orders でカートが空の場合は /cart にリダイレクトし注文確定しない | postOrders_redirectsWhenCartEmpty | PASS |
| 53 | 注文完了情報が存在しない場合は /products にリダイレクトされる | getOrderComplete_redirectsWhenNotFound | PASS |
| 54 | GET /orders/confirm で個別商品の数量が表示される | getOrderConfirm_displaysItemQuantity | PASS |
| 55 | OC-C-001〜007: GET /orders/confirm で注文確認画面が表示され主要要素が描画される | occ001To007_getOrderConfirm_rendersOrderConfirmPage | PASS |
