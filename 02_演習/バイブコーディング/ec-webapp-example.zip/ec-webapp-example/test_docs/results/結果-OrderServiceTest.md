﻿# テスト結果レポート - OrderServiceTest

## 基本情報

| 項目 | 内容 |
|---|---|
| テスト実施日 | 2026年6月1日 |
| テスト種別 | JUnit単体テスト |
| 対象テストクラス | com.example.ec.service.OrderServiceTest |
| 対象ファイル | src/test/java/com/example/ec/service/OrderServiceTest.java |

## 実行結果

| 項目 | 結果 |
|---|---|
| 実行件数 | 53 |
| 成功 | 53 |
| 失敗 | 0 |

## 判定

PASS（全件成功）

## テストケース別結果

| No. | テストケース | テストメソッド名 | 結果 |
|---|---|---|---|
| 1 | OC-S-001: カート1件で注文確認モデルを作成できる | ocS001_getOrderConfirmation_singleItem | PASS |
| 2 | OC-S-002: カート複数件で全OrderItemModelを作成できる | ocS002_getOrderConfirmation_multipleItems | PASS |
| 3 | OC-S-003: カートが空の場合はempty=trueの空モデルを返す | ocS003_getOrderConfirmation_emptyCart | PASS |
| 4 | OC-S-004: CartServiceがnullを返す場合でも空モデルを返す | ocS004_getOrderConfirmation_nullCart | PASS |
| 5 | OC-S-005: 単価5980円・数量1の小計5980円を保持できる | ocS005_getOrderConfirmation_subtotal5980x1 | PASS |
| 6 | OC-S-006: 単価5980円・数量2の小計11960円を保持できる | ocS006_getOrderConfirmation_subtotal5980x2 | PASS |
| 7 | OC-S-007: 数量境界値1の計算結果を保持できる | ocS007_getOrderConfirmation_boundaryQuantity1 | PASS |
| 8 | OC-S-008: 数量境界値99の計算結果を保持できる | ocS008_getOrderConfirmation_boundaryQuantity99 | PASS |
| 9 | OC-S-009: 価格0円商品を含む場合でも合計金額を正しく保持できる | ocS009_getOrderConfirmation_zeroPrice | PASS |
| 10 | OC-S-010: 正常注文時に注文ヘッダ登録と注文明細登録が呼び出される | ocS010_placeOrder_successCallsRepositories | PASS |
| 11 | OC-S-011: 注文ヘッダ登録値（配送先情報・合計金額・注文日時）が正しく設定される | ocS011_placeOrder_headerFieldsMapped | PASS |
| 12 | OC-S-012: 注文明細登録値（注文ID・商品情報・小計）が正しく設定される | ocS012_placeOrder_detailFieldsMapped | PASS |
| 13 | OC-S-013: カートが空の状態で注文確定すると業務例外になる | ocS013_placeOrder_emptyCartThrows | PASS |
| 14 | OC-S-014: カート内商品の在庫不足時は業務例外になる | ocS014_placeOrder_quantityExceedsStockThrows | PASS |
| 15 | OC-S-015: products側に存在しない想定で在庫更新0件の場合は業務例外になる | ocS015_placeOrder_productNotFoundLikeDecreaseStockZero | PASS |
| 16 | OC-S-016: 注文ヘッダ登録時のRepository例外はServiceから伝播する | ocS016_placeOrder_orderRepositoryException | PASS |
| 17 | OC-S-017: 注文明細登録時のRepository例外はServiceから伝播する | ocS017_placeOrder_orderItemRepositoryException | PASS |
| 18 | OC-S-018: 配送先情報の妥当値（境界値）で正常に注文登録処理へ進む [1] | ocS018_placeOrder_validDeliveryInputs(String, String, String, String)[1] | PASS |
| 19 | OC-S-018: 配送先情報の妥当値（境界値）で正常に注文登録処理へ進む [2] | ocS018_placeOrder_validDeliveryInputs(String, String, String, String)[2] | PASS |
| 20 | OC-S-018: 配送先情報の妥当値（境界値）で正常に注文登録処理へ進む [3] | ocS018_placeOrder_validDeliveryInputs(String, String, String, String)[3] | PASS |
| 21 | OC-S-019: 配送先情報の不正値はRepository例外としてServiceが伝播する [1] | ocS019_placeOrder_invalidDeliveryInputs(String, String, String, String)[1] | PASS |
| 22 | OC-S-019: 配送先情報の不正値はRepository例外としてServiceが伝播する [2] | ocS019_placeOrder_invalidDeliveryInputs(String, String, String, String)[2] | PASS |
| 23 | OC-S-019: 配送先情報の不正値はRepository例外としてServiceが伝播する [3] | ocS019_placeOrder_invalidDeliveryInputs(String, String, String, String)[3] | PASS |
| 24 | OC-S-019: 配送先情報の不正値はRepository例外としてServiceが伝播する [4] | ocS019_placeOrder_invalidDeliveryInputs(String, String, String, String)[4] | PASS |
| 25 | OC-S-019: 配送先情報の不正値はRepository例外としてServiceが伝播する [5] | ocS019_placeOrder_invalidDeliveryInputs(String, String, String, String)[5] | PASS |
| 26 | OC-S-019: 配送先情報の不正値はRepository例外としてServiceが伝播する [6] | ocS019_placeOrder_invalidDeliveryInputs(String, String, String, String)[6] | PASS |
| 27 | OC-S-019: 配送先情報の不正値はRepository例外としてServiceが伝播する [7] | ocS019_placeOrder_invalidDeliveryInputs(String, String, String, String)[7] | PASS |
| 28 | OC-S-019: 配送先情報の不正値はRepository例外としてServiceが伝播する [8] | ocS019_placeOrder_invalidDeliveryInputs(String, String, String, String)[8] | PASS |
| 29 | OC-S-019: 配送先情報の不正値はRepository例外としてServiceが伝播する [9] | ocS019_placeOrder_invalidDeliveryInputs(String, String, String, String)[9] | PASS |
| 30 | OC-S-019: 配送先情報の不正値はRepository例外としてServiceが伝播する [10] | ocS019_placeOrder_invalidDeliveryInputs(String, String, String, String)[10] | PASS |
| 31 | OC-S-019: 配送先情報の不正値はRepository例外としてServiceが伝播する [11] | ocS019_placeOrder_invalidDeliveryInputs(String, String, String, String)[11] | PASS |
| 32 | OC-S-019: 配送先情報の不正値はRepository例外としてServiceが伝播する [12] | ocS019_placeOrder_invalidDeliveryInputs(String, String, String, String)[12] | PASS |
| 33 | OC-S-020: 注文時点の商品名・単価が注文明細に設定される | ocS020_placeOrder_snapshotFieldsFromCart | PASS |
| 34 | OC-S-021: getCompletedOrder は注文明細を含むOrderModelを返す | ocS021_getCompletedOrder_returnsCompletedOrder | PASS |
| 35 | OC-S-022: getCompletedOrder は存在しない注文IDで null を返す | ocS022_getCompletedOrder_returnsNullWhenNotFound | PASS |
| 36 | OC-S-023: getCompletedOrder は注文ヘッダの顧客情報を正しくマッピングする | ocS023_getCompletedOrder_mapsHeaderFields | PASS |
| 37 | OC-S-024: getCompletedOrder は注文明細の各項目を正しくマッピングする | ocS024_getCompletedOrder_mapsItemFields | PASS |
| 38 | OC-S-025: getCompletedOrder は注文明細の数量合計を totalQuantity に設定する | ocS025_getCompletedOrder_calculatesTotalQuantity | PASS |
| 39 | OC-S-026: getCompletedOrder は注文明細が空なら empty=true と totalQuantity=0 を返す | ocS026_getCompletedOrder_returnsEmptyWhenNoItems | PASS |
| 40 | OC-S-027: getCompletedOrder の注文ヘッダ取得で例外が発生した場合、例外が伝播する | ocS027_getCompletedOrder_propagatesOrderRepositoryException | PASS |
| 41 | OC-S-028: getCompletedOrder の注文明細取得で例外が発生した場合、例外が伝播する | ocS028_getCompletedOrder_propagatesOrderItemRepositoryException | PASS |
| 42 | OC-S-029: 単価×数量の直積ケースで getOrderConfirmation の小計・合計が正しい [1] | ocS029_getOrderConfirmation_priceQuantityCartesian(int, int, int)[1] | PASS |
| 43 | OC-S-029: 単価×数量の直積ケースで getOrderConfirmation の小計・合計が正しい [2] | ocS029_getOrderConfirmation_priceQuantityCartesian(int, int, int)[2] | PASS |
| 44 | OC-S-029: 単価×数量の直積ケースで getOrderConfirmation の小計・合計が正しい [3] | ocS029_getOrderConfirmation_priceQuantityCartesian(int, int, int)[3] | PASS |
| 45 | OC-S-029: 単価×数量の直積ケースで getOrderConfirmation の小計・合計が正しい [4] | ocS029_getOrderConfirmation_priceQuantityCartesian(int, int, int)[4] | PASS |
| 46 | OC-S-029: 単価×数量の直積ケースで getOrderConfirmation の小計・合計が正しい [5] | ocS029_getOrderConfirmation_priceQuantityCartesian(int, int, int)[5] | PASS |
| 47 | OC-S-029: 単価×数量の直積ケースで getOrderConfirmation の小計・合計が正しい [6] | ocS029_getOrderConfirmation_priceQuantityCartesian(int, int, int)[6] | PASS |
| 48 | OC-S-030: 在庫×数量×金額の直積ケースで placeOrder の成否が期待どおりになる [1] | ocS030_placeOrder_stockQuantityAmountCartesian(int, int, int, boolean, String)[1] | PASS |
| 49 | OC-S-030: 在庫×数量×金額の直積ケースで placeOrder の成否が期待どおりになる [2] | ocS030_placeOrder_stockQuantityAmountCartesian(int, int, int, boolean, String)[2] | PASS |
| 50 | OC-S-030: 在庫×数量×金額の直積ケースで placeOrder の成否が期待どおりになる [3] | ocS030_placeOrder_stockQuantityAmountCartesian(int, int, int, boolean, String)[3] | PASS |
| 51 | OC-S-030: 在庫×数量×金額の直積ケースで placeOrder の成否が期待どおりになる [4] | ocS030_placeOrder_stockQuantityAmountCartesian(int, int, int, boolean, String)[4] | PASS |
| 52 | OC-S-030: 在庫×数量×金額の直積ケースで placeOrder の成否が期待どおりになる [5] | ocS030_placeOrder_stockQuantityAmountCartesian(int, int, int, boolean, String)[5] | PASS |
| 53 | OC-S-030: 在庫×数量×金額の直積ケースで placeOrder の成否が期待どおりになる [6] | ocS030_placeOrder_stockQuantityAmountCartesian(int, int, int, boolean, String)[6] | PASS |
