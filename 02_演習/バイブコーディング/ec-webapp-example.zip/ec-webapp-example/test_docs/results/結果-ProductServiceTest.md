﻿# テスト結果レポート - ProductServiceTest

## 基本情報

| 項目 | 内容 |
|---|---|
| テスト実施日 | 2026年6月1日 |
| テスト種別 | JUnit単体テスト |
| 対象テストクラス | com.example.ec.service.ProductServiceTest |
| 対象ファイル | src/test/java/com/example/ec/service/ProductServiceTest.java |

## 実行結果

| 項目 | 結果 |
|---|---|
| 実行件数 | 19 |
| 成功 | 19 |
| 失敗 | 0 |

## 判定

PASS（全件成功）

## テストケース別結果

| No. | テストケース | テストメソッド名 | 結果 |
|---|---|---|---|
| 1 | S-01: Repositoryが2件のEntityを返した場合、2件のProductModelリストが返る | s01_getOnSaleProducts_returnsConvertedModelList | PASS |
| 2 | S-02: Repositoryが空リストを返した場合、nullではなく空のModelリストが返る | s02_getOnSaleProducts_returnsEmptyListWhenRepositoryReturnsEmpty | PASS |
| 3 | S-03: Repositoryが1件のEntityを返した場合、1件のProductModelリストが返る | s03_getOnSaleProducts_returnsOneItemList | PASS |
| 4 | S-04: 変換後のProductModelのproductIdが、EntityのproductIdと一致する | s04_getOnSaleProducts_productIdIsMappedCorrectly | PASS |
| 5 | S-05: 変換後のProductModelのnameが、Entityのnameと一致する | s05_getOnSaleProducts_nameIsMappedCorrectly | PASS |
| 6 | S-06: 変換後のProductModelのpriceが、Entityのpriceと一致する | s06_getOnSaleProducts_priceIsMappedCorrectly | PASS |
| 7 | S-07: stock=0のEntityを変換した場合、ProductModelのstockも0になる（境界値：在庫ゼロ） | s07_getOnSaleProducts_stockZeroIsMappedCorrectly | PASS |
| 8 | S-08: stock=1のEntityを変換した場合、ProductModelのstockも1になる（境界値：在庫最小値） | s08_getOnSaleProducts_stockOneIsMappedCorrectly | PASS |
| 9 | S-09: 変換後のProductModelのstatusが、Entityのstatusと一致する | s09_getOnSaleProducts_statusIsMappedCorrectly | PASS |
| 10 | S-10: 変換後のProductModelのimageUrlが、EntityのimageUrlと一致する | s10_getOnSaleProducts_imageUrlIsMappedCorrectly | PASS |
| 11 | S-11: Repositoryが3件のEntityを返した場合、返却されるModelリストのサイズも3である | s11_getOnSaleProducts_listSizeMatchesRepositoryResult | PASS |
| 12 | S-12: Repositoryがデータアクセス例外をスローした場合、同じ例外が呼び出し元に伝播する | s12_getOnSaleProducts_propagatesExceptionFromRepository | PASS |
| 13 | S-13: getOnSaleProducts()呼び出し時に、Repository#findOnSaleProductsがちょうど1回呼ばれる | s13_getOnSaleProducts_callsRepositoryExactlyOnce | PASS |
| 14 | S-14: findOnSaleProductById がEntityを返した場合、対応するProductModelが返る | s14_getOnSaleProduct_returnsConvertedModel | PASS |
| 15 | S-15: findOnSaleProductById がnullを返した場合、getOnSaleProduct も null を返す | s15_getOnSaleProduct_returnsNullWhenRepositoryReturnsNull | PASS |
| 16 | S-16: getOnSaleProduct で description が正しくマッピングされる | s16_getOnSaleProduct_descriptionIsMappedCorrectly | PASS |
| 17 | S-17: getOnSaleProduct で価格・在庫・ステータス・画像URLが正しくマッピングされる | s17_getOnSaleProduct_fieldsAreMappedCorrectly | PASS |
| 18 | S-18: findOnSaleProductById で例外が発生した場合、例外が伝播する | s18_getOnSaleProduct_propagatesExceptionFromRepository | PASS |
| 19 | S-19: getOnSaleProduct 呼び出し時に findOnSaleProductById が1回だけ呼ばれる | s19_getOnSaleProduct_callsRepositoryExactlyOnce | PASS |
