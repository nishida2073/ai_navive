﻿# テスト結果レポート - CartServiceTest

## 基本情報

| 項目 | 内容 |
|---|---|
| テスト実施日 | 2026年6月1日 |
| テスト種別 | JUnit単体テスト |
| 対象テストクラス | com.example.ec.service.CartServiceTest |
| 対象ファイル | src/test/java/com/example/ec/service/CartServiceTest.java |

## 実行結果

| 項目 | 結果 |
|---|---|
| 実行件数 | 53 |
| 成功 | 53 |
| 失敗 | 0 |

## 判定

PASS（全件成功）

## テストケース別結果

| No. | テストケース | テストメソッド名 | 結果 |
|---|---|---|---|
| 1 | CT-S-001: カートに1件ある場合、CartModelに1件のCartItemModelが作成される | ctS001_getCart_singleItem | PASS |
| 2 | CT-S-002: カートに複数件ある場合、すべてのCartItemModelが作成される | ctS002_getCart_multipleItems | PASS |
| 3 | CT-S-003: cartRepositoryが空リストを返した場合、空のCartModelが返る | ctS003_getCart_emptyList | PASS |
| 4 | CT-S-004: cartRepositoryがnullを返した場合でも異常終了せず空のCartModelが返る | ctS004_getCart_nullList | PASS |
| 5 | CT-S-005: 商品Repositoryで取得できない商品IDはカート表示から除外される | ctS005_getCart_excludesUnavailableProducts | PASS |
| 6 | CT-S-006: 価格0円の商品を含む場合でも小計・合計が正しく計算される | ctS006_getCart_zeroPrice | PASS |
| 7 | CT-S-007: 単価5980円・数量1の小計が5980円になる | ctS007_getCart_subtotalBoundaryQuantityOne | PASS |
| 8 | CT-S-008: 単価5980円・数量99の小計が592020円になる | ctS008_getCart_subtotalBoundaryQuantityNinetyNine | PASS |
| 9 | CT-S-009: 単価null・数量nullは0として扱われ、小計計算で異常終了しない | ctS009_getCart_nullPriceAndQuantityHandledAsZero | PASS |
| 10 | CT-S-010: cartRepository.findAllで例外が発生した場合、例外が伝播する | ctS010_getCart_propagatesRepositoryException | PASS |
| 11 | CT-S-011: 数量1でupdateQuantityを呼ぶとRepository更新が実行される | ctS011_updateQuantity_minBoundary | PASS |
| 12 | CT-S-012: 数量99でupdateQuantityを呼ぶとRepository更新が実行される | ctS012_updateQuantity_maxBoundary | PASS |
| 13 | CT-S-013: 数量nullは範囲外としてIllegalArgumentExceptionになる | ctS013_updateQuantity_null | PASS |
| 14 | CT-S-014: 数量0は範囲外としてIllegalArgumentExceptionになる | ctS014_updateQuantity_zero | PASS |
| 15 | CT-S-015: 数量-1は範囲外としてIllegalArgumentExceptionになる | ctS015_updateQuantity_negative | PASS |
| 16 | CT-S-016: 数量100は範囲外としてIllegalArgumentExceptionになる | ctS016_updateQuantity_overMax | PASS |
| 17 | CT-S-017: カートに存在しない商品IDを更新すると業務例外になる | ctS017_updateQuantity_nonExistingCartItem | PASS |
| 18 | CT-S-018: 販売中でない商品を更新すると業務例外になる | ctS018_updateQuantity_productNotOnSale | PASS |
| 19 | CT-S-019: 在庫数を超える数量を指定した場合は業務例外になる | ctS019_updateQuantity_exceedsStock | PASS |
| 20 | CT-S-020: cartRepository.updateQuantityで例外が発生した場合、例外が伝播する | ctS020_updateQuantity_propagatesRepositoryException | PASS |
| 21 | CT-S-021: 存在する商品IDを削除するとdeleteByProductIdが呼ばれる | ctS021_deleteItem_existing | PASS |
| 22 | CT-S-022: 存在しない商品IDを削除した場合は静かに終了する | ctS022_deleteItem_nonExisting | PASS |
| 23 | CT-S-023: 削除後にgetCartを呼ぶと、削除後データに基づいてモデルが作成される | ctS023_deleteItem_thenGetCartReflectsRepositoryState | PASS |
| 24 | CT-S-024: cartRepository.findByProductIdで例外が発生した場合、例外が伝播する | ctS024_deleteItem_propagatesRepositoryException | PASS |
| 25 | CT-S-025: 商品在庫がnullの場合、在庫0として在庫超過例外になる | ctS025_updateQuantity_nullStock | PASS |
| 26 | CT-S-026: 新規商品を数量1で追加するとinsertが呼ばれる | ctS026_addItem_newProductWithMinQuantity | PASS |
| 27 | CT-S-027: 新規商品を数量99で追加するとinsertが呼ばれる | ctS027_addItem_newProductWithMaxQuantity | PASS |
| 28 | CT-S-028: 数量nullでaddItemするとIllegalArgumentExceptionになる | ctS028_addItem_nullQuantity | PASS |
| 29 | CT-S-029: 数量0でaddItemするとIllegalArgumentExceptionになる | ctS029_addItem_zeroQuantity | PASS |
| 30 | CT-S-030: 数量100でaddItemするとIllegalArgumentExceptionになる | ctS030_addItem_overMaxQuantity | PASS |
| 31 | CT-S-031: 販売中でない商品をaddItemすると業務例外になる | ctS031_addItem_productNotOnSale | PASS |
| 32 | CT-S-032: 在庫0の商品をaddItemすると在庫切れ例外になる | ctS032_addItem_outOfStock | PASS |
| 33 | CT-S-033: 在庫数を超える数量でaddItemすると業務例外になる | ctS033_addItem_quantityExceedsStock | PASS |
| 34 | CT-S-034: 既存商品に数量を追加すると合計数量でupdateQuantityが呼ばれる | ctS034_addItem_existingItemUpdatesMergedQuantity | PASS |
| 35 | CT-S-035: 既存数量nullの商品にaddItemすると数量0起点で加算更新される | ctS035_addItem_existingNullQuantityHandledAsZero | PASS |
| 36 | CT-S-036: 既存数量と追加数量の合計が100以上なら業務例外になる | ctS036_addItem_totalQuantityExceedsMax | PASS |
| 37 | CT-S-037: 既存数量と追加数量の合計が在庫数を超えると業務例外になる | ctS037_addItem_totalQuantityExceedsStock | PASS |
| 38 | CT-S-038: addItem の insert で例外が発生した場合、例外が伝播する | ctS038_addItem_insertExceptionPropagates | PASS |
| 39 | CT-S-039: addItem の updateQuantity で例外が発生した場合、例外が伝播する | ctS039_addItem_updateExceptionPropagates | PASS |
| 40 | CT-S-040: 単価×数量の直積ケースで getCart の小計・合計が正しい [1] | ctS040_getCart_priceQuantityCartesian(Integer, Integer, Integer)[1] | PASS |
| 41 | CT-S-040: 単価×数量の直積ケースで getCart の小計・合計が正しい [2] | ctS040_getCart_priceQuantityCartesian(Integer, Integer, Integer)[2] | PASS |
| 42 | CT-S-040: 単価×数量の直積ケースで getCart の小計・合計が正しい [3] | ctS040_getCart_priceQuantityCartesian(Integer, Integer, Integer)[3] | PASS |
| 43 | CT-S-040: 単価×数量の直積ケースで getCart の小計・合計が正しい [4] | ctS040_getCart_priceQuantityCartesian(Integer, Integer, Integer)[4] | PASS |
| 44 | CT-S-040: 単価×数量の直積ケースで getCart の小計・合計が正しい [5] | ctS040_getCart_priceQuantityCartesian(Integer, Integer, Integer)[5] | PASS |
| 45 | CT-S-040: 単価×数量の直積ケースで getCart の小計・合計が正しい [6] | ctS040_getCart_priceQuantityCartesian(Integer, Integer, Integer)[6] | PASS |
| 46 | CT-S-041: 在庫×数量の直積ケースで addItem の分岐が期待どおりになる [1] | ctS041_addItem_stockQuantityCartesian(Integer, Integer, boolean, String)[1] | PASS |
| 47 | CT-S-041: 在庫×数量の直積ケースで addItem の分岐が期待どおりになる [2] | ctS041_addItem_stockQuantityCartesian(Integer, Integer, boolean, String)[2] | PASS |
| 48 | CT-S-041: 在庫×数量の直積ケースで addItem の分岐が期待どおりになる [3] | ctS041_addItem_stockQuantityCartesian(Integer, Integer, boolean, String)[3] | PASS |
| 49 | CT-S-041: 在庫×数量の直積ケースで addItem の分岐が期待どおりになる [4] | ctS041_addItem_stockQuantityCartesian(Integer, Integer, boolean, String)[4] | PASS |
| 50 | CT-S-041: 在庫×数量の直積ケースで addItem の分岐が期待どおりになる [5] | ctS041_addItem_stockQuantityCartesian(Integer, Integer, boolean, String)[5] | PASS |
| 51 | CT-S-041: 在庫×数量の直積ケースで addItem の分岐が期待どおりになる [6] | ctS041_addItem_stockQuantityCartesian(Integer, Integer, boolean, String)[6] | PASS |
| 52 | CT-S-041: 在庫×数量の直積ケースで addItem の分岐が期待どおりになる [7] | ctS041_addItem_stockQuantityCartesian(Integer, Integer, boolean, String)[7] | PASS |
| 53 | CT-S-041: 在庫×数量の直積ケースで addItem の分岐が期待どおりになる [8] | ctS041_addItem_stockQuantityCartesian(Integer, Integer, boolean, String)[8] | PASS |
