﻿# テスト結果レポート - CartControllerTest

## 基本情報

| 項目 | 内容 |
|---|---|
| テスト実施日 | 2026年6月1日 |
| テスト種別 | JUnit単体テスト |
| 対象テストクラス | com.example.ec.controller.CartControllerTest |
| 対象ファイル | src/test/java/com/example/ec/controller/CartControllerTest.java |

## 実行結果

| 項目 | 結果 |
|---|---|
| 実行件数 | 45 |
| 成功 | 45 |
| 失敗 | 0 |

## 判定

PASS（全件成功）

## テストケース別結果

| No. | テストケース | テストメソッド名 | 結果 |
|---|---|---|---|
| 1 | CT-U-001: quantity=1でPOST更新するとServiceが呼び出され、/cartにリダイレクトされる | ctu001_updateQuantity_callsServiceWithMinBoundary | PASS |
| 2 | CT-C-002-3: 非空カート時に注文手続き導線が表示される | ctc002_3_showCart_displaysOrderConfirmLink | PASS |
| 3 | CT-D-003: 存在しない商品ID削除時でも仕様どおり/cartへリダイレクトされる | ctd003_deleteItem_nonExistingProductStillRedirects | PASS |
| 4 | CT-N-004: カート画面に /products へのリンクが表示される | ctn004_cartViewContainsProductsLink | PASS |
| 5 | CT-U-005: quantity負数は異常系として扱われ、/cartにリダイレクトされる | ctu005_updateQuantity_validationErrorWhenNegative | PASS |
| 6 | CT-U-009: 存在しない商品ID更新時、エラーメッセージを設定して/cartにリダイレクトされる | ctu009_updateQuantity_handlesIllegalArgumentException | PASS |
| 7 | CT-U-004: quantity=0は異常系として扱われ、/cartにリダイレクトされる | ctu004_updateQuantity_validationErrorWhenZero | PASS |
| 8 | CT-U-012: 数量異常入力の組合せでは cart を再表示してエラー表示する [1] | ctu012_updateQuantity_invalidQuantityCombinations(String)[1] | PASS |
| 9 | CT-U-012: 数量異常入力の組合せでは cart を再表示してエラー表示する [2] | ctu012_updateQuantity_invalidQuantityCombinations(String)[2] | PASS |
| 10 | CT-U-012: 数量異常入力の組合せでは cart を再表示してエラー表示する [3] | ctu012_updateQuantity_invalidQuantityCombinations(String)[3] | PASS |
| 11 | CT-U-012: 数量異常入力の組合せでは cart を再表示してエラー表示する [4] | ctu012_updateQuantity_invalidQuantityCombinations(String)[4] | PASS |
| 12 | CT-U-012: 数量異常入力の組合せでは cart を再表示してエラー表示する [5] | ctu012_updateQuantity_invalidQuantityCombinations(String)[5] | PASS |
| 13 | CT-U-012: 数量異常入力の組合せでは cart を再表示してエラー表示する [6] | ctu012_updateQuantity_invalidQuantityCombinations(String)[6] | PASS |
| 14 | CT-N-003: 非空カート画面に /orders/confirm へのリンクが表示される | ctn003_cartViewContainsOrderConfirmLink | PASS |
| 15 | CT-U-008: quantityが小数は異常系として扱われ、/cartにリダイレクトされる | ctu008_updateQuantity_validationErrorWhenDecimal | PASS |
| 16 | CT-C-002-6: 非空カート時に小計が表示される | ctc002_6_showCart_displaysSubtotal | PASS |
| 17 | CT-D-006: 削除URLのPathVariable異常入力の組合せはHTTP 400 [1] | ctd006_deleteItem_invalidPathVariableCombinations(String)[1] | PASS |
| 18 | CT-D-006: 削除URLのPathVariable異常入力の組合せはHTTP 400 [2] | ctd006_deleteItem_invalidPathVariableCombinations(String)[2] | PASS |
| 19 | CT-D-006: 削除URLのPathVariable異常入力の組合せはHTTP 400 [3] | ctd006_deleteItem_invalidPathVariableCombinations(String)[3] | PASS |
| 20 | CT-U-007: quantityが数値以外は異常系として扱われ、/cartにリダイレクトされる | ctu007_updateQuantity_validationErrorWhenNonNumeric | PASS |
| 21 | CT-U-013: 更新URLのPathVariable異常入力の組合せはHTTP 400 [1] | ctu013_updateQuantity_invalidPathVariableCombinations(String)[1] | PASS |
| 22 | CT-U-013: 更新URLのPathVariable異常入力の組合せはHTTP 400 [2] | ctu013_updateQuantity_invalidPathVariableCombinations(String)[2] | PASS |
| 23 | CT-U-013: 更新URLのPathVariable異常入力の組合せはHTTP 400 [3] | ctu013_updateQuantity_invalidPathVariableCombinations(String)[3] | PASS |
| 24 | CT-D-004: 削除時にService例外が発生した場合は例外が伝播する | ctd004_deleteItem_propagatesException | PASS |
| 25 | CT-C-003: 空カート時もHTTP 200で、空メッセージ表示かつ注文手続き導線は表示されない | ctc003_showCart_rendersEmptyCartView | PASS |
| 26 | CT-C-002: 非空カート時にタイトル・ヘッダー・商品情報・操作ボタンが表示される | ctc002_showCart_rendersThymeleafContentsForNonEmptyCart | PASS |
| 27 | CT-C-002-4: 非空カート時に商品IDが表示される | ctc002_4_showCart_displaysProductId | PASS |
| 28 | CT-C-002-2: 非空カート時に合計金額が表示される | ctc002_2_showCart_displaysTotalAmount | PASS |
| 29 | CT-C-002-5: 非空カート時に単価が表示される | ctc002_5_showCart_displaysUnitPrice | PASS |
| 30 | CT-C-001: GET /cart でHTTP 200、cartビュー、Modelにcartが設定される | ctc001_showCart_returnsOkAndViewAndModel | PASS |
| 31 | CT-N-002: GET /products にアクセスできる | ctn002_navigation_toProductsEndpointAvailable | PASS |
| 32 | CT-D-001: 存在する商品ID削除時、Service削除処理が呼び出され/cartへリダイレクトされる | ctd001_deleteItem_callsServiceAndRedirects | PASS |
| 33 | CT-D-005: 削除URLのproductIdが非数値の場合、HTTP 400になる | ctd005_deleteItem_pathVariableTypeMismatch | PASS |
| 34 | CT-C-004: GET /cart でService例外発生時は例外が伝播する | ctc004_showCart_propagatesExceptionWhenServiceThrows | PASS |
| 35 | CT-U-003: quantity未入力は異常系として扱われ、/cartにリダイレクトされる | ctu003_updateQuantity_validationErrorWhenQuantityMissing | PASS |
| 36 | CT-U-011: 更新URLのproductIdが非数値の場合、HTTP 400になる | ctu011_updateQuantity_pathVariableTypeMismatch | PASS |
| 37 | CT-C-002-7: 非空カート時に合計数量が表示される | ctc002_7_showCart_displaysTotalQuantity | PASS |
| 38 | CT-U-006: quantity=100は異常系として扱われ、/cartにリダイレクトされる | ctu006_updateQuantity_validationErrorWhenOverMax | PASS |
| 39 | CT-N-001: GET /orders/confirm にアクセスできる | ctn001_navigation_toOrderConfirmEndpointAvailable | PASS |
| 40 | CT-U-010: 更新時にServiceが想定外例外を投げた場合は例外が伝播する | ctu010_updateQuantity_propagatesUnexpectedException | PASS |
| 41 | CT-C-002-1: 非空カート時に商品名が表示される | ctc002_1_showCart_displaysItemName | PASS |
| 42 | CT-C-011: 非空カート時に個別商品の数量入力値が表示される | ctc002_9_showCart_displaysItemQuantityValue | PASS |
| 43 | CT-D-002: 複数商品を想定しても指定productIdのみ削除処理が呼び出される | ctd002_deleteItem_callsOnlySpecifiedProductId | PASS |
| 44 | CT-U-002: quantity=99でPOST更新するとServiceが呼び出され、/cartにリダイレクトされる | ctu002_updateQuantity_callsServiceWithMaxBoundary | PASS |
| 45 | CT-C-002-8: 非空カート時に数量更新と削除の操作ボタンが表示される | ctc002_8_showCart_displaysActionButtons | PASS |
