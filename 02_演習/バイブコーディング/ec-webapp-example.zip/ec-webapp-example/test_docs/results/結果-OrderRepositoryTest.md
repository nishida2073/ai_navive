﻿# テスト結果レポート - OrderRepositoryTest

## 基本情報

| 項目 | 内容 |
|---|---|
| テスト実施日 | 2026年6月1日 |
| テスト種別 | JUnit単体テスト |
| 対象テストクラス | com.example.ec.repository.OrderRepositoryTest |
| 対象ファイル | src/test/java/com/example/ec/repository/OrderRepositoryTest.java |

## 実行結果

| 項目 | 結果 |
|---|---|
| 実行件数 | 10 |
| 成功 | 10 |
| 失敗 | 0 |

## 判定

PASS（全件成功）

## テストケース別結果

| No. | テストケース | テストメソッド名 | 結果 |
|---|---|---|---|
| 1 | insert/findByOrderId: address=255文字（上限）を保持できる | insert_and_findByOrderId_addressMaxBoundary | PASS |
| 2 | insert/findByOrderId: customerName=100文字（上限）を保持できる | insert_and_findByOrderId_customerNameMaxBoundary | PASS |
| 3 | insert: customerName=nullはNOT NULL制約違反になる | insert_throwsWhenCustomerNameIsNull | PASS |
| 4 | findByOrderId: 存在しない注文IDではnullを返す | findByOrderId_returnsNullWhenNotFound | PASS |
| 5 | insert: totalAmount=nullはNOT NULL制約違反になる | insert_throwsWhenTotalAmountIsNull | PASS |
| 6 | insert: postalCode=nullはNOT NULL制約違反になる | insert_throwsWhenPostalCodeIsNull | PASS |
| 7 | insert/findByOrderId: orderedAt はnullでなく、現在時刻に近い値が格納される | insert_and_findByOrderId_setsOrderedAtByDatabaseTimestamp | PASS |
| 8 | findByOrderId: 複数注文登録時に指定orderIdの注文のみ取得できる | findByOrderId_returnsOnlySpecifiedOrderWhenMultipleOrdersExist | PASS |
| 9 | insert/findByOrderId: totalAmount=0（下限）を保持できる | insert_and_findByOrderId_totalAmountZeroBoundary | PASS |
| 10 | insert/findByOrderId: 登録した注文を取得できる | insert_and_findByOrderId | PASS |
